<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
require_once '../config/database.php';

// Helper function to auto-detect python or python3
function getPythonCommand() {
    $output = null;
    $retval = null;
    exec("python --version 2>&1", $output, $retval);
    if ($retval === 0) return "python";
    $output = null;
    $retval = null;
    exec("python3 --version 2>&1", $output, $retval);
    if ($retval === 0) return "python3";
    throw new Exception("Python is not installed or not in PATH.");
}

function getPrediction($data) {
    $data_json = json_encode($data);
    $pythonCmd = getPythonCommand();
    $descriptorspec = [
        0 => ["pipe", "r"], // stdin
        1 => ["pipe", "w"], // stdout
        2 => ["pipe", "w"]  // stderr
    ];
    $process = proc_open("$pythonCmd ../ml_model/predict.py", $descriptorspec, $pipes);
    if (is_resource($process)) {
        fwrite($pipes[0], $data_json);
        fclose($pipes[0]);
        $output = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        $return_value = proc_close($process);
        if ($return_value !== 0) {
            return ['error' => "Python error: $stderr"];
        }
        $result = json_decode($output, true);
        if ($result === null) {
            return ['error' => 'Python did not return valid JSON', 'raw_output' => $output];
        }
        return $result;
    } else {
        return ['error' => 'Could not start Python process'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $json_data = file_get_contents('php://input');
        $data = json_decode($json_data, true);
        if (!$data) {
            throw new Exception('Invalid JSON data: ' . $json_data);
        }
        $required_fields = ['size_sqm', 'distance_to_city_center', 'location', 'nearby_amenities', 'zoning', 'land_type'];
        foreach ($required_fields as $field) {
            if (!isset($data[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }
        $zoning_landtype = trim($data['zoning']) . ' - ' . trim($data['land_type']);
        $model_input = [
            'Size (sqm)' => $data['size_sqm'],
            'Distance to City Center (km)' => $data['distance_to_city_center'],
            'Location' => $data['location'],
            'Nearby Amenities' => $data['nearby_amenities'],
            'Zoning_LandType' => $zoning_landtype
        ];
        $prediction = getPrediction($model_input);
        if (isset($prediction['error'])) {
            throw new Exception('Prediction error: ' . $prediction['error'] . (isset($prediction['raw_output']) ? (' | Output: ' . $prediction['raw_output']) : ''));
        }
        echo json_encode([
            'success' => true,
            'predicted_price' => $prediction['price'],
            'confidence' => $prediction['confidence'] ?? null
        ]);
        exit;
    } catch (Exception $e) {
        http_response_code(400);
        error_log('API ERROR: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
        exit;
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
    exit;
}
?> 