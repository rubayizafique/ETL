<?php
header('Content-Type: application/json');
require_once '../config/database.php';

try {
    // Initialize query and parameters
    $query = "SELECT p.*, u.username 
              FROM properties p 
              LEFT JOIN users u ON p.user_id = u.id 
              WHERE 1=1";
    $params = [];
    $types = "";
    
    // Location filter
    if (!empty($_GET['location'])) {
        $query .= " AND p.location LIKE ?";
        $params[] = "%" . $_GET['location'] . "%";
        $types .= "s";
    }
    
    // Size range filter
    if (!empty($_GET['size_range'])) {
        $range = explode('-', $_GET['size_range']);
        if (count($range) === 2) {
            $query .= " AND p.size_sqm BETWEEN ? AND ?";
            $params[] = $range[0];
            $params[] = $range[1];
            $types .= "dd";
        } elseif ($_GET['size_range'] === '10000+') {
            $query .= " AND p.size_sqm >= ?";
            $params[] = 10000;
            $types .= "d";
        }
    }
    
    // Amenities filters
    if (!empty($_GET['has_water'])) {
        $query .= " AND p.has_water = 1";
    }
    if (!empty($_GET['has_electricity'])) {
        $query .= " AND p.has_electricity = 1";
    }
    if (!empty($_GET['has_road_access'])) {
        $query .= " AND p.has_road_access = 1";
    }
    
    // Order by submission date
    $query .= " ORDER BY p.submission_date DESC";
    
    // Prepare and execute query
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Format results
    $properties = [];
    while ($row = $result->fetch_assoc()) {
        $properties[] = [
            'id' => $row['id'],
            'location' => $row['location'],
            'size_sqm' => $row['size_sqm'],
            'has_water' => $row['has_water'],
            'has_electricity' => $row['has_electricity'],
            'has_road_access' => $row['has_road_access'],
            'estimated_price' => $row['estimated_price'],
            'submission_date' => $row['submission_date'],
            'username' => $row['username']
        ];
    }
    
    echo json_encode($properties);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 