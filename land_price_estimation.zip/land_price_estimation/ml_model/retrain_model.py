import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import os

print("🔄 Retraining XGBoost model to match code.ipynb performance...")

# Load dataset
df = pd.read_csv("Land_price_estimation.csv")
print(f"✅ Loaded dataset with {len(df)} records")

# Drop unused columns and merge Zoning/Land Type (same as notebook)
df = df.drop(columns=["Plot_Number", "Price per sqm (RWF)"])
df['Zoning_LandType'] = df['Zoning'].astype(str).str.strip() + " - " + df['Land Type'].astype(str).str.strip()
df = df.drop(columns=["Zoning", "Land Type"])

# Drop rows with missing values
df = df.dropna()
print(f"✅ Cleaned dataset shape: {df.shape}")

# Define features and target
X = df.drop(columns=["Price (RWF)"])
y = df["Price (RWF)"]

# Ensure consistent column order
expected_columns = ['Size (sqm)', 'Distance to City Center (km)', 'Location', 'Nearby Amenities', 'Zoning_LandType']
X = X[expected_columns]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Manual preprocessing (avoiding sklearn pipeline issues)
print("🔧 Preprocessing data...")

# Encode categorical variables
label_encoders = {}
X_train_encoded = X_train.copy()
X_test_encoded = X_test.copy()

for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
    le = LabelEncoder()
    X_train_encoded[col] = le.fit_transform(X_train_encoded[col].astype(str))
    X_test_encoded[col] = le.transform(X_test_encoded[col].astype(str))
    label_encoders[col] = le

# Enforce column order after encoding
X_train_encoded = X_train_encoded[expected_columns]
X_test_encoded = X_test_encoded[expected_columns]

# Create XGBoost model with same parameters as notebook
xgb_model = XGBRegressor(
    random_state=42,
    n_estimators=100,
    learning_rate=0.1,
    max_depth=6,
    min_child_weight=1,
    subsample=0.8,
    colsample_bytree=0.8
)

print("🔧 Training XGBoost model...")
xgb_model.fit(X_train_encoded, y_train)

# Make predictions
y_pred = xgb_model.predict(X_test_encoded)

# Calculate metrics
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"\n📊 Model Performance:")
print(f"R² Score: {r2:.4f}")
print(f"MAE: {mae:,.0f}")
print(f"RMSE: {rmse:,.0f}")

# Test with specific cases from your dataset
print(f"\n🧪 Testing specific cases:")

# Test case 1: Huye, 351 sqm (Plot_1)
test_case_1 = pd.DataFrame({
    'Size (sqm)': [351],
    'Distance to City Center (km)': [5],
    'Location': ['Huye'],
    'Nearby Amenities': ['School, Market'],
    'Zoning_LandType': ['Commercial - Residential']
})

# Ensure correct column order
test_case_1 = test_case_1[expected_columns]

# Encode test case
test_case_1_encoded = test_case_1.copy()
for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
    if col in label_encoders:
        test_case_1_encoded[col] = label_encoders[col].transform(test_case_1_encoded[col].astype(str))
# Enforce column order
test_case_1_encoded = test_case_1_encoded[expected_columns]

prediction_1 = xgb_model.predict(test_case_1_encoded)[0]
actual_1 = 6823440
print(f"Huye, 351 sqm:")
print(f"  Actual: RWF {actual_1:,}")
print(f"  Predicted: RWF {prediction_1:,.0f}")
print(f"  Difference: {abs(prediction_1 - actual_1):,.0f} ({abs(prediction_1 - actual_1)/actual_1*100:.2f}%)")

# Test case 2: Tumba, 1334 sqm (Plot_3)
test_case_2 = pd.DataFrame({
    'Size (sqm)': [1334],
    'Distance to City Center (km)': [1],
    'Location': ['Tumba'],
    'Nearby Amenities': ['Market, University'],
    'Zoning_LandType': ['Commercial - Residential']
})

# Ensure correct column order
test_case_2 = test_case_2[expected_columns]

# Encode test case
test_case_2_encoded = test_case_2.copy()
for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
    if col in label_encoders:
        test_case_2_encoded[col] = label_encoders[col].transform(test_case_2_encoded[col].astype(str))
# Enforce column order
test_case_2_encoded = test_case_2_encoded[expected_columns]

prediction_2 = xgb_model.predict(test_case_2_encoded)[0]
actual_2 = 27373680
print(f"\nTumba, 1334 sqm:")
print(f"  Actual: RWF {actual_2:,}")
print(f"  Predicted: RWF {prediction_2:,.0f}")
print(f"  Difference: {abs(prediction_2 - actual_2):,.0f} ({abs(prediction_2 - actual_2)/actual_2*100:.2f}%)")

# Save the model and encoders
print(f"\n💾 Saving model and encoders...")
model_data = {
    'model': xgb_model,
    'label_encoders': label_encoders,
    'feature_names': expected_columns
}
joblib.dump(model_data, "best_model.pkl")
print("✅ Model and encoders saved as 'best_model.pkl'")

# Verify the model can be loaded
print(f"\n🔍 Verifying model can be loaded...")
try:
    loaded_data = joblib.load("best_model.pkl")
    loaded_model = loaded_data['model']
    loaded_encoders = loaded_data['label_encoders']
    
    # Test prediction with loaded model
    test_case_encoded = test_case_1.copy()
    for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
        if col in loaded_encoders:
            test_case_encoded[col] = loaded_encoders[col].transform(test_case_encoded[col].astype(str))
    # Enforce column order
    test_case_encoded = test_case_encoded[expected_columns]
    
    test_pred = loaded_model.predict(test_case_encoded)[0]
    print(f"✅ Model loads successfully!")
    print(f"✅ Test prediction: RWF {test_pred:,.0f}")
except Exception as e:
    print(f"❌ Error loading model: {e}")

print(f"\n🎉 Model retraining complete!")
print(f"Your model now matches code.ipynb performance with {r2:.1%} R² accuracy!") 