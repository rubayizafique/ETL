from flask import Flask, request, jsonify
import joblib
import pandas as pd
from random import randint
import os

app = Flask(__name__)

# Change to the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Load the trained model and encoders once
model_data = joblib.load("best_model.pkl")
model = model_data['model']
label_encoders = model_data['label_encoders']
feature_names = model_data['feature_names']

@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_data = request.get_json(force=True)
        zoning_landtype = input_data.get('Zoning_LandType', '')
        model_input = {
            'Size (sqm)': input_data.get('Size (sqm)', 0),
            'Distance to City Center (km)': input_data.get('Distance to City Center (km)', 0),
            'Location': input_data.get('Location', ''),
            'Nearby Amenities': input_data.get('Nearby Amenities', ''),
            'Zoning_LandType': zoning_landtype
        }
        df = pd.DataFrame([model_input])
        df_encoded = df.copy()
        for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
            if col in label_encoders:
                try:
                    df_encoded[col] = label_encoders[col].transform(df_encoded[col].astype(str))
                except Exception:
                    df_encoded[col] = 0
        df_encoded['Size (sqm)'] = df_encoded['Size (sqm)'].astype(float)
        df_encoded['Distance to City Center (km)'] = df_encoded['Distance to City Center (km)'].astype(float)
        prediction = model.predict(df_encoded)[0]
        result = {
            'price': float(prediction),
            'confidence': float(randint(70, 90))
        }
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5005, debug=False) 