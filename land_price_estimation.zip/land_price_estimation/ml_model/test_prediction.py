import json
import subprocess
import sys
import os

# Change to the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

def test_prediction():
    # Test case 1: Huye, 351 sqm with proper amenities
    test_data = {
        'Location': 'Huye',
        'Size (sqm)': 351,
        'Zoning': 'Commercial',
        'Nearby Amenities': 'School, Market',
        'Distance to City Center (km)': 5,
        'Land Type': 'Residential'
    }
    
    print("🧪 Testing prediction with proper amenities...")
    print(f"Input data: {json.dumps(test_data, indent=2)}")
    
    # Call predict.py
    try:
        command = ['python', 'predict.py', json.dumps(test_data)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            prediction = json.loads(result.stdout.strip())
            print(f"✅ Prediction successful!")
            print(f"Predicted price: RWF {prediction['price']:,.0f}")
            print(f"Confidence: {prediction.get('confidence', 'N/A')}%")
            
            # Check if stderr has debug info
            if result.stderr:
                print(f"Debug info: {result.stderr}")
        else:
            print(f"❌ Prediction failed!")
            print(f"Error: {result.stderr}")
            
    except Exception as e:
        print(f"❌ Exception occurred: {e}")

if __name__ == "__main__":
    test_prediction() 