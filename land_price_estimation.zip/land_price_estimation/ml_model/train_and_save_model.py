import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# Load data
df = pd.read_csv("Land_price_estimation.csv")

# Drop unnecessary columns if present
drop_cols = [col for col in ["Plot_Number", "Price per sqm (RWF)"] if col in df.columns]
df = df.drop(columns=drop_cols, errors='ignore')

# Remove rows with missing target
df = df.dropna(subset=["Price (RWF)"])

# Features and target
X = df.drop(columns=["Price (RWF)"])
y = df["Price (RWF)"]

# Identify categorical and numerical columns
categorical_cols = X.select_dtypes(include='object').columns.tolist()
numerical_cols = X.select_dtypes(exclude='object').columns.tolist()

# Preprocessing
numerical_transformer = SimpleImputer(strategy="mean")
categorical_transformer = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])
preprocessor = ColumnTransformer([
    ("num", numerical_transformer, numerical_cols),
    ("cat", categorical_transformer, categorical_cols)
])

# Model candidates
models = {
    "RandomForest": RandomForestRegressor(random_state=42),
    "XGBoost": XGBRegressor(random_state=42, verbosity=0),
    "LinearRegression": LinearRegression()
}
param_grids = {
    "RandomForest": {"regressor__n_estimators": [100, 200], "regressor__max_depth": [None, 10, 20]},
    "XGBoost": {"regressor__n_estimators": [100, 200], "regressor__max_depth": [3, 6, 10]},
    "LinearRegression": {}
}

best_score = -np.inf
best_model = None
best_name = None
best_pipeline = None

for name, model in models.items():
    print(f"\nTraining {name}...")
    pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("regressor", model)
    ])
    if param_grids[name]:
        grid = GridSearchCV(pipeline, param_grids[name], cv=5, scoring='r2', n_jobs=-1)
        grid.fit(X, y)
        score = grid.best_score_
        print(f"Best params: {grid.best_params_}")
        final_model = grid.best_estimator_
    else:
        scores = cross_val_score(pipeline, X, y, cv=5, scoring='r2')
        score = scores.mean()
        pipeline.fit(X, y)
        final_model = pipeline
    print(f"CV R2: {score:.4f}")
    if score > best_score:
        best_score = score
        best_model = final_model
        best_name = name
        best_pipeline = final_model

# Evaluate on full data
preds = best_model.predict(X)
print(f"\nBest Model: {best_name}")
print(f"R2 (full data): {r2_score(y, preds):.4f}")
print(f"RMSE (full data): {np.sqrt(mean_squared_error(y, preds)):.2f}")

# Save best model
joblib.dump(best_model, "best_model.pkl")
print("✅ Model saved as best_model.pkl")