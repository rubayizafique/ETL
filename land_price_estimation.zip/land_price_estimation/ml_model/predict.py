import sys
import json
import pandas as pd
import joblib
import os
from random import randint

# Change to the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Load the trained model and encoders
try:
    model_data = joblib.load("best_model.pkl")
    model = model_data['model']
    label_encoders = model_data['label_encoders']
    feature_names = model_data['feature_names']
    print("✅ Model and encoders loaded successfully", file=sys.stderr)
except Exception as e:
    print(f"❌ Error loading model: {e}", file=sys.stderr)
    print(json.dumps({'error': f'Error loading model: {e}'}))
    sys.exit(1)

def load_input_json():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-file', type=str, help='Path to input JSON file')
    args = parser.parse_args()
    try:
        if args.input_file:
            with open(args.input_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"[PY] Loaded JSON from file: {args.input_file}", file=sys.stderr)
        else:
            data = json.load(sys.stdin)
            print(f"[PY] Loaded JSON from stdin", file=sys.stderr)
        if isinstance(data, str):
            data = json.loads(data)
        if not isinstance(data, dict):
            raise ValueError("Input JSON is not an object/dict.")
        return data
    except Exception as e:
        print(json.dumps({'error': f'Invalid JSON input: {str(e)}'}))
        sys.exit(1)

def main():
    try:
        input_data = load_input_json()  # input_data is guaranteed to be a dict
        # Use Zoning_LandType directly from input
        zoning_landtype = input_data.get('Zoning_LandType', '')
        # Prepare data in the format expected by the model
        model_data = {
            'Size (sqm)': input_data.get('Size (sqm)', 0),
            'Distance to City Center (km)': input_data.get('Distance to City Center (km)', 0),
            'Location': input_data.get('Location', ''),
            'Nearby Amenities': input_data.get('Nearby Amenities', ''),
            'Zoning_LandType': zoning_landtype
        }
        # Convert input to DataFrame
        df = pd.DataFrame([model_data])
        # DEBUG: Print DataFrame columns (only to stderr)
        print(f"DEBUG: DataFrame columns: {df.columns.tolist()}", file=sys.stderr)
        print(f"DEBUG: DataFrame data: {df.to_dict('records')}", file=sys.stderr)
        # Encode categorical variables using the saved encoders
        df_encoded = df.copy()
        for col in ['Location', 'Nearby Amenities', 'Zoning_LandType']:
            if col in label_encoders:
                try:
                    # Handle unseen categories by using a default value
                    df_encoded[col] = label_encoders[col].transform(df_encoded[col].astype(str))
                    print(f"DEBUG: {col} encoded as: {df_encoded[col].iloc[0]}", file=sys.stderr)
                except ValueError as e:
                    print(f"Warning: Unseen category in {col}, using fallback", file=sys.stderr)
                    print(f"DEBUG: Original value: '{df_encoded[col].iloc[0]}'", file=sys.stderr)
                    print(f"DEBUG: Available categories: {label_encoders[col].classes_}", file=sys.stderr)
                    # Use a default encoded value (usually 0)
                    df_encoded[col] = 0
        # Ensure numeric columns are float for XGBoost
        df_encoded['Size (sqm)'] = df_encoded['Size (sqm)'].astype(float)
        df_encoded['Distance to City Center (km)'] = df_encoded['Distance to City Center (km)'].astype(float)
        # Predict with error handling for version compatibility
        try:
            prediction = model.predict(df_encoded)[0]
            print("✅ Used XGBoost model prediction", file=sys.stderr)
            print(f"[PREDICT] Model input: {df_encoded.to_dict('records')}", file=sys.stderr)
        except Exception as predict_error:
            print(f"[ERROR] XGBoost prediction failed: {predict_error}", file=sys.stderr)
            print(f"[ERROR] Model input: {df_encoded.to_dict('records')}", file=sys.stderr)
            raise
        # Output result as JSON (single line, no extra whitespace)
        result = {
            'price': float(prediction),
            'confidence': float(randint(70, 90))  # Dynamic confidence score
        }
        print(json.dumps(result, separators=(",", ":")))
    except Exception as e:
        error_result = {
            'error': str(e)
        }
        print(json.dumps(error_result, separators=(",", ":")))
        sys.exit(1)

if __name__ == "__main__":
    main() 