document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.querySelector('.toggle-sidebar');
    const sidebarLinks = document.querySelectorAll('.sidebar-menu a span');
    const userInfo = document.querySelector('.user-info');

    // Check if sidebar state is stored in localStorage
    const isSidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    
    // Apply initial state
    if (sidebar && mainContent && toggleBtn) {
        if (isSidebarCollapsed) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('expanded');
            toggleBtn.classList.add('collapsed');
            sidebarLinks.forEach(span => span.style.display = 'none');
            if (userInfo) {
                userInfo.querySelectorAll('.user-name, .user-role, .btn span').forEach(el => el.style.display = 'none');
            }
        }

        // Toggle sidebar
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            toggleBtn.classList.toggle('collapsed');
            
            // Toggle text visibility
            sidebarLinks.forEach(span => {
                span.style.display = sidebar.classList.contains('collapsed') ? 'none' : 'inline';
            });

            if (userInfo) {
                userInfo.querySelectorAll('.user-name, .user-role, .btn span').forEach(el => {
                    el.style.display = sidebar.classList.contains('collapsed') ? 'none' : 'block';
                });
            }
            
            // Store state in localStorage
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });
    }

    // Handle mobile view
    function handleMobileView() {
        if (!sidebar || !mainContent || !toggleBtn) return;
        if (window.innerWidth <= 992) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('expanded');
            toggleBtn.classList.add('collapsed');
            sidebarLinks.forEach(span => span.style.display = 'none');
            if (userInfo) {
                userInfo.querySelectorAll('.user-name, .user-role, .btn span').forEach(el => el.style.display = 'none');
            }
        } else {
            // Restore desktop state from localStorage
            if (localStorage.getItem('sidebarCollapsed') === 'true') {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
                toggleBtn.classList.add('collapsed');
                sidebarLinks.forEach(span => span.style.display = 'none');
                if (userInfo) {
                    userInfo.querySelectorAll('.user-name, .user-role, .btn span').forEach(el => el.style.display = 'none');
                }
            } else {
                sidebar.classList.remove('collapsed');
                mainContent.classList.remove('expanded');
                toggleBtn.classList.remove('collapsed');
                sidebarLinks.forEach(span => span.style.display = 'inline');
                if (userInfo) {
                    userInfo.querySelectorAll('.user-name, .user-role, .btn span').forEach(el => el.style.display = 'block');
                }
            }
        }
    }

    // Initial call
    handleMobileView();

    // Listen for window resize
    window.addEventListener('resize', handleMobileView);
}); 