// Initialize animations and interactions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize floating shapes
    initFloatingShapes();
    
    // Initialize scroll animations
    initScrollAnimations();
    
    // Initialize form animations
    initFormAnimations();
    
    // Initialize loading states
    initLoadingStates();
    
    // Initialize toast notifications
    initToastNotifications();
});

// Floating shapes animation
function initFloatingShapes() {
    const container = document.createElement('div');
    container.className = 'floating-shapes';
    
    // Create shapes
    for (let i = 0; i < 5; i++) {
        const shape = document.createElement('div');
        shape.className = 'shape';
        container.appendChild(shape);
    }
    
    document.body.appendChild(container);
}

// Scroll animations
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, {
        threshold: 0.1
    });

    // Observe all elements with fade-in class
    document.querySelectorAll('.fade-in').forEach(element => {
        observer.observe(element);
    });
}

// Form animations and validation
function initFormAnimations() {
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle property type change
    const propertyTypeSelect = document.getElementById('property_type');
    const numRoomsInput = document.getElementById('num_rooms');
    
    if (propertyTypeSelect && numRoomsInput) {
        propertyTypeSelect.addEventListener('change', function() {
            if (this.value === 'land') {
                numRoomsInput.value = '';
                numRoomsInput.disabled = true;
                numRoomsInput.classList.add('fade-out');
            } else {
                numRoomsInput.disabled = false;
                numRoomsInput.classList.remove('fade-out');
            }
        });
    }

    // Form validation with animations
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Animate invalid fields
                form.querySelectorAll(':invalid').forEach(field => {
                    field.classList.add('shake');
                    setTimeout(() => field.classList.remove('shake'), 500);
                });
            }
            form.classList.add('was-validated');
        });
    });

    // Input focus animations
    document.querySelectorAll('.form-control').forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    });
}

// Loading states
function initLoadingStates() {
    // Add loading class to elements that need it
    document.querySelectorAll('[data-loading]').forEach(element => {
        element.classList.add('loading');
    });
}

// Toast notifications
function initToastNotifications() {
    // Create toast container if it doesn't exist
    if (!document.querySelector('.toast-container')) {
        const container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }
}

// Show toast notification
function showToast(message, type = 'success') {
    const container = document.querySelector('.toast-container');
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    container.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Utility function to format currency
function formatCurrency(amount) {
    return 'RWF ' + new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Utility function to format area
function formatArea(sqm) {
    return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(sqm) + ' sqm';
}

// Add CSS classes for animations
document.head.insertAdjacentHTML('beforeend', `
    <style>
        .fade-out {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .shake {
            animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
        }
        
        @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
        }
        
        .focused {
            transform: translateY(-2px);
            transition: transform 0.3s ease;
        }
    </style>
`); 