<?php
require_once 'config/database.php';

// Create original_dataset table if it doesn't exist
$create_table_sql = "
CREATE TABLE IF NOT EXISTS original_dataset (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plot_number VARCHAR(50),
    location VARCHAR(100),
    size_sqm DECIMAL(10,2),
    price DECIMAL(15,2),
    zoning VARCHAR(100),
    nearby_amenities TEXT,
    distance_to_city_center DECIMAL(5,2),
    land_type VARCHAR(100),
    price_per_sqm DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($create_table_sql) === TRUE) {
    echo "✅ Original dataset table created successfully\n";
} else {
    echo "❌ Error creating table: " . $conn->error . "\n";
}

// Clear existing data
$conn->query("TRUNCATE TABLE original_dataset");

// Read CSV file and insert data
$csv_file = 'ml_model/Land_price_estimation.csv';
if (($handle = fopen($csv_file, "r")) !== FALSE) {
    // Skip header row
    fgetcsv($handle);
    
    $insert_sql = "INSERT INTO original_dataset (plot_number, location, size_sqm, price, zoning, nearby_amenities, distance_to_city_center, land_type, price_per_sqm) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    
    $count = 0;
    while (($data = fgetcsv($handle)) !== FALSE) {
        if (count($data) >= 9) { // Ensure we have all required columns
            $plot_number = trim($data[0]);
            $location = trim($data[1]);
            $size_sqm = floatval($data[2]);
            $price = floatval($data[3]);
            $zoning = trim($data[4]);
            $nearby_amenities = trim($data[5]);
            $distance_to_city_center = floatval($data[6]);
            $land_type = trim($data[7]);
            $price_per_sqm = floatval($data[8]);
            
            $stmt->bind_param("ssddsssdd", 
                $plot_number, $location, $size_sqm, $price, $zoning, 
                $nearby_amenities, $distance_to_city_center, $land_type, $price_per_sqm
            );
            
            if ($stmt->execute()) {
                $count++;
            } else {
                echo "❌ Error inserting row: " . $stmt->error . "\n";
            }
        } else {
            echo "❌ Skipping row with insufficient data: " . implode(',', $data) . "\n";
        }
    }
    
    fclose($handle);
    echo "✅ Successfully imported $count records from CSV\n";
} else {
    echo "❌ Error opening CSV file\n";
}

$conn->close();
echo "✅ Original dataset population completed\n";
?> 