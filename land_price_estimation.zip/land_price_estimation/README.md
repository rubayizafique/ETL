# Land Price Estimation System

A web-based application for estimating land and property prices using machine learning. This system allows users to input property details and get price estimates, while administrators can manage submissions and datasets.

## Features

- User-friendly interface for property details submission
- Property price estimation (ML model to be integrated)
- Admin dashboard for data management
- Responsive design using Bootstrap 5
- MySQL database integration

## Technical Stack

- PHP
- MySQL
- Bootstrap 5
- JavaScript
- CSS

## Setup Instructions

1. Ensure you have XAMPP installed and running
2. Clone this repository to your htdocs folder
3. Import the database schema from `database/schema.sql`
4. Configure database connection in `config/database.php`
5. Access the application through your web browser at `http://localhost/land_price_estimation`

## Directory Structure

```
land_price_estimation/
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── config/
│   └── database.php
├── includes/
│   ├── header.php
│   └── footer.php
├── admin/
│   ├── dashboard.php
│   └── manage_submissions.php
├── database/
│   └── schema.sql
├── index.php
├── predict.php
└── submit.php
```

## Future Enhancements

- Machine Learning model integration
- User authentication system
- Historical price tracking
- Advanced search and filtering
- Data visualization 