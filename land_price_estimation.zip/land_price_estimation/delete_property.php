<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Check if property ID is provided
$property_id = $_GET['id'] ?? $_POST['id'] ?? null;
if (!$property_id) {
    header('Location: user/dashboard.php');
    exit;
}

// First, check if the property belongs to the user
$stmt = $conn->prepare("SELECT id FROM properties WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $property_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Property not found or you don't have permission to delete it.";
    header('Location: user/dashboard.php');
    exit;
}

// Delete associated predictions first
$stmt = $conn->prepare("DELETE FROM predictions WHERE property_id = ?");
$stmt->bind_param("i", $property_id);
$stmt->execute();

// Delete the property
$stmt = $conn->prepare("DELETE FROM properties WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $property_id, $_SESSION['user_id']);

$success = $stmt->execute();

if ($success) {
    $_SESSION['success'] = "Property deleted successfully!";
} else {
    $_SESSION['error'] = "Error deleting property. Please try again.";
}
header('Location: user/dashboard.php');
exit; 