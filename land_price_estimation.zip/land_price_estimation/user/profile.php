<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Get user's profile information
$stmt = $conn->prepare("
    SELECT 
        u.*,
        COUNT(DISTINCT p.id) as total_predictions,
        AVG(pr.predicted_price) as avg_price,
        MAX(pr.confidence_score) as highest_confidence
    FROM users u
    LEFT JOIN properties p ON u.id = p.user_id
    LEFT JOIN predictions pr ON p.id = pr.property_id
    WHERE u.id = ?
    GROUP BY u.id
");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get recent predictions
$recent_stmt = $conn->prepare("
    SELECT 
        p.*,
        pr.predicted_price,
        pr.confidence_score,
        pr.prediction_date
    FROM properties p
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    WHERE p.user_id = ?
    ORDER BY p.submission_date DESC
    LIMIT 5
");

if ($recent_stmt === false) {
    die("Error preparing statement: " . $recent_stmt->error);
}

$recent_stmt->bind_param("i", $_SESSION['user_id']);
$recent_stmt->execute();
$recent_predictions = $recent_stmt->get_result();

include '../includes/header_logged_in.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white d-none d-lg-block" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
        <div class="p-3">
            <div class="d-flex align-items-center mb-4">
                <img src="../assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
                <h5 class="text-white mb-0">User Dashboard</h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link text-white" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white active" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-white" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Mobile Sidebar Toggle Button -->
    <button class="btn btn-dark d-lg-none position-fixed" style="top: 1rem; left: 1rem; z-index: 1100;" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMobile" aria-controls="sidebarMobile">
        <i class="bi bi-list fs-2"></i>
    </button>
    <!-- Mobile Sidebar (Offcanvas) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Profile Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="bi bi-person-circle me-2"></i>My Profile
                    </h1>
                    <p class="text-muted mb-0">View and manage your profile information</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="settings.php" class="btn btn-primary">
                        <i class="bi bi-gear-fill me-2"></i>Edit Profile
                    </a>
                    <a href="../logout.php" class="btn btn-outline-danger d-lg-none">
                        <i class="bi bi-box-arrow-right"></i>
                    </a>
                </div>
            </div>

            <div class="row g-4">
                <!-- Profile Information -->
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-4">
                                <div class="profile-avatar">
                                    <i class="bi bi-person-circle display-1"></i>
                                </div>
                            </div>
                            <h4 class="mb-1"><?php echo htmlspecialchars($user['username']); ?></h4>
                            <p class="text-muted mb-3">
                                <i class="bi bi-calendar-check me-1"></i>
                                Member since <?php echo date('F Y', strtotime($user['created_at'])); ?>
                            </p>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="mailto:<?php echo htmlspecialchars($user['email']); ?>" class="btn btn-outline-primary">
                                    <i class="bi bi-envelope-fill"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Stats -->
                    <div class="card border-0 shadow-sm mt-4">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-graph-up me-2"></i>Quick Stats
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="stat-icon bg-primary bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-building text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Total Predictions</h6>
                                    <h4 class="mb-0"><?php echo number_format($user['total_predictions']); ?></h4>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <div class="stat-icon bg-success bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-currency-dollar text-success"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Average Price</h6>
                                    <h4 class="mb-0">RWF <?php echo number_format($user['avg_price'], 2); ?></h4>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-info bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-percent text-info"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Highest Confidence</h6>
                                    <h4 class="mb-0"><?php echo number_format($user['highest_confidence'], 1); ?>%</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="col-md-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">Recent Activity</h5>
                        </div>
                        <div class="card-body">
                            <?php while ($prediction = $recent_predictions->fetch_assoc()): ?>
                            <div class="d-flex align-items-start mb-4">
                                <div class="prediction-icon bg-primary bg-opacity-10 rounded p-2 me-3">
                                    <i class="bi bi-calculator text-primary"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1">Land in <?php echo htmlspecialchars($prediction['location']); ?></h6>
                                            <p class="text-muted mb-0">
                                                <i class="bi bi-calendar3 me-1"></i>
                                                <?php echo date('F d, Y', strtotime($prediction['submission_date'])); ?>
                                            </p>
                                        </div>
                                        <div class="text-end">
                                            <h5 class="text-success mb-1">
                                                RWF <?php echo number_format($prediction['predicted_price'], 2); ?>
                                            </h5>
                                            <?php if ($prediction['confidence_score']): ?>
                                            <div class="progress" style="height: 6px; width: 100px;">
                                                <div class="progress-bar bg-success" 
                                                     role="progressbar" 
                                                     style="width: <?php echo $prediction['confidence_score']; ?>%">
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                <?php echo number_format($prediction['confidence_score'], 1); ?>% confidence
                                            </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row g-3 mt-2">
                                        <div class="col-md-3">
                                            <div class="d-flex align-items-center">
                                                <i class="bi bi-rulers text-primary me-2"></i>
                                                <div>
                                                    <small class="text-muted d-block">Size</small>
                                                    <strong><?php echo number_format($prediction['size_sqm'], 2); ?> sqm</strong>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if ($prediction['additional_amenities']): ?>
                                    <div class="alert alert-info mt-3 mb-0">
                                        <h6 class="alert-heading mb-2">
                                            <i class="bi bi-info-circle me-2"></i>Additional Notes
                                        </h6>
                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($prediction['additional_amenities'])); ?></p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Profile Information -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="card-title mb-4">Profile Information</h5>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label text-muted">Username</label>
                                    <p class="mb-0"><?php echo htmlspecialchars($user['username']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label text-muted">Email</label>
                                    <p class="mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label text-muted">Member Since</label>
                                    <p class="mb-0"><?php echo date('F d, Y', strtotime($user['created_at'])); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label text-muted">Account Type</label>
                                    <p class="mb-0"><?php echo ucfirst($user['role']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <a href="settings.php" class="btn btn-primary">
                                <i class="bi bi-pencil me-2"></i>Edit Profile
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Timeline Styles */
.timeline {
    position: relative;
    padding: 20px 0;
}

.timeline-item {
    position: relative;
    padding-left: 50px;
    margin-bottom: 30px;
}

.timeline-marker {
    position: absolute;
    left: 0;
    top: 0;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #0d6efd;
    border: 4px solid #fff;
    box-shadow: 0 0 0 2px #0d6efd;
}

.timeline-item::before {
    content: '';
    position: absolute;
    left: 9px;
    top: 20px;
    height: calc(100% + 10px);
    width: 2px;
    background: #e9ecef;
}

.timeline-item:last-child::before {
    display: none;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .sidebar {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

@media (max-width: 768px) {
    .timeline-item {
        padding-left: 40px;
    }
}

/* Mobile Optimizations */
@media (max-width: 576px) {
    .timeline-marker {
        width: 16px;
        height: 16px;
    }
    
    .btn-group .btn {
        padding: 0.25rem 0.5rem;
    }
}

.profile-avatar {
    width: 120px;
    height: 120px;
    margin: 0 auto;
    color: #6c757d;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f8f9fa;
    border-radius: 50%;
    border: 2px solid #dee2e6;
}

.profile-avatar i {
    font-size: 4rem;
}

.stat-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
}

.stat-icon i {
    font-size: 1.5rem;
}
</style>

<?php include '../includes/footer.php'; ?> 