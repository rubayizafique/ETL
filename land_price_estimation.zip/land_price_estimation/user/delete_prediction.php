<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Check if prediction ID is provided
if (!isset($_POST['prediction_id']) || empty($_POST['prediction_id'])) {
    $_SESSION['error_message'] = 'Invalid prediction ID.';
    header('Location: history.php');
    exit;
}

$prediction_id = (int)$_POST['prediction_id'];
$user_id = $_SESSION['user_id'];

try {
    // Start transaction
    $conn->begin_transaction();
    
    // First, verify that the prediction belongs to the current user
    $verify_stmt = $conn->prepare("SELECT id FROM properties WHERE id = ? AND user_id = ?");
    $verify_stmt->bind_param("ii", $prediction_id, $user_id);
    $verify_stmt->execute();
    $verify_result = $verify_stmt->get_result();
    
    if ($verify_result->num_rows === 0) {
        throw new Exception('Prediction not found or you do not have permission to delete it.');
    }
    
    // Delete related predictions first (if they exist)
    $delete_predictions_stmt = $conn->prepare("DELETE FROM predictions WHERE property_id = ?");
    $delete_predictions_stmt->bind_param("i", $prediction_id);
    $delete_predictions_stmt->execute();
    
    // Delete the property record
    $delete_property_stmt = $conn->prepare("DELETE FROM properties WHERE id = ? AND user_id = ?");
    $delete_property_stmt->bind_param("ii", $prediction_id, $user_id);
    
    if ($delete_property_stmt->execute()) {
        if ($delete_property_stmt->affected_rows > 0) {
            // Commit transaction
            $conn->commit();
            $_SESSION['success_message'] = 'Prediction deleted successfully.';
        } else {
            throw new Exception('Failed to delete prediction. Please try again.');
        }
    } else {
        throw new Exception('Database error occurred while deleting prediction.');
    }
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $_SESSION['error_message'] = $e->getMessage();
}

// Redirect back to history page
header('Location: history.php');
exit;
?>