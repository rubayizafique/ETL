<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Get export type from request
$export_type = $_GET['type'] ?? 'csv';
$user_id = $_SESSION['user_id'];

// Function to get user's complete portfolio data
function getUserCompletePortfolioData($conn, $user_id) {
    $stmt = $conn->prepare("
        SELECT 
            p.id,
            p.location,
            p.size_sqm,
            p.has_water,
            p.has_electricity,
            p.has_road_access,
            p.additional_amenities,
            p.estimated_price,
            p.submission_date,
            p.land_type,
            p.zoning,
            p.land_use,
            p.nearby_schools,
            p.nearby_hospital,
            p.nearby_market,
            p.nearby_university,
            p.zoning_landtype,
            p.nearby_amenities,
            p.distance_to_city_center,
            pr.predicted_price,
            pr.confidence_score,
            pr.prediction_date,
            CASE 
                WHEN p.has_water = 1 AND p.has_electricity = 1 AND p.has_road_access = 1 THEN 'Fully Developed'
                WHEN p.has_water = 1 OR p.has_electricity = 1 OR p.has_road_access = 1 THEN 'Partially Developed'
                ELSE 'Undeveloped'
            END as development_status,
            CASE 
                WHEN p.estimated_price < 1000000 THEN 'Under 1M'
                WHEN p.estimated_price < 5000000 THEN '1M - 5M'
                WHEN p.estimated_price < 10000000 THEN '5M - 10M'
                WHEN p.estimated_price < 20000000 THEN '10M - 20M'
                ELSE 'Over 20M'
            END as price_category,
            CASE 
                WHEN pr.confidence_score >= 90 THEN 'Excellent'
                WHEN pr.confidence_score >= 80 THEN 'Good'
                WHEN pr.confidence_score >= 70 THEN 'Fair'
                ELSE 'Poor'
            END as confidence_category,
            ABS(p.estimated_price - pr.predicted_price) as price_difference,
            ((ABS(p.estimated_price - pr.predicted_price) / p.estimated_price) * 100) as accuracy_percentage,
            (p.estimated_price * pow(1.03, 10)) as conservative_10yr_projection,
            (p.estimated_price * pow(1.05, 10)) as moderate_10yr_projection,
            (p.estimated_price * pow(1.08, 10)) as aggressive_10yr_projection
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        WHERE p.user_id = ?
        ORDER BY p.submission_date DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get user's portfolio statistics
function getUserPortfolioStats($conn, $user_id) {
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_properties,
            SUM(estimated_price) as total_value,
            AVG(estimated_price) as avg_price,
            MIN(estimated_price) as min_price,
            MAX(estimated_price) as max_price,
            AVG(pr.confidence_score) as avg_confidence,
            MAX(pr.confidence_score) as highest_confidence,
            MIN(pr.confidence_score) as lowest_confidence,
            COUNT(CASE WHEN pr.confidence_score >= 80 THEN 1 END) as high_confidence_count,
            COUNT(CASE WHEN pr.confidence_score < 70 THEN 1 END) as low_confidence_count,
            COUNT(CASE WHEN has_water = 1 THEN 1 END) as properties_with_water,
            COUNT(CASE WHEN has_electricity = 1 THEN 1 END) as properties_with_electricity,
            COUNT(CASE WHEN has_road_access = 1 THEN 1 END) as properties_with_road_access
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        WHERE p.user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Function to get location summary
function getUserLocationSummary($conn, $user_id) {
    $stmt = $conn->prepare("
        SELECT 
            location,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            SUM(estimated_price) as total_value,
            AVG(pr.confidence_score) as avg_confidence
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        WHERE p.user_id = ?
        GROUP BY location
        ORDER BY total_value DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to clean data - remove empty, null, 0, and N/A values
function cleanData($value) {
    if ($value === null || $value === '' || $value === '0' || $value === 'N/A' || $value === 0) {
        return '';
    }
    return $value;
}

// Generate CSV export
if ($export_type === 'csv') {
    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="portfolio_' . $_SESSION['username'] . '_' . date('Y-m-d') . '.csv"');

    // Create output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM for proper Excel encoding
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // Get portfolio data
    $properties = getUserCompletePortfolioData($conn, $user_id);
    $stats = getUserPortfolioStats($conn, $user_id);
    $locations = getUserLocationSummary($conn, $user_id);

    // Write Portfolio Summary Section
    fputcsv($output, ['PORTFOLIO SUMMARY']);
    fputcsv($output, ['']);
    fputcsv($output, ['Metric', 'Value']);
    fputcsv($output, ['Total Properties', cleanData($stats['total_properties'])]);
    fputcsv($output, ['Total Portfolio Value', cleanData($stats['total_value'])]);
    fputcsv($output, ['Average Property Price', cleanData($stats['avg_price'])]);
    fputcsv($output, ['Minimum Property Price', cleanData($stats['min_price'])]);
    fputcsv($output, ['Maximum Property Price', cleanData($stats['max_price'])]);
    fputcsv($output, ['Average Confidence Score', cleanData($stats['avg_confidence'])]);
    fputcsv($output, ['Highest Confidence Score', cleanData($stats['highest_confidence'])]);
    fputcsv($output, ['Properties with Water', cleanData($stats['properties_with_water'])]);
    fputcsv($output, ['Properties with Electricity', cleanData($stats['properties_with_electricity'])]);
    fputcsv($output, ['Properties with Road Access', cleanData($stats['properties_with_road_access'])]);
    fputcsv($output, ['']);

    // Write Location Summary Section
    fputcsv($output, ['LOCATION SUMMARY']);
    fputcsv($output, ['']);
    fputcsv($output, ['Location', 'Property Count', 'Average Price', 'Total Value', 'Average Confidence']);
    foreach ($locations as $location) {
        fputcsv($output, [
            cleanData($location['location']),
            cleanData($location['property_count']),
            cleanData($location['avg_price']),
            cleanData($location['total_value']),
            cleanData($location['avg_confidence'])
        ]);
    }
    fputcsv($output, ['']);

    // Write Detailed Properties Section
    fputcsv($output, ['DETAILED PROPERTIES']);
    fputcsv($output, ['']);
    fputcsv($output, [
        'ID', 'Location', 'Size (sqm)', 'Has Water', 'Has Electricity', 'Has Road Access',
        'Additional Amenities', 'Estimated Price', 'Submission Date', 'Land Type', 'Zoning',
        'Land Use', 'Nearby Schools', 'Nearby Hospital', 'Nearby Market', 'Nearby University',
        'Zoning Land Type', 'Nearby Amenities', 'Distance to City Center', 'Predicted Price',
        'Confidence Score', 'Prediction Date', 'Development Status', 'Price Category',
        'Confidence Category', 'Price Difference', 'Accuracy Percentage', 'Conservative 10yr Projection',
        'Moderate 10yr Projection', 'Aggressive 10yr Projection'
    ]);

    foreach ($properties as $property) {
        fputcsv($output, [
            cleanData($property['id']),
            cleanData($property['location']),
            cleanData($property['size_sqm']),
            cleanData($property['has_water'] ? 'Yes' : ''),
            cleanData($property['has_electricity'] ? 'Yes' : ''),
            cleanData($property['has_road_access'] ? 'Yes' : ''),
            cleanData($property['additional_amenities']),
            cleanData($property['estimated_price']),
            cleanData($property['submission_date']),
            cleanData($property['land_type']),
            cleanData($property['zoning']),
            cleanData($property['land_use']),
            cleanData($property['nearby_schools'] ? 'Yes' : ''),
            cleanData($property['nearby_hospital'] ? 'Yes' : ''),
            cleanData($property['nearby_market'] ? 'Yes' : ''),
            cleanData($property['nearby_university'] ? 'Yes' : ''),
            cleanData($property['zoning_landtype']),
            cleanData($property['nearby_amenities']),
            cleanData($property['distance_to_city_center']),
            cleanData($property['predicted_price']),
            cleanData($property['confidence_score']),
            cleanData($property['prediction_date']),
            cleanData($property['development_status']),
            cleanData($property['price_category']),
            cleanData($property['confidence_category']),
            cleanData($property['price_difference']),
            cleanData($property['accuracy_percentage']),
            cleanData($property['conservative_10yr_projection']),
            cleanData($property['moderate_10yr_projection']),
            cleanData($property['aggressive_10yr_projection'])
        ]);
    }

    // Close the output stream
    fclose($output);
    exit;
}

// Generate PDF export
elseif ($export_type === 'pdf') {
    // Include TCPDF library
    require_once('../TCPDF/tcpdf.php');
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('Land Price Estimation System');
    $pdf->SetAuthor($_SESSION['username']);
    $pdf->SetTitle('Portfolio Report - ' . $_SESSION['username']);
    $pdf->SetSubject('Portfolio Analysis Report');
    
    // Set default header data
    $pdf->SetHeaderData('', 0, 'Portfolio Report', $_SESSION['username'] . ' - ' . date('Y-m-d'));
    
    // Set header and footer fonts
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    
    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    
    // Set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    
    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    
    // Set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
    
    // Add a page
    $pdf->AddPage();
    
    // Get data
    $properties = getUserCompletePortfolioData($conn, $user_id);
    $stats = getUserPortfolioStats($conn, $user_id);
    $locations = getUserLocationSummary($conn, $user_id);
    
    // Portfolio Summary
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Portfolio Summary', 0, 1, 'L');
    $pdf->Ln(5);
    
    $pdf->SetFont('helvetica', '', 10);
    $summaryData = [
        'Total Properties' => $stats['total_properties'],
        'Total Portfolio Value' => 'RWF ' . number_format($stats['total_value'], 0),
        'Average Property Price' => 'RWF ' . number_format($stats['avg_price'], 0),
        'Average Confidence Score' => number_format($stats['avg_confidence'], 1) . '%',
        'Properties with Water' => $stats['properties_with_water'],
        'Properties with Electricity' => $stats['properties_with_electricity'],
        'Properties with Road Access' => $stats['properties_with_road_access']
    ];
    
    foreach ($summaryData as $label => $value) {
        $pdf->Cell(60, 8, $label . ':', 0, 0);
        $pdf->Cell(0, 8, $value, 0, 1);
    }
    
    $pdf->Ln(10);
    
    // Location Summary
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Location Summary', 0, 1, 'L');
    $pdf->Ln(5);
    
    $pdf->SetFont('helvetica', '', 9);
    $pdf->Cell(40, 8, 'Location', 1);
    $pdf->Cell(25, 8, 'Count', 1);
    $pdf->Cell(35, 8, 'Avg Price', 1);
    $pdf->Cell(35, 8, 'Total Value', 1);
    $pdf->Cell(25, 8, 'Confidence', 1);
    $pdf->Ln();
    
    foreach ($locations as $location) {
        $pdf->Cell(40, 8, $location['location'], 1);
        $pdf->Cell(25, 8, $location['property_count'], 1);
        $pdf->Cell(35, 8, 'RWF ' . number_format($location['avg_price'], 0), 1);
        $pdf->Cell(35, 8, 'RWF ' . number_format($location['total_value'], 0), 1);
        $pdf->Cell(25, 8, number_format($location['avg_confidence'], 1) . '%', 1);
        $pdf->Ln();
    }
    
    $pdf->Ln(10);
    
    // Properties Table
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Property Details', 0, 1, 'L');
    $pdf->Ln(5);
    
    $pdf->SetFont('helvetica', '', 8);
    $pdf->Cell(15, 8, 'ID', 1);
    $pdf->Cell(30, 8, 'Location', 1);
    $pdf->Cell(20, 8, 'Size', 1);
    $pdf->Cell(25, 8, 'Est. Price', 1);
    $pdf->Cell(25, 8, 'Pred. Price', 1);
    $pdf->Cell(20, 8, 'Confidence', 1);
    $pdf->Cell(25, 8, 'Status', 1);
    $pdf->Cell(25, 8, 'Category', 1);
    $pdf->Ln();
    
    foreach ($properties as $property) {
        $pdf->Cell(15, 8, $property['id'], 1);
        $pdf->Cell(30, 8, $property['location'], 1);
        $pdf->Cell(20, 8, $property['size_sqm'] . ' sqm', 1);
        $pdf->Cell(25, 8, 'RWF ' . number_format($property['estimated_price'], 0), 1);
        $pdf->Cell(25, 8, $property['predicted_price'] ? 'RWF ' . number_format($property['predicted_price'], 0) : '', 1);
        $pdf->Cell(20, 8, $property['confidence_score'] ? number_format($property['confidence_score'], 1) . '%' : '', 1);
        $pdf->Cell(25, 8, $property['development_status'], 1);
        $pdf->Cell(25, 8, $property['price_category'], 1);
        $pdf->Ln();
    }
    
    // Add charts (simplified text-based representation)
    $pdf->AddPage();
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Portfolio Charts', 0, 1, 'L');
    $pdf->Ln(10);
    
    // Price Distribution Chart
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Price Distribution', 0, 1, 'L');
    $pdf->Ln(5);
    
    $priceRanges = [];
    foreach ($properties as $property) {
        $range = $property['price_category'];
        if (!isset($priceRanges[$range])) {
            $priceRanges[$range] = 0;
        }
        $priceRanges[$range]++;
    }
    
    $pdf->SetFont('helvetica', '', 10);
    foreach ($priceRanges as $range => $count) {
        $percentage = ($count / count($properties)) * 100;
        $pdf->Cell(40, 8, $range, 0, 0);
        $pdf->Cell(20, 8, $count . ' (' . number_format($percentage, 1) . '%)', 0, 1);
    }
    
    $pdf->Ln(10);
    
    // Development Status Chart
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Development Status', 0, 1, 'L');
    $pdf->Ln(5);
    
    $devStatus = [];
    foreach ($properties as $property) {
        $status = $property['development_status'];
        if (!isset($devStatus[$status])) {
            $devStatus[$status] = 0;
        }
        $devStatus[$status]++;
    }
    
    $pdf->SetFont('helvetica', '', 10);
    foreach ($devStatus as $status => $count) {
        $percentage = ($count / count($properties)) * 100;
        $pdf->Cell(50, 8, $status, 0, 0);
        $pdf->Cell(20, 8, $count . ' (' . number_format($percentage, 1) . '%)', 0, 1);
    }
    
    // Output PDF
    $pdf->Output('portfolio_' . $_SESSION['username'] . '_' . date('Y-m-d') . '.pdf', 'D');
    exit;
}

// Default redirect
else {
    header('Location: dashboard.php');
    exit;
}
?> 