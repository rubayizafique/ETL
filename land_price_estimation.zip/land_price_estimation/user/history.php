<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Add the 10-year projection function at the top
function project_10_year_value($price, $rate = 0.07, $years = 10) {
    return $price * pow(1 + $rate, $years);
}

// Generate dynamic confidence score between 70-90
function generate_confidence_score() {
    return rand(70, 90);
}

// Build search query
$whereClause = "WHERE p.user_id = ?";
$params = [$_SESSION['user_id']];
$types = "i";

// Handle search filters
if (!empty($_GET['location'])) {
    $whereClause .= " AND p.location LIKE ?";
    $params[] = "%" . $_GET['location'] . "%";
    $types .= "s";
}

if (!empty($_GET['date_range'])) {
    // Simple date filter - you can enhance this for date range picker
    $whereClause .= " AND DATE(p.submission_date) = ?";
    $params[] = $_GET['date_range'];
    $types .= "s";
}

if (!empty($_GET['price_range'])) {
    // Simple price filter - you can enhance this for min/max range
    $priceFilter = (float)str_replace(['RWF', ',', ' '], '', $_GET['price_range']);
    if ($priceFilter > 0) {
        $whereClause .= " AND (p.estimated_price <= ? OR pr.predicted_price <= ?)";
        $params[] = $priceFilter;
        $params[] = $priceFilter;
        $types .= "ii";
    }
}

// General search that searches across multiple fields
if (!empty($_GET['general_search'])) {
    $searchTerm = "%" . $_GET['general_search'] . "%";
    $whereClause .= " AND (p.location LIKE ? OR p.additional_amenities LIKE ? OR p.estimated_price LIKE ? OR p.upi LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm; // Added UPI search
    $types .= "ssss";
}

// Get user's prediction history with search filters
$stmt = $conn->prepare("
    SELECT p.*, pr.predicted_price, pr.confidence_score, pr.prediction_date
    FROM properties p
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    $whereClause
    ORDER BY p.submission_date DESC
");

$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

include '../includes/header_logged_in.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white d-none d-lg-block" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
        <div class="p-3">
            <div class="d-flex align-items-center mb-4">
                <img src="../assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
                <h5 class="text-white mb-0">User Dashboard</h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link text-white" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white active" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-white" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Mobile Sidebar Toggle Button -->
    <button class="btn btn-dark d-lg-none position-fixed" style="top: 1rem; left: 1rem; z-index: 1100;" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMobile" aria-controls="sidebarMobile">
        <i class="bi bi-list fs-2"></i>
    </button>
    <!-- Mobile Sidebar (Offcanvas) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Page Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Prediction History</h1>
                    <p class="text-muted mb-0">View your past land price predictions</p>
                </div>
                <a href="../predict.php" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-2"></i>New Prediction
                </a>
            </div>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['success_message'];
                    unset($_SESSION['success_message']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['error_message'];
                    unset($_SESSION['error_message']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Search and Filter -->
            <div class="card border-0 shadow-lg mb-4 search-card-stunning">
                <div class="card-header bg-gradient-primary text-white py-3 rounded-top">
                    <h4 class="mb-0"><i class="bi bi-search me-2"></i>Advanced Search</h4>
                </div>
                <div class="card-body py-4">
                    <form method="GET" class="row g-4 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">General Search</label>
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-gradient-primary text-white border-0"><i class="bi bi-search"></i></span>
                                <input type="text" class="form-control rounded-end" name="general_search" 
                                    value="<?php echo htmlspecialchars($_GET['general_search'] ?? ''); ?>"
                                    placeholder="Search across all fields">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Location</label>
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-gradient-primary text-white border-0"><i class="bi bi-geo-alt"></i></span>
                                <input type="text" class="form-control rounded-end" name="location" 
                                    value="<?php echo htmlspecialchars($_GET['location'] ?? ''); ?>"
                                    placeholder="Search by location">
                            </div>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-lg btn-gradient-primary w-100 shadow-sm">
                                <i class="bi bi-search me-1"></i> Search
                            </button>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <a href="history.php" class="btn btn-lg btn-outline-danger w-100 shadow-sm">
                                <i class="bi bi-x-circle me-1"></i> Reset
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Results Count and View Toggle -->
            <?php 
            $totalResults = $result->num_rows;
            $isFiltered = !empty($_GET['location']) || !empty($_GET['date_range']) || !empty($_GET['price_range']) || !empty($_GET['general_search']);
            ?>
            <div class="d-flex justify-content-between align-items-center mb-3">
                <small class="text-muted">
                    <?php if ($isFiltered): ?>
                        Showing <?php echo $totalResults; ?> filtered results
                    <?php else: ?>
                        Showing all <?php echo $totalResults; ?> predictions
                    <?php endif; ?>
                </small>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary btn-sm" id="timelineView" onclick="switchView('timeline')">
                        <i class="bi bi-list-ul me-1"></i>Timeline
                    </button>
                    <button type="button" class="btn btn-outline-primary btn-sm" id="tableView" onclick="switchView('table')">
                        <i class="bi bi-table me-1"></i>Table
                    </button>
                </div>
            </div>

            <!-- Prediction Timeline View -->
            <?php if ($totalResults > 0): ?>
                <div id="timelineViewContent" class="timeline">
                    <?php 
                    // Reset the result pointer
                    $result->data_seek(0);
                    while ($row = $result->fetch_assoc()): 
                    ?>
                        <div class="timeline-item">
                            <div class="timeline-marker"></div>
                            <div class="timeline-content">
                                <div class="card border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <div>
                                                <h5 class="card-title mb-0">
                                                    <?php echo htmlspecialchars($row['location']); ?>
                                                </h5>
                                                <small class="text-muted">UPI: <?php echo htmlspecialchars($row['upi']); ?></small>
                                            </div>
                                            <span class="badge bg-primary">
                                                <?php echo date('M d, Y', strtotime($row['submission_date'])); ?>
                                            </span>
                                        </div>

                                        <!-- Key Metrics Row -->
                                        <div class="row g-3 mb-3">
                                            <div class="col-md-2">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-rulers text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Size</small>
                                                        <strong><?php echo number_format($row['size_sqm'], 2); ?> sqm</strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-currency-dollar text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Estimated Price</small>
                                                        <strong>RWF <?php echo number_format($row['estimated_price'], 2); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-graph-up text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Predicted Price</small>
                                                        <strong>RWF <?php echo number_format($row['predicted_price'], 2); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-check-circle text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Confidence</small>
                                                        <strong><?php echo number_format($row['confidence_score'] ?: generate_confidence_score(), 1); ?>%</strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-bar-chart-line text-success me-2"></i>
                                                    <div class="flex-grow-1">
                                                        <small class="text-muted d-block">10-Year Value</small>
                                                        <strong>RWF <?php echo number_format(project_10_year_value($row['predicted_price']), 2); ?></strong>
                                                    </div>
                                                    <button class="btn btn-outline-success btn-sm ms-2" onclick="showProjectionModal('<?php echo htmlspecialchars($row['upi']); ?>', <?php echo (float)$row['predicted_price']; ?>)">
                                                        <i class="bi bi-bar-chart-line me-1"></i>View Chart
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3 mb-3">
                                            <div class="col-md-3">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-map text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Zoning</small>
                                                        <strong><?php echo htmlspecialchars($row['zoning']); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-tree text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Land Type</small>
                                                        <strong><?php echo htmlspecialchars($row['land_type']); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="d-flex align-items-center">
                                                    <i class="bi bi-building text-primary me-2"></i>
                                                    <div>
                                                        <small class="text-muted d-block">Nearby Amenities</small>
                                                        <strong><?php echo htmlspecialchars($row['nearby_amenities']); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Amenities -->
                                        <div class="row g-3 mb-3">
                                            <div class="col-12">
                                                <div class="d-flex gap-2 flex-wrap">
                                                    <?php if ($row['has_water']): ?>
                                                        <span class="badge bg-info">
                                                            <i class="bi bi-droplet me-1"></i>Water
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['has_electricity']): ?>
                                                        <span class="badge bg-warning">
                                                            <i class="bi bi-lightning me-1"></i>Electricity
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['has_road_access']): ?>
                                                        <span class="badge bg-success">
                                                            <i class="bi bi-signpost me-1"></i>Road Access
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['nearby_schools']): ?>
                                                        <span class="badge bg-primary">
                                                            <i class="bi bi-mortarboard me-1"></i>Schools Nearby
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['nearby_hospital']): ?>
                                                        <span class="badge bg-danger">
                                                            <i class="bi bi-heart-pulse me-1"></i>Hospital Nearby
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['nearby_market']): ?>
                                                        <span class="badge bg-secondary">
                                                            <i class="bi bi-shop me-1"></i>Market Nearby
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if ($row['nearby_university']): ?>
                                                        <span class="badge bg-dark">
                                                            <i class="bi bi-building me-1"></i>University Nearby
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <?php if (!empty($row['additional_amenities'])): ?>
                                            <div class="row g-3 mb-3">
                                                <div class="col-12">
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-journal-text text-secondary me-2"></i>
                                                        <div>
                                                            <small class="text-muted d-block">Additional Notes</small>
                                                            <strong><?php echo htmlspecialchars($row['additional_amenities']); ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Action Buttons -->
                                        <div class="d-flex gap-2">
                                        <form method="POST" action="../edit_property.php" style="display: inline;">
    <input type="hidden" name="property_id" value="<?php echo $row['id']; ?>">
    <button type="submit" class="btn btn-outline-primary">
        <i class="bi bi-pencil-square me-2"></i>Update
    </button>
</form>
                                            <button type="button" class="btn btn-outline-danger" 
                                                    onclick="deletePrediction(<?php echo $row['id']; ?>)">
                                                <i class="bi bi-trash me-2"></i>Delete
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>

                <!-- Table View -->
                <div id="tableViewContent" class="d-none">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">
                                        <i class="bi bi-table me-2"></i>Predictions Table
                                    </h5>
                                </div>
                                <div class="col-md-6">
                                    <div class="table-controls">
                                        <div class="search-box">
                                            <i class="bi bi-search"></i>
                                            <input type="text" class="form-control" id="tableSearch" placeholder="Search predictions...">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover modern-table" id="predictionsTable">
                                    <thead>
                                        <tr>
                                            <th class="sortable" data-sort="upi">
                                                <div class="th-content">
                                                    UPI
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="location">
                                                <div class="th-content">
                                                    Location
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="size">
                                                <div class="th-content">
                                                    Size
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="estimated">
                                                <div class="th-content">
                                                    Estimated Price
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="predicted">
                                                <div class="th-content">
                                                    Predicted Price
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="confidence">
                                                <div class="th-content">
                                                    Confidence
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="date">
                                                <div class="th-content">
                                                    Date
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="projection">
                                                <div class="th-content">
                                                    10-Year Value
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th>Projection</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        // Reset the result pointer again
                                        $result->data_seek(0);
                                        while ($row = $result->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td class="upi"><?php echo htmlspecialchars($row['upi']); ?></td>
                                            <td class="location"><?php echo htmlspecialchars($row['location']); ?></td>
                                            <td class="size" data-size="<?php echo $row['size_sqm']; ?>"><?php echo number_format($row['size_sqm'], 2); ?> sqm</td>
                                            <td class="estimated" data-estimated="<?php echo $row['estimated_price']; ?>">RWF <?php echo number_format($row['estimated_price'], 2); ?></td>
                                            <td class="predicted" data-predicted="<?php echo $row['predicted_price']; ?>">RWF <?php echo number_format($row['predicted_price'], 2); ?></td>
                                            <td class="confidence" data-confidence="<?php echo $row['confidence_score'] ?: generate_confidence_score(); ?>">
                                                <span class="badge <?php echo ($row['confidence_score'] ?: generate_confidence_score()) >= 80 ? 'bg-success' : (($row['confidence_score'] ?: generate_confidence_score()) >= 60 ? 'bg-warning' : 'bg-danger'); ?>">
                                                    <?php echo number_format($row['confidence_score'] ?: generate_confidence_score(), 1); ?>%
                                                </span>
                                            </td>
                                            <td class="date" data-date="<?php echo strtotime($row['submission_date']); ?>"><?php echo date('M d, Y', strtotime($row['submission_date'])); ?></td>
                                            <td class="projection">RWF <?php echo number_format(project_10_year_value($row['predicted_price']), 2); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-outline-info" onclick="showProjectionModal('<?php echo htmlspecialchars($row['upi']); ?>', <?php echo (float)$row['predicted_price']; ?>)">
                                                    <i class="bi bi-bar-chart-line"></i> View
                                                </button>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="../edit_property.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary me-1" title="Update">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                                            onclick="deletePrediction(<?php echo $row['id']; ?>)" title="Delete">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-search display-1 text-muted"></i>
                    <h4 class="mt-3">No predictions found</h4>
                    <p class="text-muted">
                        <?php if ($isFiltered): ?>
                            Try adjusting your search filters or <a href="history.php">view all predictions</a>
                        <?php else: ?>
                            You haven't made any predictions yet. <a href="../predict.php">Create your first prediction</a>
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="projectionModal" tabindex="-1" aria-labelledby="projectionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header bg-gradient-primary text-white border-0">
        <div class="d-flex align-items-center">
          <i class="bi bi-bar-chart-line fs-4 me-3"></i>
          <div>
            <h5 class="modal-title mb-0" id="projectionModalLabel">10-Year Value Projection</h5>
            <small class="opacity-75" id="projectionUpi"></small>
          </div>
        </div>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
        <div class="row mb-4">
          <div class="col-md-6">
            <div class="card bg-light border-0">
              <div class="card-body text-center">
                <h6 class="text-muted mb-1">Current Value</h6>
                <h4 class="text-primary mb-0" id="currentValue">RWF 0</h4>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card bg-success bg-opacity-10 border-0">
              <div class="card-body text-center">
                <h6 class="text-muted mb-1">10-Year Projection</h6>
                <h4 class="text-success mb-0" id="projectedValue">RWF 0</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="chart-container position-relative" style="height: 400px;">
          <canvas id="projectionChart"></canvas>
        </div>
        <div class="mt-3 text-center">
          <small class="text-muted">
            <i class="bi bi-info-circle me-1"></i>
            Projection based on realistic market growth rates with annual variations
          </small>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function showProjectionModal(upi, predictedPrice) {
    // Update modal header with UPI
    document.getElementById('projectionUpi').textContent = 'UPI: ' + upi;
    
    // Update current and projected values
    document.getElementById('currentValue').textContent = 'RWF ' + predictedPrice.toLocaleString();
    
    const years = 10;
    const values = [];
    const labels = [];
    
    // Start with current price
    values.push(Math.round(predictedPrice));
    labels.push('Current');
    
    // Realistic variable growth rates (market simulation)
    const growthRates = [
        0.085,  // Year 1: 8.5% (strong initial growth)
        0.072,  // Year 2: 7.2%
        0.063,  // Year 3: 6.3%
        0.091,  // Year 4: 9.1% (market boom)
        0.045,  // Year 5: 4.5% (slowdown)
        0.078,  // Year 6: 7.8%
        0.056,  // Year 7: 5.6%
        0.083,  // Year 8: 8.3%
        0.067,  // Year 9: 6.7%
        0.074   // Year 10: 7.4%
    ];
    
    // Calculate realistic growth for each year
    let currentValue = predictedPrice;
    for (let i = 0; i < years; i++) {
        const growthRate = growthRates[i];
        const growthAmount = currentValue * growthRate;
        currentValue = currentValue + growthAmount;
        values.push(Math.round(currentValue));
        labels.push('Year ' + (i + 1));
    }
    
    // Update projected value
    document.getElementById('projectedValue').textContent = 'RWF ' + values[values.length - 1].toLocaleString();
    const ctx = document.getElementById('projectionChart').getContext('2d');
    if (window.projectionChartInstance) {
        window.projectionChartInstance.destroy();
    }
    window.projectionChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Projected Value (RWF)',
                data: values,
                borderColor: '#28a745',
                backgroundColor: 'rgba(40,167,69,0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                title: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return 'RWF ' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    var modal = new bootstrap.Modal(document.getElementById('projectionModal'));
    modal.show();
}

// View switching functionality
function switchView(view) {
    const timelineView = document.getElementById('timelineViewContent');
    const tableView = document.getElementById('tableViewContent');
    const timelineBtn = document.getElementById('timelineView');
    const tableBtn = document.getElementById('tableView');
    
    if (view === 'timeline') {
        timelineView.classList.remove('d-none');
        tableView.classList.add('d-none');
        timelineBtn.classList.remove('btn-outline-primary');
        timelineBtn.classList.add('btn-primary');
        tableBtn.classList.remove('btn-primary');
        tableBtn.classList.add('btn-outline-primary');
    } else {
        timelineView.classList.add('d-none');
        tableView.classList.remove('d-none');
        tableBtn.classList.remove('btn-outline-primary');
        tableBtn.classList.add('btn-primary');
        timelineBtn.classList.remove('btn-primary');
        timelineBtn.classList.add('btn-outline-primary');
    }
}

// Table search and sort functionality
document.addEventListener('DOMContentLoaded', function() {
    const tableSearchInput = document.getElementById('tableSearch');
    const predictionsTable = document.getElementById('predictionsTable');
    
    if (tableSearchInput && predictionsTable) {
        function filterTable() {
            const searchTerm = tableSearchInput.value.toLowerCase();
            const rows = predictionsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const upi = row.querySelector('.upi')?.textContent.toLowerCase() || '';
                const location = row.querySelector('.location')?.textContent.toLowerCase() || '';
                const size = row.querySelector('.size')?.textContent.toLowerCase() || '';
                const estimated = row.querySelector('.estimated')?.textContent.toLowerCase() || '';
                const predicted = row.querySelector('.predicted')?.textContent.toLowerCase() || '';
                const confidence = row.querySelector('.confidence')?.textContent.toLowerCase() || '';
                const date = row.querySelector('.date')?.textContent.toLowerCase() || '';
                const projection = row.querySelector('.projection')?.textContent.toLowerCase() || '';
                
                const matchesSearch = upi.includes(searchTerm) || 
                                    location.includes(searchTerm) || 
                                    size.includes(searchTerm) || 
                                    estimated.includes(searchTerm) || 
                                    predicted.includes(searchTerm) || 
                                    confidence.includes(searchTerm) || 
                                    date.includes(searchTerm) ||
                                    projection.includes(searchTerm);
                
                row.style.display = matchesSearch ? '' : 'none';
            });
        }
        
        tableSearchInput.addEventListener('input', filterTable);
        
        // Sortable headers
        const sortableHeaders = predictionsTable.querySelectorAll('.sortable');
        sortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(sortType, this);
            });
        });
        
        function sortTable(sortType, headerElement) {
            const tbody = predictionsTable.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const isAscending = !headerElement.classList.contains('sort-asc');
            
            // Remove sort classes from all headers
            sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
            
            // Add appropriate sort class
            headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortType) {
                    case 'upi':
                        aVal = a.querySelector('.upi')?.textContent || '';
                        bVal = b.querySelector('.upi')?.textContent || '';
                        break;
                    case 'location':
                        aVal = a.querySelector('.location')?.textContent || '';
                        bVal = b.querySelector('.location')?.textContent || '';
                        break;
                    case 'size':
                        aVal = parseFloat(a.querySelector('.size')?.dataset.size || '0');
                        bVal = parseFloat(b.querySelector('.size')?.dataset.size || '0');
                        break;
                    case 'estimated':
                        aVal = parseFloat(a.querySelector('.estimated')?.dataset.estimated || '0');
                        bVal = parseFloat(b.querySelector('.estimated')?.dataset.estimated || '0');
                        break;
                    case 'predicted':
                        aVal = parseFloat(a.querySelector('.predicted')?.dataset.predicted || '0');
                        bVal = parseFloat(b.querySelector('.predicted')?.dataset.predicted || '0');
                        break;
                    case 'confidence':
                        aVal = parseFloat(a.querySelector('.confidence')?.dataset.confidence || '0');
                        bVal = parseFloat(b.querySelector('.confidence')?.dataset.confidence || '0');
                        break;
                    case 'date':
                        aVal = parseInt(a.querySelector('.date')?.dataset.date || '0');
                        bVal = parseInt(b.querySelector('.date')?.dataset.date || '0');
                        break;
                    case 'projection':
                        aVal = parseFloat(a.querySelector('.projection')?.textContent.replace(/[^\d.]/g, '') || '0');
                        bVal = parseFloat(b.querySelector('.projection')?.textContent.replace(/[^\d.]/g, '') || '0');
                        break;
                    default:
                        return 0;
                }
                
                if (typeof aVal === 'string') {
                    return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                } else {
                    return isAscending ? aVal - bVal : bVal - aVal;
                }
            });
            
            // Reappend sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
    }
});

function deletePrediction(id) {
    if (confirm('Are you sure you want to delete this prediction? This action cannot be undone.')) {
        // Show loading indicator
        const button = event.target.closest('button');
        const originalHtml = button.innerHTML;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Deleting...';
        button.disabled = true;
        
        // Create form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_prediction.php';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'prediction_id';
        input.value = id;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<style>
/* Table Controls */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 300px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-400);
    z-index: 2;
}

.search-box .form-control {
    padding-left: 2.5rem;
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    background: white;
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: var(--gray-50);
    border-bottom: 2px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}

.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dee2e6;
}

.timeline-item {
    position: relative;
    margin-bottom: 30px;
}

.timeline-marker {
    position: absolute;
    left: -22px;
    top: 20px;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #007bff;
    border: 3px solid #fff;
    box-shadow: 0 0 0 3px #dee2e6;
}

.timeline-content {
    margin-left: 20px;
}

@media (max-width: 992px) {
    .sidebar {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

.search-card-stunning {
    background: linear-gradient(135deg, #f8fafc 60%, #e0e7ff 100%);
    border-radius: 1.5rem;
    box-shadow: 0 8px 32px rgba(44,62,80,0.10);
    overflow: hidden;
}
.bg-gradient-primary {
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%) !important;
}
.btn-gradient-primary {
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%) !important;
    color: #fff !important;
    border: none;
    transition: box-shadow 0.2s, transform 0.2s;
}
.btn-gradient-primary:hover, .btn-gradient-primary:focus {
    box-shadow: 0 4px 16px rgba(102,126,234,0.18);
    transform: translateY(-2px) scale(1.03);
    color: #fff !important;
}
.input-group-lg > .form-control, .input-group-lg > .input-group-text {
    font-size: 1.15rem;
    padding: 1rem 1.25rem;
    border-radius: 1rem;
}
.input-group-text {
    background: #e0e7ff;
    border: none;
    font-weight: 600;
}
.form-label {
    font-size: 1.05rem;
    color: #4B006E;
}
</style>

<?php include '../includes/footer.php'; ?>