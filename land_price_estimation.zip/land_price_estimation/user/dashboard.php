<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Get user's properties with predictions (only those with a prediction)
$stmt = $conn->prepare("
    SELECT p.*, pr.predicted_price, pr.confidence_score, pr.prediction_date
    FROM properties p
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    WHERE p.user_id = ?
    ORDER BY p.submission_date DESC
");

if ($stmt === false) {
    $stmt = $conn->prepare("
        SELECT p.*, 
               p.estimated_price as predicted_price,
               0 as confidence_score,
               p.submission_date as prediction_date,
               '' as market_trends,
               '' as future_projections
        FROM properties p
        WHERE p.user_id = ?
        ORDER BY p.submission_date DESC
    ");
}

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$properties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT p.id) as total_properties,
        AVG(p.estimated_price) as avg_price,
        SUM(p.estimated_price) as total_value,
        MAX(COALESCE(pr.confidence_score, 0)) as highest_confidence,
        MIN(p.estimated_price) as min_price,
        MAX(p.estimated_price) as max_price
    FROM properties p
    LEFT JOIN predictions pr ON p.id = pr.property_id
    WHERE p.user_id = ?
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get price trends for the last 12 months
$stmt = $conn->prepare("
    SELECT DATE_FORMAT(COALESCE(pr.prediction_date, p.submission_date), '%Y-%m') as month,
           AVG(COALESCE(pr.predicted_price, p.estimated_price)) as avg_price,
           COUNT(*) as property_count
    FROM properties p
    LEFT JOIN predictions pr ON p.id = pr.property_id
    WHERE p.user_id = ?
    AND COALESCE(pr.prediction_date, p.submission_date) >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(COALESCE(pr.prediction_date, p.submission_date), '%Y-%m')
    ORDER BY month ASC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$price_trends = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get location distribution
$stmt = $conn->prepare("
    SELECT location, 
           COUNT(*) as count,
           AVG(estimated_price) as avg_price,
           SUM(estimated_price) as total_value
    FROM properties
    WHERE user_id = ?
    GROUP BY location
    ORDER BY count DESC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$locations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get min and max price for this user
$minMaxStmt = $conn->prepare("SELECT MIN(estimated_price) as min_price, MAX(estimated_price) as max_price FROM properties WHERE user_id = ?");
$minMaxStmt->bind_param("i", $_SESSION['user_id']);
$minMaxStmt->execute();
$minMax = $minMaxStmt->get_result()->fetch_assoc();
$min_price = (int)$minMax['min_price'];
$max_price = (int)$minMax['max_price'];

$bin_count = 5;
$bin_size = ($max_price - $min_price) / $bin_count;
$bins = [];
$labels = [];
for ($i = 0; $i < $bin_count; $i++) {
    $start = round($min_price + $i * $bin_size);
    $end = round($min_price + ($i + 1) * $bin_size);
    $labels[] = "RWF " . number_format($start) . " - RWF " . number_format($end);
    $bins[] = ["min" => $start, "max" => $end];
}

$price_ranges = [];
foreach ($bins as $idx => $bin) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE user_id = ? AND estimated_price >= ? AND estimated_price < ?");
    $stmt->bind_param("iii", $_SESSION['user_id'], $bin['min'], $bin['max']);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $price_ranges[] = [
        'price_range' => $labels[$idx],
        'count' => $result['count']
    ];
}

// Get confidence score distribution
$stmt = $conn->prepare("
    SELECT 
        CASE 
            WHEN COALESCE(pr.confidence_score, 0) < 60 THEN 'Low (0-59%)'
            WHEN COALESCE(pr.confidence_score, 0) BETWEEN 60 AND 79 THEN 'Medium (60-79%)'
            WHEN COALESCE(pr.confidence_score, 0) BETWEEN 80 AND 89 THEN 'High (80-89%)'
            ELSE 'Very High (90%+)'
        END as confidence_range,
        COUNT(*) as count
    FROM properties p
    LEFT JOIN predictions pr ON p.id = pr.property_id
    WHERE p.user_id = ?
    GROUP BY confidence_range
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$confidence_distribution = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get size vs price correlation data
$stmt = $conn->prepare("
    SELECT size_sqm, estimated_price, location
    FROM properties 
    WHERE user_id = ?
    ORDER BY size_sqm ASC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$size_price_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get monthly property additions
$stmt = $conn->prepare("
    SELECT DATE_FORMAT(submission_date, '%Y-%m') as month,
           COUNT(*) as count
    FROM properties 
    WHERE user_id = ?
    AND submission_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(submission_date, '%Y-%m')
    ORDER BY month ASC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$monthly_additions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get all prices for this user
$prices = [];
$stmt = $conn->prepare("SELECT estimated_price FROM properties WHERE user_id = ? AND estimated_price IS NOT NULL ORDER BY estimated_price ASC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $prices[] = (int)$row['estimated_price'];
}

$price_ranges = [];
if (count($prices) > 0) {
    $quantiles = [];
    $n = count($prices);
    for ($i = 0; $i <= 5; $i++) {
        $q = $i / 5;
        $idx = (int)round($q * ($n - 1));
        $quantiles[] = $prices[$idx];
    }
    $labels = [];
    for ($i = 0; $i < 5; $i++) {
        if ($i == 0) {
            $labels[] = 'Under RWF ' . number_format($quantiles[$i+1]);
        } elseif ($i == 4) {
            $labels[] = 'Over RWF ' . number_format($quantiles[$i]);
        } else {
            $labels[] = 'RWF ' . number_format($quantiles[$i]) . ' - RWF ' . number_format($quantiles[$i+1]);
        }
    }
    for ($i = 0; $i < 5; $i++) {
        if ($i == 0) {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE user_id = ? AND estimated_price < ?");
            $stmt->bind_param("ii", $_SESSION['user_id'], $quantiles[$i+1]);
        } elseif ($i == 4) {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE user_id = ? AND estimated_price >= ?");
            $stmt->bind_param("ii", $_SESSION['user_id'], $quantiles[$i]);
        } else {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE user_id = ? AND estimated_price >= ? AND estimated_price < ?");
            $stmt->bind_param("iii", $_SESSION['user_id'], $quantiles[$i], $quantiles[$i+1]);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $price_ranges[] = [
            'price_range' => $labels[$i],
            'count' => $result['count']
        ];
    }
}

include '../includes/header_logged_in.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white d-none d-lg-block" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
        <div class="p-3">
            <div class="d-flex align-items-center mb-4">
                <img src="../assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
                <h5 class="text-white mb-0">My Dashboard</h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link text-white active" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-white" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Mobile Sidebar Toggle Button -->
    <button class="btn btn-dark d-lg-none position-fixed" style="top: 1rem; left: 1rem; z-index: 1100;" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMobile" aria-controls="sidebarMobile">
        <i class="bi bi-list fs-2"></i>
    </button>
    <!-- Mobile Sidebar (Offcanvas) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Welcome Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Welcome Back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
                    <p class="text-muted mb-0">Here's an overview of your land predictions and portfolio analytics</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="../predict.php" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>New Prediction
                    </a>
                    <button class="btn btn-outline-secondary" onclick="downloadReport()">
                        <i class="bi bi-download me-2"></i>Export Report
                    </button>
                </div>
            </div>

            <!-- Enhanced Statistics Cards -->
            <div class="row g-4 mb-4">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-primary bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-map text-primary fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Total Properties</h6>
                            <h4 class="mb-0 text-primary"><?php echo number_format($stats['total_properties']); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-success bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-cash text-success fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Portfolio Value</h6>
                            <h4 class="mb-0 text-success">RWF <?php echo number_format($stats['total_value'], 0); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-info bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-graph-up text-info fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Average Price</h6>
                            <h4 class="mb-0 text-info">RWF <?php echo number_format($stats['avg_price'], 0); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-warning bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-shield-check text-warning fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Best Confidence</h6>
                            <h4 class="mb-0 text-warning"><?php echo number_format($stats['highest_confidence'], 1); ?>%</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-danger bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-arrow-up-right text-danger fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Highest Value</h6>
                            <h4 class="mb-0 text-danger">RWF <?php echo number_format($stats['max_price'], 0); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="card border-0 shadow-sm stat-card">
                        <div class="card-body text-center p-3">
                            <div class="stat-icon bg-secondary bg-opacity-10 rounded-circle mx-auto mb-2">
                                <i class="bi bi-arrow-down-right text-secondary fs-4"></i>
                            </div>
                            <h6 class="text-muted mb-1">Lowest Value</h6>
                            <h4 class="mb-0 text-secondary">RWF <?php echo number_format($stats['min_price'], 0); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Price Trends Chart -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-graph-up me-2 text-primary"></i>Price Trends Analysis
                            </h5>
                            
                        </div>
                        <div class="card-body">
                            <canvas id="priceTrendsChart" height="300"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Portfolio Composition -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-pie-chart me-2 text-success"></i>Portfolio by Location
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="locationDistributionChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Secondary Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Price Range Distribution -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-bar-chart me-2 text-info"></i>Price Range Distribution
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="priceRangeChart" height="250"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Confidence Score Distribution -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-speedometer2 me-2 text-warning"></i>Prediction Confidence Levels
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="confidenceDistributionChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 10-Year Prediction Chart -->
            <div class="row g-4 mb-4">
                <div class="col-12">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-graph-up-arrow me-2 text-success"></i>10-Year Value Projection
                            </h5>
                            <div class="d-flex gap-2 align-items-center">
                                <select id="locationFilter" class="form-select form-select-sm" style="width: auto;">
                                    <option value="">All Locations</option>
                                    <?php foreach ($locations as $loc): ?>
                                        <option value="<?php echo htmlspecialchars($loc['location']); ?>">
                                            <?php echo htmlspecialchars($loc['location']); ?> (<?php echo $loc['count']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-secondary active" onclick="updatePredictionChart('conservative')">Conservative</button>
                                    <button class="btn btn-sm btn-outline-secondary" onclick="updatePredictionChart('moderate')">Moderate</button>
                                    <button class="btn btn-sm btn-outline-secondary" onclick="updatePredictionChart('aggressive')">Aggressive</button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <div class="text-center p-3 bg-light rounded">
                                        <h6 class="text-muted mb-1">Current Portfolio Value</h6>
                                        <h4 class="text-success mb-0" id="currentValue">RWF <?php echo number_format($stats['total_value'], 0); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center p-3 bg-light rounded">
                                        <h6 class="text-muted mb-1">10-Year Projection (Moderate)</h6>
                                        <h4 class="text-info mb-0" id="projectedValue">RWF <?php echo number_format($stats['total_value'] * pow(1.07, 10), 0); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center p-3 bg-light rounded">
                                        <h6 class="text-muted mb-1">Potential Growth</h6>
                                        <h4 class="text-warning mb-0" id="growthPotential"><?php echo number_format((pow(1.07, 10) - 1) * 100, 1); ?>%</h4>
                                    </div>
                                </div>
                            </div>
                            <canvas id="predictionChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Analytics Row -->
            <div class="row g-4 mb-4">
                <!-- Size vs Price Scatter Plot -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-scatter-chart me-2 text-purple"></i>Size vs Price Correlation
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="sizePriceScatterChart" height="250"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Monthly Property Additions -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-calendar-plus me-2 text-primary"></i>Monthly Additions
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlyAdditionsChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Properties Table -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-dark text-white border-0">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h5 class="card-title mb-0 text-white fw-bold fs-4">
                                <i class="bi bi-table me-2 text-warning fs-3"></i>Recent Properties
                            </h5>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="table-controls">
                                    <div class="search-box">
                                        <i class="bi bi-search text-warning fw-bold fs-5"></i>
                                        <input type="text" class="form-control search-input-enhanced" id="userDashboardSearch" placeholder="🔍 Search properties by location, size, price...">
                                        <button type="button" class="btn btn-sm btn-outline-warning clear-search-btn" id="clearSearchBtn" style="display: none;">
                                            <i class="bi bi-x fw-bold"></i>
                                        </button>
                                    </div>
                                    <div class="search-results-info" id="searchResultsInfo">
                                        <i class="bi bi-info-circle me-1 text-warning"></i>
                                        <span id="searchResultsText">Showing all properties</span>
                                    </div>
                                </div>
                                <a href="history.php" class="btn btn-sm btn-warning text-dark fw-bold ms-2">
                                    <i class="bi bi-arrow-right me-1"></i>View All
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover modern-table" id="userDashboardTable">
                            <thead class="table-dark">
                                <tr>
                                    <th class="sortable" data-sort="upi">
                                        <div class="th-content">
                                            <i class="bi bi-hash me-1 text-warning"></i>UPI
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="location">
                                        <div class="th-content">
                                            <i class="bi bi-geo-alt me-1 text-warning"></i>Location
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="size">
                                        <div class="th-content">
                                            <i class="bi bi-rulers me-1 text-warning"></i>Size (sqm)
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="price">
                                        <div class="th-content">
                                            <i class="bi bi-currency-dollar me-1 text-warning"></i>Predicted Price
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="confidence">
                                        <div class="th-content">
                                            <i class="bi bi-percent me-1 text-warning"></i>Confidence
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="date">
                                        <div class="th-content">
                                            <i class="bi bi-calendar me-1 text-warning"></i>Date
                                            <i class="bi bi-arrow-down-up sort-icon text-warning"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="actions">
                                        <div class="th-content">
                                            <i class="bi bi-three-dots text-warning"></i>Actions
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $recent_properties = array_slice($properties, 0, 5);
                                foreach ($recent_properties as $property): 
                                ?>
                                <tr>
                                    <td class="upi"><?php echo htmlspecialchars($property['upi']); ?></td>
                                    <td class="location"><?php echo htmlspecialchars($property['location']); ?></td>
                                    <td class="size" data-size="<?php echo $property['size_sqm']; ?>"><?php echo number_format($property['size_sqm'], 2); ?> sqm</td>
                                    <td class="price" data-price="<?php echo $property['predicted_price']; ?>">RWF <?php echo number_format($property['predicted_price'], 2); ?></td>
                                    <td class="confidence" data-confidence="<?php echo $property['confidence_score']; ?>">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress position-relative flex-grow-1" style="height: 18px; background: #f1f1f1; border-radius: 10px; min-width: 100px;">
                                                <div class="progress-bar <?php echo $property['confidence_score'] >= 80 ? 'bg-success' : ($property['confidence_score'] >= 60 ? 'bg-warning' : 'bg-danger'); ?>" 
                                                     role="progressbar"
                                                     style="width: <?php echo $property['confidence_score']; ?>%; border-radius: 10px; font-size: 13px; font-weight: 600;"
                                                     title="Confidence: <?php echo number_format($property['confidence_score'], 1); ?>%">
                                                </div>
                                            </div>
                                            <span class="badge rounded-pill px-3 py-1 fs-6 fw-bold <?php echo $property['confidence_score'] >= 80 ? 'bg-success' : ($property['confidence_score'] >= 60 ? 'bg-warning text-dark' : 'bg-danger'); ?>" title="Confidence: <?php echo number_format($property['confidence_score'], 1); ?>%">
                                                <?php echo number_format($property['confidence_score'], 1); ?>%
                                            </span>
                                        </div>
                                    </td>
                                    <td class="date" data-date="<?php echo strtotime($property['submission_date']); ?>"><?php echo date('M d, Y', strtotime($property['submission_date'])); ?></td>
                                    <td class="actions text-center">
                                        <div class="d-flex justify-content-center gap-2">
                                        <form method="POST" action="../edit_property.php" style="display: inline;">
    <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
    <button type="submit" class="btn btn-icon btn-update" title="Update">
        <i class="bi bi-pencil-square"></i>
    </button>
</form>
                                            <form method="POST" action="../delete_property.php" style="display:inline;">
                                                <input type="hidden" name="id" value="<?php echo $property['id']; ?>">
                                                <button type="submit" class="btn btn-icon btn-delete" onclick="return confirm('Are you sure you want to delete this property?');" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Enhanced Card Styles */
.card {
    transition: all 0.3s ease-in-out;
    border-radius: 12px;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1) !important;
}

/* Enhanced header styling for better visibility */
.card-header.bg-dark {
    background: linear-gradient(135deg, #343a40 0%, #495057 100%) !important;
    border-bottom: 3px solid #ffc107;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.card-header.bg-dark .card-title {
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    letter-spacing: 0.5px;
}

.card-header.bg-dark .text-warning {
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
}

.stat-card:hover {
    transform: translateY(-5px);
}

.chart-card {
    background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
}

.stat-icon {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Color scheme enhancements */
.text-purple {
    color: #6f42c1 !important;
}

.bg-purple {
    background-color: #6f42c1 !important;
}

/* Table Controls - Enhanced Visibility */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 350px;
    min-width: 250px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.8);
    z-index: 2;
    font-size: 1.1rem;
}

.search-input-enhanced {
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    border-radius: 25px;
    border: 3px solid #ffc107;
    background: #ffffff;
    color: #000;
    font-weight: 700;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    font-size: 16px;
    text-shadow: none;
}

.search-input-enhanced::placeholder {
    color: #333;
    font-weight: 600;
    opacity: 1;
    font-size: 15px;
}

.search-input-enhanced:focus {
    background: rgba(255, 255, 255, 0.95);
    border-color: #ffc107;
    box-shadow: 0 4px 20px rgba(255, 193, 7, 0.3);
    outline: none;
    color: #000;
}

.search-input-enhanced:focus::placeholder {
    color: #999;
    font-weight: 500;
}

/* Enhanced search box hover effect */
.search-box:hover .search-input-enhanced {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.4);
    transform: translateY(-1px);
}

/* Search box focus animation */
.search-input-enhanced:focus {
    animation: searchPulse 0.3s ease;
}

@keyframes searchPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.02); }
    100% { transform: scale(1); }
}

/* Enhanced table row highlighting */
.modern-table tbody tr {
    transition: all 0.3s ease;
}

.modern-table tbody tr:hover {
    background-color: rgba(13, 110, 253, 0.08) !important;
    transform: scale(1.01);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

/* Search results info styling */
.search-results-info {
    background: #ffc107;
    padding: 0.75rem 1.25rem;
    border-radius: 25px;
    color: #000;
    font-size: 1rem;
    font-weight: 700;
    margin-top: 0.75rem;
    display: none;
    border: 2px solid #000;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.5);
}

.search-results-info.show {
    display: block;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from { 
        opacity: 0; 
        transform: translateY(-10px) scale(0.95); 
    }
    to { 
        opacity: 1; 
        transform: translateY(0) scale(1); 
    }
}

/* Clear search button */
.clear-search-btn {
    position: absolute;
    right: 0.5rem;
    top: 50%;
    transform: translateY(-50%);
    border-radius: 50%;
    width: 30px;
    height: 30px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.8;
    transition: all 0.3s ease;
    z-index: 3;
}

.clear-search-btn:hover {
    opacity: 1;
    transform: translateY(-50%) scale(1.1);
    background-color: rgba(255, 255, 255, 0.2);
}

/* Adjust search input padding when clear button is visible */
.search-box.has-clear .search-input-enhanced {
    padding-right: 3rem;
}

/* Mobile responsiveness for search */
@media (max-width: 768px) {
    .search-box {
        max-width: 100%;
        min-width: auto;
    }
    
    .search-input-enhanced {
        font-size: 16px; /* Prevents zoom on iOS */
    }
    
    .table-controls {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .search-results-info {
        text-align: center;
        margin-top: 0.25rem;
    }
    
    .clear-search-btn {
        width: 28px;
        height: 28px;
        right: 0.25rem;
    }
}

/* Search results indicator */
.search-results-info {
    background: rgba(255, 255, 255, 0.1);
    padding: 0.5rem 1rem;
    border-radius: 15px;
    color: white;
    font-size: 0.875rem;
    margin-top: 0.5rem;
    display: none;
}

.search-results-info.show {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: #343a40;
    border-bottom: 2px solid #ffc107;
    font-weight: 700;
    color: white;
    text-transform: uppercase;
    font-size: 0.8rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}

/* Table enhancements */
.table tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.05);
}

/* Progress bar enhancements */
.progress {
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    transition: width 0.6s ease;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .sidebar {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

@media (max-width: 768px) {
    .stat-card {
        margin-bottom: 1rem;
    }
    
    .chart-card {
        margin-bottom: 1.5rem;
    }
}

@media (max-width: 576px) {
    .btn-group {
        flex-direction: column;
    }
    
    .btn-group .btn {
        margin-bottom: 0.25rem;
    }
}

/* Chart container styling */
canvas {
    max-height: 400px;
}

/* Enhanced Card Styles */
.stat-card {
    transition: all 0.3s ease;
    border-radius: 10px;
    background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
    overflow: hidden;
    height: 140px;
}

.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1) !important;
}

.stat-icon {
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.stat-card:hover .stat-icon {
    transform: scale(1.1);
}

.stat-card h6 {
    font-size: 0.85rem;
    font-weight: 500;
    margin-bottom: 0.5rem;
}

.stat-card h4 {
    font-size: 1.25rem;
    font-weight: 600;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .stat-card {
        height: 130px;
        margin-bottom: 1rem;
    }
    
    .stat-card h4 {
        font-size: 1.1rem;
    }
    
    .stat-icon {
        width: 40px;
        height: 40px;
    }
}

/* Enhanced Chart Card Styles */
.chart-card {
    transition: all 0.3s ease;
    border-radius: 12px;
    background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
    overflow: hidden;
}

.chart-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1) !important;
}

.chart-card .card-header {
    padding: 1rem 1.5rem;
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.chart-card .card-body {
    padding: 1.5rem;
}

.chart-card .card-title {
    font-size: 1.1rem;
    font-weight: 600;
}

.chart-card .card-title i {
    width: 24px;
    height: 24px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    margin-right: 0.5rem;
}

/* Button Group Styling */
.btn-group .btn {
    padding: 0.375rem 1rem;
    font-size: 0.875rem;
    font-weight: 500;
}

.btn-group .btn.active {
    background-color: #0d6efd;
    color: white;
    border-color: #0d6efd;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .chart-card {
        margin-bottom: 1.5rem;
    }
    
    .chart-card .card-body {
        padding: 1rem;
    }
}

@media (max-width: 768px) {
    .chart-card .card-header {
        padding: 0.75rem 1rem;
    }
    
    .chart-card .card-title {
        font-size: 1rem;
    }
    
    .btn-group .btn {
        padding: 0.25rem 0.75rem;
        font-size: 0.8rem;
    }
}

/* Stunning Action Buttons for Recent Properties */
.btn-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    font-size: 1.25rem;
    border: none;
    background: #f8f9fa;
    color: #495057;
    box-shadow: 0 2px 8px rgba(0,0,0,0.07);
    transition: background 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s;
    margin: 0 2px;
    outline: none;
}
.btn-icon:hover, .btn-icon:focus {
    background: #ffc107;
    color: #212529;
    box-shadow: 0 4px 16px rgba(255,193,7,0.15);
    transform: translateY(-2px) scale(1.08);
}
.btn-update {
    background: #e7f5ff;
    color: #228be6;
}
.btn-update:hover, .btn-update:focus {
    background: #228be6;
    color: #fff;
}
.btn-delete {
    background: #fff0f0;
    color: #fa5252;
}
.btn-delete:hover, .btn-delete:focus {
    background: #fa5252;
    color: #fff;
}

/* Confidence Progress Bar Customization */
.progress {
    background: #f1f1f1;
    border-radius: 10px;
    height: 18px;
    min-width: 100px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
.progress-bar {
    font-size: 13px;
    font-weight: 600;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 8px;
    transition: width 0.5s cubic-bezier(.4,2,.3,1);
}
.badge.rounded-pill {
    font-size: 15px;
    font-weight: 700;
    box-shadow: 0 1px 4px rgba(0,0,0,0.07);
    letter-spacing: 0.5px;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-3d"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script>
// Chart.js global configuration
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.color = '#6c757d';

// Register DataLabels plugin
Chart.register(ChartDataLabels);

// Color palette
const colorPalette = {
    primary: '#0d6efd',
    success: '#198754',
    info: '#0dcaf0',
    warning: '#ffc107',
    danger: '#dc3545',
    purple: '#6f42c1',
    orange: '#fd7e14',
    teal: '#20c997',
    pink: '#d63384'
};

// Initialize all charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Price Trends Chart (3D)
    const priceTrendsCtx = document.getElementById('priceTrendsChart').getContext('2d');
    const priceTrendsChart = new Chart(priceTrendsCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($price_trends, 'month')); ?>,
            datasets: [{
                label: 'Average Price',
                data: <?php echo json_encode(array_column($price_trends, 'avg_price')); ?>,
                borderColor: colorPalette.primary,
                backgroundColor: colorPalette.primary + '40',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: colorPalette.primary,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 3,
                pointRadius: 8,
                pointHoverRadius: 10,
                borderWidth: 3
            }, {
                label: 'Property Count',
                data: <?php echo json_encode(array_column($price_trends, 'property_count')); ?>,
                borderColor: colorPalette.success,
                backgroundColor: colorPalette.success + '40',
                tension: 0.4,
                yAxisID: 'y1',
                pointBackgroundColor: colorPalette.success,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 3,
                pointRadius: 8,
                pointHoverRadius: 10,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                },
                datalabels: {
                    display: function(context) {
                        return context.datasetIndex === 0; // Show labels for first dataset only
                    },
                    color: '#333',
                    anchor: 'end',
                    align: 'top',
                    offset: 8,
                    font: {
                        weight: 'bold',
                        size: 10
                    },
                    formatter: function(value) {
                        return 'RWF ' + Math.round(value / 1000000) + 'M';
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Month'
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Price (RWF)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'RWF ' + value.toLocaleString();
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Count'
                    },
                    grid: {
                        drawOnChartArea: false,
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 20,
                    bottom: 20
                }
            },
            elements: {
                point: {
                    radius: 8,
                    hoverRadius: 10,
                    borderWidth: 3
                }
            }
        }
    });

    // Location Distribution Chart (3D)
    const locationDistributionCtx = document.getElementById('locationDistributionChart').getContext('2d');
    new Chart(locationDistributionCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_column($locations, 'location')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($locations, 'count')); ?>,
                backgroundColor: [
                    colorPalette.primary,
                    colorPalette.success,
                    colorPalette.warning,
                    colorPalette.info,
                    colorPalette.danger,
                    colorPalette.purple,
                    colorPalette.orange,
                    colorPalette.teal
                ],
                borderWidth: 4,
                borderColor: '#ffffff',
                hoverOffset: 8,
                weight: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} properties (${percentage}%)`;
                        }
                    }
                },
                datalabels: {
                    color: '#fff',
                    font: {
                        weight: 'bold',
                        size: 11
                    },
                    formatter: function(value, context) {
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((value / total) * 100).toFixed(1);
                        return `${value}\n(${percentage}%)`;
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 10,
                    bottom: 10
                }
            },
            cutout: '60%'
        }
    });

    // Price Range Distribution Chart (3D)
    const priceRangeCtx = document.getElementById('priceRangeChart').getContext('2d');
    new Chart(priceRangeCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($price_ranges, 'price_range')); ?>,
            datasets: [{
                label: 'Number of Properties',
                data: <?php echo json_encode(array_column($price_ranges, 'count')); ?>,
                backgroundColor: [
                    colorPalette.success + '90',
                    colorPalette.info + '90',
                    colorPalette.warning + '90',
                    colorPalette.orange + '90',
                    colorPalette.danger + '90'
                ],
                borderColor: [
                    colorPalette.success,
                    colorPalette.info,
                    colorPalette.warning,
                    colorPalette.orange,
                    colorPalette.danger
                ],
                borderWidth: 3,
                borderRadius: 12,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.parsed.y} properties in ${context.label}`;
                        }
                    }
                },
                datalabels: {
                    color: '#333',
                    anchor: 'end',
                    align: 'top',
                    offset: 4,
                    font: {
                        weight: 'bold',
                        size: 10
                    },
                    formatter: function(value, context) {
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((value / total) * 100).toFixed(1);
                        return `${value}\n(${percentage}%)`;
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Properties'
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Price Range'
                    },
                    grid: {
                        display: false
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 20,
                    bottom: 20
                }
            },
            elements: {
                bar: {
                    borderWidth: 3
                }
            }
        }
    });

    // Confidence Distribution Chart (3D)
    const confidenceDistributionCtx = document.getElementById('confidenceDistributionChart').getContext('2d');
    new Chart(confidenceDistributionCtx, {
        type: 'polarArea',
        data: {
            labels: <?php echo json_encode(array_column($confidence_distribution, 'confidence_range')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($confidence_distribution, 'count')); ?>,
                backgroundColor: [
                    colorPalette.danger + '80',
                    colorPalette.warning + '80',
                    colorPalette.info + '80',
                    colorPalette.success + '80'
                ],
                borderColor: [
                    colorPalette.danger,
                    colorPalette.warning,
                    colorPalette.info,
                    colorPalette.success
                ],
                borderWidth: 3,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} properties (${percentage}%)`;
                        }
                    }
                },
                datalabels: {
                    color: '#333',
                    font: {
                        weight: 'bold',
                        size: 10
                    },
                    formatter: function(value, context) {
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((value / total) * 100).toFixed(1);
                        return `${value}\n(${percentage}%)`;
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 10,
                    bottom: 10
                }
            }
        }
    });

    // Size vs Price Scatter Chart (3D)
    const sizePriceScatterCtx = document.getElementById('sizePriceScatterChart').getContext('2d');
    new Chart(sizePriceScatterCtx, {
        type: 'scatter',
        data: {
            datasets: [{
                label: 'Properties',
                data: <?php echo json_encode(array_map(function($item) {
                    return ['x' => $item['size_sqm'], 'y' => $item['estimated_price']];
                }, $size_price_data)); ?>,
                backgroundColor: colorPalette.purple + '80',
                borderColor: colorPalette.purple,
                borderWidth: 3,
                pointRadius: 8,
                pointHoverRadius: 12,
                pointBackgroundColor: colorPalette.purple,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Size: ${context.parsed.x.toLocaleString()} sqm, Price: RWF ${context.parsed.y.toLocaleString()}`;
                        }
                    }
                },
                datalabels: {
                    display: false // Hide labels for scatter plot to avoid clutter
                }
            },
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    title: {
                        display: true,
                        text: 'Size (sqm)'
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Price (RWF)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'RWF ' + value.toLocaleString();
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 20,
                    bottom: 20
                }
            },
            elements: {
                point: {
                    radius: 8,
                    hoverRadius: 12,
                    borderWidth: 2
                }
            }
        }
    });

    // Monthly Additions Chart (3D)
    const monthlyAdditionsCtx = document.getElementById('monthlyAdditionsChart').getContext('2d');
    new Chart(monthlyAdditionsCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($monthly_additions, 'month')); ?>,
            datasets: [{
                label: 'Properties Added',
                data: <?php echo json_encode(array_column($monthly_additions, 'count')); ?>,
                backgroundColor: colorPalette.primary + '90',
                borderColor: colorPalette.primary,
                borderWidth: 3,
                borderRadius: 10,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.parsed.y} properties added in ${context.label}`;
                        }
                    }
                },
                datalabels: {
                    color: '#333',
                    anchor: 'end',
                    align: 'top',
                    offset: 4,
                    font: {
                        weight: 'bold',
                        size: 10
                    },
                    formatter: function(value) {
                        return value;
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Properties Added'
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Month'
                    },
                    grid: {
                        display: false
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 20,
                    bottom: 20
                }
            },
            elements: {
                bar: {
                    borderWidth: 3
                }
            }
        }
    });

    // Initialize Prediction Chart with dynamic data
    const predictionCtx = document.getElementById('predictionChart').getContext('2d');
    
    // Get all properties data for dynamic calculations
    const allProperties = <?php echo json_encode($properties); ?>;
    const locationData = <?php echo json_encode($locations); ?>;
    
    // Location-based growth rates (Rwanda market data) - Updated for realistic projections
    const locationGrowthRates = {
        'Tumba': { conservative: 0.07, moderate: 0.09, aggressive: 0.12 }, // Highest growth area
        'Huye': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 }, // High growth area
        'Ngoma': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 }, // Medium growth area
        'Rukira': { conservative: 0.04, moderate: 0.06, aggressive: 0.09 }, // Lower growth area
        'Kacyiru': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 },
        'Kimihurura': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 },
        'Remera': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 },
        'Muhima': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 },
        'Gasabo': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Kicukiro': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Nyarugenge': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Rusororo': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Bumbogo': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Gikomero': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Jabana': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'Kimironko': { conservative: 0.05, moderate: 0.07, aggressive: 0.10 },
        'default': { conservative: 0.06, moderate: 0.08, aggressive: 0.11 } // Default to realistic rates
    };
    
    // Function to get growth rate for a location
    function getGrowthRate(location, scenario) {
        for (const [area, rates] of Object.entries(locationGrowthRates)) {
            if (location.toLowerCase().includes(area.toLowerCase())) {
                return rates[scenario];
            }
        }
        return locationGrowthRates.default[scenario];
    }
    
    // Function to calculate projection for filtered properties
    function calculateProjectionForProperties(properties, scenario) {
        if (properties.length === 0) return Array.from({length: 11}, () => 0);
        
        const totalValue = properties.reduce((sum, prop) => sum + (parseFloat(prop.predicted_price) || 0), 0);
        const avgGrowthRate = properties.reduce((sum, prop) => {
            return sum + getGrowthRate(prop.location, scenario);
        }, 0) / properties.length;
        
        return Array.from({length: 11}, (_, i) => {
            return totalValue * Math.pow(1 + avgGrowthRate, i);
        });
    }
    
    // Function to update chart data based on location filter
    function updateChartData() {
        const selectedLocation = document.getElementById('locationFilter').value;
        let filteredProperties = allProperties;
        
        if (selectedLocation) {
            filteredProperties = allProperties.filter(prop => 
                prop.location.toLowerCase().includes(selectedLocation.toLowerCase())
            );
        }
        
        const currentValue = filteredProperties.reduce((sum, prop) => 
            sum + (parseFloat(prop.predicted_price) || 0), 0
        );
        
        // Update summary cards
        document.getElementById('currentValue').textContent = 'RWF ' + currentValue.toLocaleString();
        
        const conservativeGrowth = getGrowthRate(selectedLocation || 'default', 'conservative');
        const projectedValue = currentValue * Math.pow(1 + conservativeGrowth, 10);
        const growthPercent = (Math.pow(1 + conservativeGrowth, 10) - 1) * 100;
        
        document.getElementById('projectedValue').textContent = 'RWF ' + projectedValue.toLocaleString();
        document.getElementById('growthPotential').textContent = growthPercent.toFixed(1) + '%';
        
        // Update chart datasets
        predictionChart.data.datasets[0].data = calculateProjectionForProperties(filteredProperties, 'conservative');
        predictionChart.data.datasets[1].data = calculateProjectionForProperties(filteredProperties, 'moderate');
        predictionChart.data.datasets[2].data = calculateProjectionForProperties(filteredProperties, 'aggressive');
        
        predictionChart.update();
    }
    
    const predictionChart = new Chart(predictionCtx, {
        type: 'line',
        data: {
            labels: Array.from({length: 11}, (_, i) => `Year ${i}`),
            datasets: [{
                label: 'Conservative Growth',
                data: calculateProjectionForProperties(allProperties, 'conservative'),
                borderColor: colorPalette.success,
                backgroundColor: colorPalette.success + '40',
                tension: 0.4,
                fill: true,
                hidden: false,
                borderWidth: 3,
                pointBackgroundColor: colorPalette.success,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8
            }, {
                label: 'Moderate Growth',
                data: calculateProjectionForProperties(allProperties, 'moderate'),
                borderColor: colorPalette.warning,
                backgroundColor: colorPalette.warning + '40',
                tension: 0.4,
                fill: true,
                hidden: true,
                borderWidth: 3,
                pointBackgroundColor: colorPalette.warning,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8
            }, {
                label: 'Aggressive Growth',
                data: calculateProjectionForProperties(allProperties, 'aggressive'),
                borderColor: colorPalette.danger,
                backgroundColor: colorPalette.danger + '40',
                tension: 0.4,
                fill: true,
                hidden: true,
                borderWidth: 3,
                pointBackgroundColor: colorPalette.danger,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: RWF ${context.parsed.y.toLocaleString()}`;
                        }
                    }
                },
                datalabels: {
                    display: function(context) {
                        return !context.dataset.hidden; // Only show labels for visible datasets
                    },
                    color: '#333',
                    anchor: 'end',
                    align: 'top',
                    offset: 8,
                    font: {
                        weight: 'bold',
                        size: 9
                    },
                    formatter: function(value) {
                        return 'RWF ' + Math.round(value / 1000000) + 'M';
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Year'
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Projected Value (RWF)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'RWF ' + value.toLocaleString();
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                }
            },
            // 3D Configuration
            layout: {
                padding: {
                    top: 20,
                    bottom: 20
                }
            },
            elements: {
                point: {
                    radius: 6,
                    hoverRadius: 8,
                    borderWidth: 2
                }
            }
        }
    });

    // Store the chart instance globally
    window.predictionChart = predictionChart;
    
    // Add event listener for location filter
    document.getElementById('locationFilter').addEventListener('change', updateChartData);
});

// Function to update prediction chart scenario
function updatePredictionChart(scenario) {
    const chart = window.predictionChart;
    if (!chart) return;

    // Update button states
    document.querySelectorAll('.btn-group .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // Show/hide datasets based on scenario
    chart.data.datasets.forEach((dataset, index) => {
        if (scenario === 'conservative') {
            dataset.hidden = index !== 0;
        } else if (scenario === 'moderate') {
            dataset.hidden = index !== 1;
        } else if (scenario === 'aggressive') {
            dataset.hidden = index !== 2;
        }
    });

    chart.update();
}

// Function to update price chart type
function updatePriceChart(type) {
    const priceTrendsChart = Chart.getChart('priceTrendsChart');
    if (priceTrendsChart) {
        priceTrendsChart.config.type = type;
        if (type === 'area') {
            priceTrendsChart.config.type = 'line';
            priceTrendsChart.data.datasets[0].fill = true;
        } else {
            priceTrendsChart.data.datasets[0].fill = false;
        }
        priceTrendsChart.update();
    }
}

// Function to delete property
function deleteProperty(id) {
    if (confirm('Are you sure you want to delete this property?')) {
        fetch('../delete_property.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting property: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting. Please try again.');
        });
    }
}

// Function to download report
function downloadReport() {
    // Show export options modal
    const exportModal = `
        <div class="modal fade" id="exportModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Export Portfolio Report</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-3">Choose your export format:</p>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card border-primary">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-primary">
                                            <i class="bi bi-file-earmark-text me-2"></i>CSV Export
                                        </h6>
                                        <p class="card-text small">Complete portfolio data in a single CSV file with all analytics and projections</p>
                                        <button type="button" class="btn btn-primary btn-sm" onclick="performCSVExport()">
                                            <i class="bi bi-download me-1"></i>Download CSV
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-danger">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-danger">
                                            <i class="bi bi-file-earmark-pdf me-2"></i>PDF Report
                                        </h6>
                                        <p class="card-text small">Professional PDF report with charts, tables, and portfolio analysis</p>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="performPDFExport()">
                                            <i class="bi bi-download me-1"></i>Download PDF
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-info">
                                            <i class="bi bi-graph-up me-2"></i>Chart Data
                                        </h6>
                                        <p class="card-text small">Raw chart data for creating custom visualizations in Excel</p>
                                        <button type="button" class="btn btn-info btn-sm" onclick="performChartExport()">
                                            <i class="bi bi-download me-1"></i>Download Charts
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h6>Export Options Include:</h6>
                            <ul class="small">
                                <li><strong>CSV Export:</strong> Complete portfolio data in one file with summary, location analysis, and detailed properties</li>
                                <li><strong>PDF Report:</strong> Professional report with charts, tables, and portfolio analysis</li>
                                <li><strong>Chart Data:</strong> Raw data for creating custom visualizations in Excel or other tools</li>
                                <li>All exports exclude empty/null values for cleaner data</li>
                                <li>Includes 10-year projections and performance metrics</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', exportModal);
    const modal = new bootstrap.Modal(document.getElementById('exportModal'));
    modal.show();
    
    // Clean up modal after hiding
    document.getElementById('exportModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

function performCSVExport() {
    // Show loading message
    showNotification('Preparing CSV export...', 'info');
    
    // Redirect to CSV export
    window.location.href = 'export_portfolio.php?type=csv';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function performPDFExport() {
    // Show loading message
    showNotification('Preparing PDF report...', 'info');
    
    // Redirect to PDF export
    window.location.href = 'export_portfolio.php?type=pdf';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function performChartExport() {
    // Show loading message
    showNotification('Preparing chart data export...', 'info');
    
    // Redirect to chart export
    window.location.href = '../admin/export_charts.php?chart=all';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Search and filter functionality for user dashboard table
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('userDashboardSearch');
    const table = document.getElementById('userDashboardTable');
    const searchResultsInfo = document.getElementById('searchResultsInfo');
    const searchResultsText = document.getElementById('searchResultsText');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const searchBox = document.querySelector('.search-box');
    
    if (searchInput && table) {
        function filterTable() {
            const searchTerm = searchInput.value.toLowerCase();
            const rows = table.querySelectorAll('tbody tr');
            let visibleCount = 0;
            
            rows.forEach(row => {
                const upi = row.querySelector('.upi')?.textContent.toLowerCase() || '';
                const location = row.querySelector('.location')?.textContent.toLowerCase() || '';
                const size = row.querySelector('.size')?.textContent.toLowerCase() || '';
                const price = row.querySelector('.price')?.textContent.toLowerCase() || '';
                const date = row.querySelector('.date')?.textContent.toLowerCase() || '';
                
                const matchesSearch = upi.includes(searchTerm) || 
                                    location.includes(searchTerm) || 
                                    size.includes(searchTerm) || 
                                    price.includes(searchTerm) || 
                                    date.includes(searchTerm);
                
                if (matchesSearch) {
                    row.style.display = '';
                    visibleCount++;
                    // Add highlight effect to matching text
                    if (searchTerm) {
                        row.style.backgroundColor = 'rgba(13, 110, 253, 0.05)';
                        row.style.borderLeft = '3px solid #0d6efd';
                    } else {
                        row.style.backgroundColor = '';
                        row.style.borderLeft = '';
                    }
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Update search results info
            const totalRows = rows.length;
            if (searchTerm) {
                searchResultsText.textContent = `Found ${visibleCount} of ${totalRows} properties`;
                searchResultsInfo.classList.add('show');
            } else {
                searchResultsInfo.classList.remove('show');
            }
            
            // Show/hide clear button
            if (searchTerm) {
                clearSearchBtn.style.display = 'flex';
                searchBox.classList.add('has-clear');
            } else {
                clearSearchBtn.style.display = 'none';
                searchBox.classList.remove('has-clear');
            }
        }
        
        searchInput.addEventListener('input', filterTable);
        
        // Clear search button functionality
        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', function() {
                searchInput.value = '';
                filterTable();
                searchInput.focus();
            });
        }
        
        // Show/hide clear button based on input
        searchInput.addEventListener('input', function() {
            if (this.value.length > 0) {
                clearSearchBtn.style.display = 'flex';
                searchBox.classList.add('has-clear');
            } else {
                clearSearchBtn.style.display = 'none';
                searchBox.classList.remove('has-clear');
            }
        });
        
        // Sortable headers
        const sortableHeaders = table.querySelectorAll('.sortable');
        sortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(sortType, this);
            });
        });
        
        function sortTable(sortType, headerElement) {
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const isAscending = !headerElement.classList.contains('sort-asc');
            
            // Remove sort classes from all headers
            sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
            
            // Add appropriate sort class
            headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortType) {
                    case 'upi':
                        aVal = a.querySelector('.upi')?.textContent || '';
                        bVal = b.querySelector('.upi')?.textContent || '';
                        break;
                    case 'location':
                        aVal = a.querySelector('.location')?.textContent || '';
                        bVal = b.querySelector('.location')?.textContent || '';
                        break;
                    case 'size':
                        aVal = parseFloat(a.querySelector('.size')?.dataset.size || '0');
                        bVal = parseFloat(b.querySelector('.size')?.dataset.size || '0');
                        break;
                    case 'price':
                        aVal = parseFloat(a.querySelector('.price')?.dataset.price || '0');
                        bVal = parseFloat(b.querySelector('.price')?.dataset.price || '0');
                        break;
                    case 'confidence':
                        aVal = parseFloat(a.querySelector('.confidence')?.dataset.confidence || '0');
                        bVal = parseFloat(b.querySelector('.confidence')?.dataset.confidence || '0');
                        break;
                    case 'date':
                        aVal = parseInt(a.querySelector('.date')?.dataset.date || '0');
                        bVal = parseInt(b.querySelector('.date')?.dataset.date || '0');
                        break;
                    default:
                        return 0;
                }
                
                if (typeof aVal === 'string') {
                    return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                } else {
                    return isAscending ? aVal - bVal : bVal - aVal;
                }
            });
            
            // Reappend sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
    }
});

// Add animation effects on page load
window.addEventListener('load', function() {
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'all 0.5s ease';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 50);
        }, index * 100);
    });
});
</script>

<?php include '../includes/footer.php'; ?>