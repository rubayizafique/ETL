<?php
require_once '../../config/database.php';
if (!isset($_SESSION)) session_start();

// Get user's properties with their predictions
$stmt = $conn->prepare("
    SELECT 
        p.*,
        pr.predicted_price,
        pr.confidence_score,
        pr.prediction_date
    FROM properties p
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    WHERE p.user_id = ?
    ORDER BY p.submission_date DESC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$properties = $stmt->get_result();

// Prepare data for chart
$dates = [];
$prices = [];
$properties->data_seek(0);
while ($property = $properties->fetch_assoc()) {
    if ($property['predicted_price'] && $property['prediction_date']) {
        $dates[] = date('M d', strtotime($property['prediction_date']));
        $prices[] = $property['predicted_price'];
    }
}

// Calculate stats
$total = 0;
$count = 0;
$latest_date = 'N/A';
$properties->data_seek(0);
while ($property = $properties->fetch_assoc()) {
    if ($property['predicted_price']) {
        $total += $property['predicted_price'];
        $count++;
    }
    if ($property['prediction_date'] && $latest_date === 'N/A') {
        $latest_date = date('M d, Y', strtotime($property['prediction_date']));
    }
}
$avg_price = $count > 0 ? 'RWF ' . number_format($total / $count, 0) : 'RWF 0';
// Re-query for count to ensure accuracy
$count_stmt = $conn->prepare("SELECT COUNT(*) FROM properties WHERE user_id = ?");
$count_stmt->bind_param("i", $_SESSION['user_id']);
$count_stmt->execute();
$count_stmt->bind_result($total_submissions);
$count_stmt->fetch();
$count_stmt->close();

?>
<div class="row g-4">
    <div class="col-md-4">
        <div class="glass-card card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #27AE60 60%, #2C3E50 100%);">
                    <i class="bi bi-house-door-fill"></i>
                </div>
                <div class="stat-label">Total Submissions</div>
                <div class="stat-value"><?php echo $total_submissions; ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="glass-card card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #2C3E50 60%, #27AE60 100%);">
                    <i class="bi bi-currency-dollar"></i>
                </div>
                <div class="stat-label">Average Price</div>
                <div class="stat-value"><?php echo $avg_price; ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="glass-card card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #27AE60 60%, #2C3E50 100%);">
                    <i class="bi bi-calendar-event"></i>
                </div>
                <div class="stat-label">Latest Prediction</div>
                <div class="stat-value"><?php echo $latest_date; ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5">
    <div class="col-12">
        <div class="glass-card card border-0 shadow-sm">
            <div class="card-body">
                <h5 class="card-title mb-4"><i class="bi bi-graph-up"></i> Property Value Trends</h5>
                <canvas id="propertyValueChart" height="80"></canvas>
            </div>
        </div>
    </div>
</div>

<style>
.glass-card {
    background: rgba(255,255,255,0.7);
    border-radius: 18px;
    box-shadow: 0 8px 32px 0 rgba(31,38,135,0.10);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    border: 1px solid rgba(255,255,255,0.18);
    transition: box-shadow 0.2s, transform 0.2s;
}
.glass-card:hover {
    box-shadow: 0 12px 36px 0 rgba(44,62,80,0.18);
    transform: translateY(-2px) scale(1.01);
}
.icon-circle {
    width: 54px;
    height: 54px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: #fff;
    margin: 0 auto;
    box-shadow: 0 2px 8px rgba(44,62,80,0.10);
}
.stat-label {
    font-size: 1.1rem;
    color: #2C3E50;
    font-weight: 500;
    margin-bottom: 0.2rem;
}
.stat-value {
    font-size: 2.1rem;
    font-weight: 700;
    color: #27AE60;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-3d"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script>
// Register DataLabels plugin
Chart.register(ChartDataLabels);

const ctx = document.getElementById('propertyValueChart').getContext('2d');
const propertyValueChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_reverse($dates)); ?>,
        datasets: [{
            label: 'Predicted Price',
            data: <?php echo json_encode(array_reverse($prices)); ?>,
            fill: true,
            backgroundColor: 'rgba(39, 174, 96, 0.3)',
            borderColor: '#27AE60',
            tension: 0.4,
            pointBackgroundColor: '#2C3E50',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 8,
            borderWidth: 3
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'RWF ' + context.parsed.y.toLocaleString();
                    }
                }
            },
            datalabels: {
                color: '#333',
                anchor: 'end',
                align: 'top',
                offset: 8,
                font: {
                    weight: 'bold',
                    size: 10
                },
                formatter: function(value) {
                    return 'RWF ' + Math.round(value / 1000000) + 'M';
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'RWF ' + new Intl.NumberFormat('en-US', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0
                        }).format(value);
                    }
                },
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        },
        // 3D Configuration
        layout: {
            padding: {
                top: 20,
                bottom: 20
            }
        },
        elements: {
            point: {
                radius: 6,
                hoverRadius: 8,
                borderWidth: 2
            }
        }
    }
});
</script> 