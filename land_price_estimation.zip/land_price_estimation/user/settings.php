<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Get user's current settings
$stmt = $conn->prepare("
    SELECT 
        u.*,
        COALESCE(up.notifications, 1) as notifications,
        COALESCE(up.email_alerts, 1) as email_alerts
    FROM users u
    LEFT JOIN user_preferences up ON u.id = up.user_id
    WHERE u.id = ?
");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $email, $phone, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Profile updated successfully.";
            $_SESSION['username'] = $username;
        } else {
            $_SESSION['error'] = "Error updating profile.";
        }
    } elseif (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (password_verify($current_password, $user['password'])) {
            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashed_password, $_SESSION['user_id']);
                
                if ($stmt->execute()) {
                    $_SESSION['success'] = "Password changed successfully.";
                } else {
                    $_SESSION['error'] = "Error changing password.";
                }
            } else {
                $_SESSION['error'] = "New passwords do not match.";
            }
        } else {
            $_SESSION['error'] = "Current password is incorrect.";
        }
    } elseif (isset($_POST['update_preferences'])) {
        $notifications = isset($_POST['notifications']) ? 1 : 0;
        $email_alerts = isset($_POST['email_alerts']) ? 1 : 0;
        $currency = $_POST['currency'];
        
        // Check if user preferences exist
        $check_stmt = $conn->prepare("SELECT id FROM user_preferences WHERE user_id = ?");
        $check_stmt->bind_param("i", $_SESSION['user_id']);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Update existing preferences
            $update_stmt = $conn->prepare("
                UPDATE user_preferences 
                SET notifications = ?, email_alerts = ? 
                WHERE user_id = ?
            ");
            $update_stmt->bind_param("iii", $notifications, $email_alerts, $_SESSION['user_id']);
            $update_stmt->execute();
        } else {
            // Insert new preferences
            $insert_stmt = $conn->prepare("
                INSERT INTO user_preferences (user_id, notifications, email_alerts) 
                VALUES (?, ?, ?)
            ");
            $insert_stmt->bind_param("iii", $_SESSION['user_id'], $notifications, $email_alerts);
            $insert_stmt->execute();
        }
        
        // Refresh the page to show updated settings
        header("Location: settings.php?success=1");
        exit;
    }
    
    header('Location: settings.php');
    exit;
}

include '../includes/header_logged_in.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white d-none d-lg-block" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
        <div class="p-3">
            <div class="d-flex align-items-center mb-4">
                <img src="../assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
                <h5 class="text-white mb-0">User Dashboard</h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link text-white" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white active" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-white" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Mobile Sidebar Toggle Button -->
    <button class="btn btn-dark d-lg-none position-fixed" style="top: 1rem; left: 1rem; z-index: 1100;" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMobile" aria-controls="sidebarMobile">
        <i class="bi bi-list fs-2"></i>
    </button>
    <!-- Mobile Sidebar (Offcanvas) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="../logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Settings Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Settings</h1>
                    <p class="text-muted mb-0">Manage your account settings and preferences</p>
                </div>
                <a href="../logout.php" class="btn btn-outline-danger d-lg-none">
                    <i class="bi bi-box-arrow-right"></i>
                </a>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- Profile Settings -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-person-circle me-2"></i>Profile Settings
                            </h5>
                        </div>
                        <div class="card-body">
                            <form action="settings.php" method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Save Changes
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-key me-2"></i>Change Password
                            </h5>
                        </div>
                        <div class="card-body">
                            <form action="settings.php" method="POST">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password</label>
                                    <input type="password" class="form-control" id="current_password" 
                                           name="current_password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new_password" class="form-label">New Password</label>
                                    <input type="password" class="form-control" id="new_password" 
                                           name="new_password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                                    <input type="password" class="form-control" id="confirm_password" 
                                           name="confirm_password" required>
                                </div>
                                <button type="submit" name="change_password" class="btn btn-primary">
                                    <i class="bi bi-key me-2"></i>Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Preferences -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-gear me-2"></i>Preferences
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <!-- Notifications -->
                                <div class="mb-4">
                                    <h5 class="card-title mb-3">Notifications</h5>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="notifications" name="notifications" 
                                               <?php echo ($user['notifications'] ?? 1) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="notifications">
                                            Enable in-app notifications
                                        </label>
                                    </div>
                                </div>

                                <!-- Email Alerts -->
                                <div class="mb-4">
                                    <h5 class="card-title mb-3">Email Alerts</h5>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="email_alerts" name="email_alerts" 
                                               <?php echo ($user['email_alerts'] ?? 1) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="email_alerts">
                                            Receive email notifications
                                        </label>
                                    </div>
                                </div>

                                <!-- Save Button -->
                                <div class="text-end">
                                    <button type="submit" name="update_preferences" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i>Save Settings
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Account Security -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-shield-lock me-2"></i>Account Security
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h6 class="mb-3">Two-Factor Authentication</h6>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="2fa" disabled>
                                    <label class="form-check-label" for="2fa">
                                        Enable two-factor authentication
                                    </label>
                                </div>
                                <small class="text-muted d-block mt-2">
                                    Coming soon: Add an extra layer of security to your account
                                </small>
                            </div>
                            <div class="mb-4">
                                <h6 class="mb-3">Login History</h6>
                                <div class="table-controls mb-2">
                                    <div class="search-box">
                                        <i class="bi bi-search"></i>
                                        <input type="text" class="form-control" id="loginHistorySearch" placeholder="Search login history...">
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm modern-table" id="loginHistoryTable">
                                        <thead>
                                            <tr>
                                                <th class="sortable" data-sort="date">
                                                    <div class="th-content">
                                                        Date
                                                        <i class="bi bi-arrow-down-up sort-icon"></i>
                                                    </div>
                                                </th>
                                                <th class="sortable" data-sort="ip">
                                                    <div class="th-content">
                                                        IP Address
                                                        <i class="bi bi-arrow-down-up sort-icon"></i>
                                                    </div>
                                                </th>
                                                <th class="sortable" data-sort="device">
                                                    <div class="th-content">
                                                        Device
                                                        <i class="bi bi-arrow-down-up sort-icon"></i>
                                                    </div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="date" data-date="<?php echo strtotime(date('Y-m-d H:i:s')); ?>"><?php echo date('M d, Y H:i'); ?></td>
                                                <td class="ip"><?php echo $_SERVER['REMOTE_ADDR']; ?></td>
                                                <td class="device"><?php echo $_SERVER['HTTP_USER_AGENT']; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="d-grid">
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" 
                                        data-bs-target="#deleteAccountModal">
                                    <i class="bi bi-trash me-2"></i>Delete Account
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="text-danger">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    Warning: This action cannot be undone.
                </p>
                <p>Are you sure you want to delete your account? All your data will be permanently removed.</p>
                <form action="delete_account.php" method="POST">
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Enter your password to confirm</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-trash me-2"></i>Delete Account
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
/* Table Controls */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 300px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-400);
    z-index: 2;
}

.search-box .form-control {
    padding-left: 2.5rem;
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    background: white;
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: var(--gray-50);
    border-bottom: 2px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .sidebar {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

@media (max-width: 768px) {
    .card {
        margin-bottom: 1rem;
    }
}

/* Mobile Optimizations */
@media (max-width: 576px) {
    .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .form-check {
        margin-bottom: 1rem;
    }
}
</style>

<script>
// Search and filter functionality for login history table
document.addEventListener('DOMContentLoaded', function() {
    const loginHistorySearchInput = document.getElementById('loginHistorySearch');
    const loginHistoryTable = document.getElementById('loginHistoryTable');
    
    if (loginHistorySearchInput && loginHistoryTable) {
        function filterLoginHistoryTable() {
            const searchTerm = loginHistorySearchInput.value.toLowerCase();
            const rows = loginHistoryTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const date = row.querySelector('.date')?.textContent.toLowerCase() || '';
                const ip = row.querySelector('.ip')?.textContent.toLowerCase() || '';
                const device = row.querySelector('.device')?.textContent.toLowerCase() || '';
                
                const matchesSearch = date.includes(searchTerm) || 
                                    ip.includes(searchTerm) || 
                                    device.includes(searchTerm);
                
                row.style.display = matchesSearch ? '' : 'none';
            });
        }
        
        loginHistorySearchInput.addEventListener('input', filterLoginHistoryTable);
        
        // Sortable headers
        const sortableHeaders = loginHistoryTable.querySelectorAll('.sortable');
        sortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(sortType, this);
            });
        });
        
        function sortTable(sortType, headerElement) {
            const tbody = loginHistoryTable.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const isAscending = !headerElement.classList.contains('sort-asc');
            
            // Remove sort classes from all headers
            sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
            
            // Add appropriate sort class
            headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortType) {
                    case 'date':
                        aVal = parseInt(a.querySelector('.date')?.dataset.date || '0');
                        bVal = parseInt(b.querySelector('.date')?.dataset.date || '0');
                        break;
                    case 'ip':
                        aVal = a.querySelector('.ip')?.textContent || '';
                        bVal = b.querySelector('.ip')?.textContent || '';
                        break;
                    case 'device':
                        aVal = a.querySelector('.device')?.textContent || '';
                        bVal = b.querySelector('.device')?.textContent || '';
                        break;
                    default:
                        return 0;
                }
                
                if (typeof aVal === 'string') {
                    return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                } else {
                    return isAscending ? aVal - bVal : bVal - aVal;
                }
            });
            
            // Reappend sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
    }
});
</script>

<?php include '../includes/footer.php'; ?> 