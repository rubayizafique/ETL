<?php
session_start();
require_once 'config/database.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $property_type = $_POST['property_type'] ?? '';
    $location = $_POST['location'] ?? '';
    $size_sqm = $_POST['size_sqm'] ?? 0;
    $num_rooms = $_POST['num_rooms'] ?? null;
    $has_water = isset($_POST['has_water']) ? 1 : 0;
    $has_electricity = isset($_POST['has_electricity']) ? 1 : 0;
    $has_road_access = isset($_POST['has_road_access']) ? 1 : 0;
    $additional_amenities = $_POST['additional_amenities'] ?? '';
    
    // Basic validation
    if (empty($property_type) || empty($location) || $size_sqm <= 0) {
        $_SESSION['error'] = "Please fill in all required fields correctly.";
        header('Location: submit.php');
        exit;
    }

    // Get user ID if logged in
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO properties (user_id, property_type, location, size_sqm, num_rooms, 
                           has_water, has_electricity, has_road_access, additional_amenities) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param("issdiisss", 
        $user_id,
        $property_type,
        $location,
        $size_sqm,
        $num_rooms,
        $has_water,
        $has_electricity,
        $has_road_access,
        $additional_amenities
    );

    if ($stmt->execute()) {
        $property_id = $conn->insert_id;
        
        // TODO: Here you would integrate with your ML model
        // For now, we'll use a placeholder price
        $estimated_price = calculatePlaceholderPrice($size_sqm, $property_type);
        
        // Store the placeholder price
        $stmt = $conn->prepare("UPDATE properties SET estimated_price = ? WHERE id = ?");
        $stmt->bind_param("di", $estimated_price, $property_id);
        $stmt->execute();

        $_SESSION['success'] = "Property details submitted successfully!";
        header('Location: predict.php?id=' . $property_id);
        exit;
    } else {
        $_SESSION['error'] = "Error submitting property details. Please try again.";
        header('Location: submit.php');
        exit;
    }
} else {
    header('Location: submit.php');
    exit;
}

// Placeholder function for price calculation
// This will be replaced by your ML model later
function calculatePlaceholderPrice($size_sqm, $property_type) {
    $base_price = 1000; // Base price per square meter
    
    // Adjust price based on property type
    switch ($property_type) {
        case 'land':
            $multiplier = 1.0;
            break;
        case 'house':
            $multiplier = 1.5;
            break;
        case 'apartment':
            $multiplier = 1.3;
            break;
        default:
            $multiplier = 1.0;
    }
    
    return $size_sqm * $base_price * $multiplier;
}
?> 