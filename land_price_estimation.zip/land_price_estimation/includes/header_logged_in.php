<?php
// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Price Estimation</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Chart.js with 3D Support and Data Labels -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-chart-3d"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <!-- Sidebar JavaScript -->
    <script src="../assets/js/sidebar.js" defer></script>
    <style>
        /* Main Layout */
        body {
            overflow-x: hidden;
            background-color: #f8f9fa;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: #2c3e50;
            padding-top: 1rem;
            transition: all 0.3s ease;
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            width: 70px;
        }

        .sidebar-header {
            padding: 1rem;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h3 {
            color: white;
            margin: 0;
            font-size: 1.2rem;
            white-space: nowrap;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .sidebar-header h3 {
            opacity: 0;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 1rem 0;
            flex-grow: 1;
        }

        .sidebar-menu li {
            margin-bottom: 0.5rem;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 0.8rem 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-radius: 0.5rem;
            margin: 0 0.5rem;
        }

        .sidebar-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .sidebar-menu a.active {
            background: #3498db;
            color: white;
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }

        .sidebar-menu i {
            font-size: 1.2rem;
            margin-right: 1rem;
            width: 20px;
            text-align: center;
        }

        .sidebar-menu span {
            white-space: nowrap;
            overflow: hidden;
            opacity: 1;
            transition: all 0.3s ease;
            display: inline;
        }

        .sidebar.collapsed .sidebar-menu span {
            opacity: 0;
            width: 0;
            display: none;
        }

        .user-info {
            padding: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: auto;
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .user-info {
            text-align: center;
            padding: 1rem 0;
        }

        .user-info .user-name,
        .user-info .user-role,
        .user-info .btn span {
            display: block;
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .user-info .user-name,
        .sidebar.collapsed .user-info .user-role,
        .sidebar.collapsed .user-info .btn span {
            display: none;
        }

        .user-info .user-name {
            color: white;
            font-weight: 500;
            margin-bottom: 0.5rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info .user-role {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-info .btn-danger {
            transition: all 0.3s ease;
        }

        .sidebar.collapsed .user-info .btn-danger {
            padding: 0.25rem;
            width: 40px !important;
            margin: 0 auto;
        }

        /* Dashboard specific styles */
        .dashboard-container {
            padding: 2rem;
            width: 100%;
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
            }
            
            .sidebar.expanded {
                width: 250px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .main-content.expanded {
                margin-left: 250px;
            }
            
            .toggle-sidebar {
                left: 90px;
            }
            
            .toggle-sidebar.expanded {
                left: 270px;
            }
            
            .sidebar-menu span,
            .user-name,
            .user-role,
            .btn span {
                display: none;
            }
            
            .sidebar.expanded .sidebar-menu span,
            .sidebar.expanded .user-name,
            .sidebar.expanded .user-role,
            .sidebar.expanded .btn span {
                display: inline;
            }
            
            .sidebar.expanded .sidebar-header h3 {
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
            }
        }

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all 0.3s ease;
            padding: 20px;
            width: calc(100% - 250px);
            position: relative;
            z-index: 1;
            background-color: #f8f9fa;
        }

        .main-content.expanded {
            margin-left: 70px;
            width: calc(100% - 70px);
        }

        .toggle-sidebar {
            position: fixed;
            top: 1rem;
            left: 270px;
            z-index: 1001;
            background: #2c3e50;
            color: white;
            border: none;
            padding: 0.5rem;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }

        .toggle-sidebar.collapsed {
            left: 90px;
        }

        .user-info .user-name,
        .user-info .user-role,
        .user-info .btn span {
            display: block;
            transition: all 0.3s ease;
        }

        .card {
            background-color: #fff;
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .card-body {
            padding: 1.5rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Land Price Estimation</h3>
        </div>
        <ul class="sidebar-menu">
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <li>
                <a href="/land_price_estimation/admin/dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="bi bi-shield-lock"></i>
                    <span>Admin Dashboard</span>
                </a>
            </li>
            <li>
                <a href="/land_price_estimation/admin/users.php" class="<?php echo $current_page === 'users.php' ? 'active' : ''; ?>">
                    <i class="bi bi-people"></i>
                    <span>Manage Users</span>
                </a>
            </li>
            <li>
                <a href="/land_price_estimation/admin/properties.php" class="<?php echo $current_page === 'properties.php' ? 'active' : ''; ?>">
                    <i class="bi bi-house"></i>
                    <span>All Properties</span>
                </a>
            </li>
            <?php else: ?>
            <li>
                <a href="/land_price_estimation/user/dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="/land_price_estimation/submit.php" class="<?php echo $current_page === 'submit.php' ? 'active' : ''; ?>">
                    <i class="bi bi-plus-circle"></i>
                    <span>Submit Property</span>
                </a>
            </li>
            <li>
                <a href="/land_price_estimation/predict.php" class="<?php echo $current_page === 'predict.php' ? 'active' : ''; ?>">
                    <i class="bi bi-calculator"></i>
                    <span>Predict Price</span>
                </a>
            </li>
            <li>
                <a href="/land_price_estimation/user/profile.php" class="<?php echo $current_page === 'profile.php' ? 'active' : ''; ?>">
                    <i class="bi bi-person"></i>
                    <span>Profile</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <div class="user-info">
            <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
            <div class="user-role"><?php echo ucfirst($_SESSION['role'] ?? 'user'); ?></div>
            <a href="/land_price_estimation/logout.php" class="btn btn-danger btn-sm w-100 mt-2">
                <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Toggle Sidebar Button -->
    <!-- <button class="toggle-sidebar">
        <i class="bi bi-list"></i>
    </button> -->

    <!-- Main Content Container -->
    <!-- Dashboard content will be inserted here -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleButton = document.querySelector('.toggle-sidebar');
    
    // Function to toggle sidebar
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
        toggleButton.classList.toggle('collapsed');
        
        // For mobile responsive design
        sidebar.classList.toggle('expanded');
        toggleButton.classList.toggle('expanded');
    }
    
    // Event listener for toggle button
    toggleButton.addEventListener('click', toggleSidebar);
    
    // Auto collapse on mobile devices
    function checkWidth() {
        if (window.innerWidth <= 992) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('expanded');
            toggleButton.classList.add('collapsed');
        } else {
            sidebar.classList.remove('collapsed');
            mainContent.classList.remove('expanded');
            toggleButton.classList.remove('collapsed');
        }
    }
    
    // Check on load
    checkWidth();
    
    // Check on resize
    window.addEventListener('resize', checkWidth);
});
</script>