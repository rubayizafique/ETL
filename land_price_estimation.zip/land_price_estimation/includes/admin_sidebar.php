<!-- Admin Sidebar (Reusable Include) -->
<div class="sidebar bg-dark text-white" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
    <div class="p-3">
        <div class="d-flex align-items-center mb-4">
            <img src="../assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
            <h5 class="text-white mb-0">Admin Dashboard</h5>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="users.php">
                    <i class="bi bi-people me-2"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="properties.php">
                    <i class="bi bi-building me-2"></i> Properties
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-white" href="settings.php">
                    <i class="bi bi-gear me-2"></i> Settings
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-white" href="../logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- Mobile Sidebar Toggle -->
<button class="btn btn-dark d-lg-none position-fixed" 
        style="top: 1rem; left: 1rem; z-index: 1001;"
        type="button" 
        data-bs-toggle="offcanvas" 
        data-bs-target="#sidebarMobile">
    <i class="bi bi-list"></i>
</button>

<!-- Mobile Sidebar -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="users.php">
                    <i class="bi bi-people me-2"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="properties.php">
                    <i class="bi bi-building me-2"></i> Properties
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="settings.php">
                    <i class="bi bi-gear me-2"></i> Settings
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link text-danger" href="../logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</div> 