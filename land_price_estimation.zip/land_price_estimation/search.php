<?php
require_once 'includes/header.php';
require_once 'config/database.php';

// Get locations for dropdown
// $stmt = $conn->prepare("SELECT DISTINCT location FROM properties ORDER BY location");
// $stmt->execute();
// $locations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include 'includes/header_logged_in.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-4">Search Land Properties</h5>
                    <form id="searchForm">
                        <div class="row g-3">
                            <!-- Location -->
                            <div class="mb-3">
                                <label for="location" class="form-label">Location</label>
                                <input type="text" class="form-control" id="location" name="location" 
                                       placeholder="Enter location to search">
                            </div>

                            <!-- Size Range -->
                            <div class="col-md-6">
                                <label for="size_range" class="form-label">Size Range (sqm)</label>
                                <select class="form-select" id="size_range" name="size_range">
                                    <option value="">Any Size</option>
                                    <option value="0-1000">0 - 1,000 sqm</option>
                                    <option value="1000-5000">1,000 - 5,000 sqm</option>
                                    <option value="5000-10000">5,000 - 10,000 sqm</option>
                                    <option value="10000+">10,000+ sqm</option>
                                </select>
                            </div>

                            <!-- Amenities -->
                            <div class="col-12">
                                <label class="form-label">Amenities</label>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="has_water" 
                                                   name="has_water" value="1">
                                            <label class="form-check-label" for="has_water">
                                                <i class="bi bi-droplet me-1"></i>Water Supply
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="has_electricity" 
                                                   name="has_electricity" value="1">
                                            <label class="form-check-label" for="has_electricity">
                                                <i class="bi bi-lightning me-1"></i>Electricity
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="has_road_access" 
                                                   name="has_road_access" value="1">
                                            <label class="form-check-label" for="has_road_access">
                                                <i class="bi bi-signpost me-1"></i>Road Access
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Search Button -->
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-search me-2"></i>Search
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Results Table -->
            <div class="card border-0 shadow-sm mt-4">
                <div class="card-header bg-transparent border-0">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-table me-2"></i>Search Results
                            </h5>
                        </div>
                        <div class="col-md-6">
                            <div class="table-controls">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control" id="resultsSearch" placeholder="Filter results...">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover modern-table" id="searchResultsTable">
                            <thead>
                                <tr>
                                    <th class="sortable" data-sort="location">
                                        <div class="th-content">
                                            Location
                                            <i class="bi bi-arrow-down-up sort-icon"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="size">
                                        <div class="th-content">
                                            Size
                                            <i class="bi bi-arrow-down-up sort-icon"></i>
                                        </div>
                                    </th>
                                    <th class="sortable" data-sort="price">
                                        <div class="th-content">
                                            Price
                                            <i class="bi bi-arrow-down-up sort-icon"></i>
                                        </div>
                                    </th>
                                    <th>Amenities</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="searchResults">
                                <!-- Results will be populated here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <!-- Information Card -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-info-circle me-2"></i>Search Tips
                    </h5>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-3">
                            <i class="bi bi-geo-alt text-primary me-2"></i>
                            <strong>Location:</strong> Search by specific area or neighborhood
                        </li>
                        <li class="mb-3">
                            <i class="bi bi-rulers text-primary me-2"></i>
                            <strong>Size:</strong> Filter by land size range
                        </li>
                        <li class="mb-3">
                            <i class="bi bi-check-circle text-primary me-2"></i>
                            <strong>Amenities:</strong> Find land with specific features
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const searchParams = new URLSearchParams();
    
    for (const [key, value] of formData.entries()) {
        if (value) {
            searchParams.append(key, value);
        }
    }
    
    fetch('api/search_properties.php?' + searchParams.toString())
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('searchResults');
            resultsContainer.innerHTML = '';
            
            if (data.length === 0) {
                resultsContainer.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <i class="bi bi-search text-muted mb-2" style="font-size: 2rem;"></i>
                            <p class="text-muted mb-0">No properties found matching your criteria</p>
                        </td>
                    </tr>
                `;
                return;
            }
            
            data.forEach(property => {
                const amenities = [];
                if (property.has_water) amenities.push('<i class="bi bi-droplet" title="Water Supply"></i>');
                if (property.has_electricity) amenities.push('<i class="bi bi-lightning" title="Electricity"></i>');
                if (property.has_road_access) amenities.push('<i class="bi bi-signpost" title="Road Access"></i>');
                
                resultsContainer.innerHTML += `
                    <tr>
                        <td class="location">${property.location}</td>
                        <td class="size" data-size="${property.size_sqm}">${property.size_sqm} sqm</td>
                        <td class="price" data-price="${property.estimated_price}">RWF ${parseFloat(property.estimated_price).toLocaleString()}</td>
                        <td class="amenities">${amenities.join(' ')}</td>
                        <td>
                            <a href="edit_property.php?id=${property.id}" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button onclick="deleteProperty(${property.id})" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while searching. Please try again.');
        });
});

function deleteProperty(id) {
    if (confirm('Are you sure you want to delete this property?')) {
        fetch('delete_property.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('searchForm').dispatchEvent(new Event('submit'));
            } else {
                alert('Error deleting property: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting. Please try again.');
        });
    }
}
</script>

<style>
/* Table Controls */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 300px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-400);
    z-index: 2;
}

.search-box .form-control {
    padding-left: 2.5rem;
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    background: white;
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: var(--gray-50);
    border-bottom: 2px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}
</style>

<script>
// Search and filter functionality for results table
document.addEventListener('DOMContentLoaded', function() {
    const resultsSearchInput = document.getElementById('resultsSearch');
    const searchResultsTable = document.getElementById('searchResultsTable');
    
    if (resultsSearchInput && searchResultsTable) {
        function filterResultsTable() {
            const searchTerm = resultsSearchInput.value.toLowerCase();
            const rows = searchResultsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const location = row.querySelector('.location')?.textContent.toLowerCase() || '';
                const size = row.querySelector('.size')?.textContent.toLowerCase() || '';
                const price = row.querySelector('.price')?.textContent.toLowerCase() || '';
                const amenities = row.querySelector('.amenities')?.textContent.toLowerCase() || '';
                
                const matchesSearch = location.includes(searchTerm) || 
                                    size.includes(searchTerm) || 
                                    price.includes(searchTerm) || 
                                    amenities.includes(searchTerm);
                
                row.style.display = matchesSearch ? '' : 'none';
            });
        }
        
        resultsSearchInput.addEventListener('input', filterResultsTable);
        
        // Sortable headers
        const sortableHeaders = searchResultsTable.querySelectorAll('.sortable');
        sortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(sortType, this);
            });
        });
        
        function sortTable(sortType, headerElement) {
            const tbody = searchResultsTable.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const isAscending = !headerElement.classList.contains('sort-asc');
            
            // Remove sort classes from all headers
            sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
            
            // Add appropriate sort class
            headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
            
            rows.sort((a, b) => {
                let aVal, bVal;
                
                switch(sortType) {
                    case 'location':
                        aVal = a.querySelector('.location')?.textContent || '';
                        bVal = b.querySelector('.location')?.textContent || '';
                        break;
                    case 'size':
                        aVal = parseFloat(a.querySelector('.size')?.dataset.size || '0');
                        bVal = parseFloat(b.querySelector('.size')?.dataset.size || '0');
                        break;
                    case 'price':
                        aVal = parseFloat(a.querySelector('.price')?.dataset.price || '0');
                        bVal = parseFloat(b.querySelector('.price')?.dataset.price || '0');
                        break;
                    default:
                        return 0;
                }
                
                if (typeof aVal === 'string') {
                    return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                } else {
                    return isAscending ? aVal - bVal : bVal - aVal;
                }
            });
            
            // Reappend sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
    }
});

document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const searchParams = new URLSearchParams();
    
    for (const [key, value] of formData.entries()) {
        if (value) {
            searchParams.append(key, value);
        }
    }
    
    fetch('api/search_properties.php?' + searchParams.toString())
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('searchResults');
            resultsContainer.innerHTML = '';
            
            if (data.length === 0) {
                resultsContainer.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <i class="bi bi-search text-muted mb-2" style="font-size: 2rem;"></i>
                            <p class="text-muted mb-0">No properties found matching your criteria</p>
                        </td>
                    </tr>
                `;
                return;
            }
            
            data.forEach(property => {
                const amenities = [];
                if (property.has_water) amenities.push('<i class="bi bi-droplet" title="Water Supply"></i>');
                if (property.has_electricity) amenities.push('<i class="bi bi-lightning" title="Electricity"></i>');
                if (property.has_road_access) amenities.push('<i class="bi bi-signpost" title="Road Access"></i>');
                
                resultsContainer.innerHTML += `
                    <tr>
                        <td class="location">${property.location}</td>
                        <td class="size" data-size="${property.size_sqm}">${property.size_sqm} sqm</td>
                        <td class="price" data-price="${property.estimated_price}">RWF ${parseFloat(property.estimated_price).toLocaleString()}</td>
                        <td class="amenities">${amenities.join(' ')}</td>
                        <td>
                            <a href="edit_property.php?id=${property.id}" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button onclick="deleteProperty(${property.id})" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while searching. Please try again.');
        });
});

function deleteProperty(id) {
    if (confirm('Are you sure you want to delete this property?')) {
        fetch('delete_property.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('searchForm').dispatchEvent(new Event('submit'));
            } else {
                alert('Error deleting property: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting. Please try again.');
        });
    }
}
</script>

<?php require_once 'includes/footer.php'; ?> 