<?php
require_once 'config/database.php';

echo "Debugging exact match for Huye property...\n\n";

// Test case: Huye, 351 sqm, Commercial, Residential, "School, Market", 5km
$location = 'Huye';
$size_sqm = 351;
$zoning = 'Commercial';
$land_type = 'Residential';
$nearby_amenities = 'School, Market';
$distance_to_city_center = 5;

echo "Looking for:\n";
echo "Location: '$location'\n";
echo "Size: $size_sqm\n";
echo "Zoning: '$zoning'\n";
echo "Land Type: '$land_type'\n";
echo "Amenities: '$nearby_amenities'\n";
echo "Distance: $distance_to_city_center\n\n";

// Check what's actually in the database
$stmt = $conn->prepare("SELECT * FROM original_dataset WHERE location = ? AND size_sqm = ? LIMIT 5");
$stmt->bind_param("sd", $location, $size_sqm);
$stmt->execute();
$result = $stmt->get_result();

echo "Properties in database with Location='$location' and Size=$size_sqm:\n";
while ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . "\n";
    echo "  Location: '" . $row['location'] . "'\n";
    echo "  Size: " . $row['size_sqm'] . "\n";
    echo "  Zoning: '" . $row['zoning'] . "'\n";
    echo "  Land Type: '" . $row['land_type'] . "'\n";
    echo "  Amenities: '" . $row['nearby_amenities'] . "'\n";
    echo "  Distance: " . $row['distance_to_city_center'] . "\n";
    echo "  Price: " . number_format($row['price']) . "\n";
    echo "---\n";
}

// Try exact match query
$stmt = $conn->prepare("SELECT estimated_price FROM properties WHERE location = ? AND size_sqm = ? AND zoning = ? AND land_type = ? AND nearby_amenities = ? LIMIT 1");
$stmt->bind_param("sdsss", $location, $size_sqm, $zoning, $land_type, $nearby_amenities);
$stmt->execute();
$match_result = $stmt->get_result();

if ($match = $match_result->fetch_assoc()) {
    echo "✅ Exact match found in properties table: RWF " . number_format($match['estimated_price']) . "\n";
} else {
    echo "❌ No exact match found in properties table\n";
}

// Check original_dataset table
$stmt = $conn->prepare("SELECT price FROM original_dataset WHERE location = ? AND size_sqm = ? AND zoning = ? AND land_type = ? AND nearby_amenities = ? LIMIT 1");
$stmt->bind_param("sdsss", $location, $size_sqm, $zoning, $land_type, $nearby_amenities);
$stmt->execute();
$match_result = $stmt->get_result();

if ($match = $match_result->fetch_assoc()) {
    echo "✅ Exact match found in original_dataset table: RWF " . number_format($match['price']) . "\n";
} else {
    echo "❌ No exact match found in original_dataset table\n";
}

$conn->close();
?> 