<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Get total users
$stmt = $conn->prepare("SELECT COUNT(*) as total_users FROM users");
if ($stmt) {
    $stmt->execute();
    $total_users = $stmt->get_result()->fetch_assoc()['total_users'];
} else {
    $total_users = 0;
}

// Get total properties
$stmt = $conn->prepare("SELECT COUNT(*) as total_properties FROM properties");
if ($stmt) {
    $stmt->execute();
    $total_properties = $stmt->get_result()->fetch_assoc()['total_properties'];
} else {
    $total_properties = 0;
}

// Get total value
$stmt = $conn->prepare("SELECT SUM(estimated_price) as total_value FROM properties");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $total_value = $result['total_value'] ?? 0;
} else {
    $total_value = 0;
}

// Get average confidence score
$stmt = $conn->prepare("SELECT AVG(confidence_score) as avg_confidence FROM predictions");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $avg_confidence = $result['avg_confidence'] ?? 0;
} else {
    $avg_confidence = 0;
}

// Get active users (last 30 days)
$stmt = $conn->prepare("SELECT COUNT(DISTINCT user_id) as active_users FROM properties WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($stmt) {
    $stmt->execute();
    $active_users = $stmt->get_result()->fetch_assoc()['active_users'];
} else {
    $active_users = 0;
}

// Get prediction accuracy rate
$stmt = $conn->prepare("SELECT AVG(confidence_score) as accuracy_rate FROM predictions WHERE confidence_score >= 80");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $accuracy_rate = $result['accuracy_rate'] ?? 0;
} else {
    $accuracy_rate = 0;
}

// Get recent predictions (last 6 months)
$stmt = $conn->prepare("
    SELECT p.*, u.username, pr.predicted_price, pr.confidence_score, pr.prediction_date,
           CASE 
               WHEN p.has_water = 1 AND p.has_electricity = 1 AND p.has_road_access = 1 THEN 'Fully Developed'
               WHEN p.has_water = 1 OR p.has_electricity = 1 OR p.has_road_access = 1 THEN 'Partially Developed'
               ELSE 'Undeveloped'
           END as property_type
    FROM properties p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    WHERE p.submission_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    ORDER BY p.submission_date DESC
    LIMIT 10
");
if ($stmt) {
    $stmt->execute();
    $recent_predictions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $recent_predictions = [];
}

// Get property type distribution with development status
$stmt = $conn->prepare("
    SELECT 
        CASE 
            WHEN has_water = 1 AND has_electricity = 1 AND has_road_access = 1 THEN 'Fully Developed'
            WHEN has_water = 1 OR has_electricity = 1 OR has_road_access = 1 THEN 'Partially Developed'
            ELSE 'Undeveloped'
        END as development_status,
        COUNT(*) as count,
        AVG(estimated_price) as avg_price
    FROM properties
    GROUP BY development_status
");
if ($stmt) {
    $stmt->execute();
    $development_distribution = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $development_distribution = [];
}

// Get monthly comparison (current year vs previous year)
$stmt = $conn->prepare("
    SELECT 
        MONTH(submission_date) as month,
        YEAR(submission_date) as year,
        COUNT(*) as count,
        AVG(estimated_price) as avg_price
    FROM properties
    WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 24 MONTH)
    GROUP BY YEAR(submission_date), MONTH(submission_date)
    ORDER BY year, month
");
if ($stmt) {
    $stmt->execute();
    $monthly_comparison = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $monthly_comparison = [];
}

// Get location performance comparison
$stmt = $conn->prepare("
    SELECT 
        location,
        COUNT(*) as property_count,
        AVG(estimated_price) as avg_price,
        AVG(pr.confidence_score) as avg_confidence,
        MAX(estimated_price) as max_price,
        MIN(estimated_price) as min_price
    FROM properties p
    LEFT JOIN predictions pr ON p.id = pr.property_id
    GROUP BY location
    HAVING property_count >= 5
    ORDER BY avg_price DESC
    LIMIT 10
");
if ($stmt) {
    $stmt->execute();
    $location_performance = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $location_performance = [];
}

// Get user activity trends
$stmt = $conn->prepare("
    SELECT 
        DATE_FORMAT(submission_date, '%Y-%m') as month,
        COUNT(*) as submissions,
        COUNT(DISTINCT user_id) as active_users,
        AVG(estimated_price) as avg_price
    FROM properties
    WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(submission_date, '%Y-%m')
    ORDER BY month ASC
");
if ($stmt) {
    $stmt->execute();
    $activity_trends = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $activity_trends = [];
}

// Get min and max price
$minMaxStmt = $conn->query("SELECT MIN(estimated_price) as min_price, MAX(estimated_price) as max_price FROM properties");
$minMax = $minMaxStmt->fetch_assoc();
$min_price = (int)$minMax['min_price'];
$max_price = (int)$minMax['max_price'];

// Get all prices
$prices = [];
$res = $conn->query("SELECT estimated_price FROM properties WHERE estimated_price IS NOT NULL ORDER BY estimated_price ASC");
while ($row = $res->fetch_assoc()) {
    $prices[] = (int)$row['estimated_price'];
}

$price_distribution = [];
if (count($prices) > 0) {
    $quantiles = [];
    $n = count($prices);
    for ($i = 0; $i <= 5; $i++) {
        $q = $i / 5;
        $idx = (int)round($q * ($n - 1));
        $quantiles[] = $prices[$idx];
    }
    $labels = [];
    for ($i = 0; $i < 5; $i++) {
        if ($i == 0) {
            $labels[] = 'Under RWF ' . number_format($quantiles[$i+1]);
        } elseif ($i == 4) {
            $labels[] = 'Over RWF ' . number_format($quantiles[$i]);
        } else {
            $labels[] = 'RWF ' . number_format($quantiles[$i]) . ' - RWF ' . number_format($quantiles[$i+1]);
        }
    }
    for ($i = 0; $i < 5; $i++) {
        if ($i == 0) {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE estimated_price < ?");
            $stmt->bind_param("i", $quantiles[$i+1]);
        } elseif ($i == 4) {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE estimated_price >= ?");
            $stmt->bind_param("i", $quantiles[$i]);
        } else {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM properties WHERE estimated_price >= ? AND estimated_price < ?");
            $stmt->bind_param("ii", $quantiles[$i], $quantiles[$i+1]);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $price_distribution[] = [
            'price_range' => $labels[$i],
            'count' => $result['count']
        ];
    }
}

// Get top performing users
$stmt = $conn->prepare("
    SELECT 
        u.username,
        COUNT(p.id) as total_submissions,
        AVG(p.estimated_price) as avg_property_value,
        AVG(pr.confidence_score) as avg_confidence
    FROM users u
    JOIN properties p ON u.id = p.user_id
    LEFT JOIN predictions pr ON p.id = pr.property_id
    WHERE u.role = 'user'
    GROUP BY u.id, u.username
    HAVING total_submissions >= 5
    ORDER BY avg_property_value DESC
    LIMIT 10
");
if ($stmt) {
    $stmt->execute();
    $top_users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $top_users = [];
}

include '../includes/header_logged_in.php';
include '../includes/admin_sidebar.php';
?>

<div class="d-flex">
    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Dashboard Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Admin Dashboard</h1>
                    <p class="text-muted mb-0">Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary" onclick="exportData()">
                        <i class="bi bi-download me-2"></i>Export Data
                    </button>
                    <button type="button" class="btn btn-outline-success" onclick="exportChartData()">
                        <i class="bi bi-graph-up me-2"></i>Export Charts
                    </button>
                    <button type="button" class="btn btn-primary" onclick="refreshDashboard()">
                        <i class="bi bi-arrow-clockwise me-2"></i>Refresh
                    </button>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-people text-primary fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Total Users</h6>
                                    <h4 class="mb-0 fw-bold"><?php echo number_format($total_users); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-success bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-person-check text-success fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Active Users</h6>
                                    <h4 class="mb-0 fw-bold"><?php echo number_format($active_users); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-info bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-building text-info fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Properties</h6>
                                    <h4 class="mb-0 fw-bold"><?php echo number_format($total_properties); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-warning bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-cash text-success fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Total Value</h6>
                                    <h4 class="mb-0 fw-bold">RWF <?php echo number_format($total_value / 1000000, 0); ?>M</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-danger bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-graph-up text-danger fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Confidence</h6>
                                    <h4 class="mb-0 fw-bold"><?php echo number_format($avg_confidence, 1); ?>%</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 stat-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-purple bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="bi bi-check-circle text-purple fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1 small">Accuracy Rate</h6>
                                    <h4 class="mb-0 fw-bold"><?php echo number_format($accuracy_rate, 1); ?>%</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <!-- Activity Trends Comparison -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-gradient-primary text-white border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-graph-up me-2"></i>Activity Trends & User Engagement
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="activityTrendsChart" height="100"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Development Status Distribution -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-gradient-success text-white border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-pie-chart me-2"></i>Development Status
                            </h5>
                        </div>
                        <div class="card-body chart-3d-container position-relative" style="height: 350px; min-height: 300px;">
                            <canvas id="developmentChart"></canvas>
                            <div id="developmentPieLabels" class="pie-labels"></div>
                        </div>
                    </div>
                </div>

                <!-- Location Performance Comparison -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-gradient-info text-white border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-geo-alt me-2"></i>Location Performance Analysis
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="locationPerformanceChart" height="120"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Price Range Distribution -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm chart-card">
                        <div class="card-header bg-gradient-warning text-white border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-bar-chart me-2"></i>Price Range Distribution
                            </h5>
                        </div>
                        <div class="card-body">
                            <canvas id="priceDistributionChart" height="120"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Monthly Performance Comparison -->
                <div class="col-lg-12">
                    <div class="card border-0 shadow-sm chart-card year-bar-mobile-card">
                        <div class="card-header bg-gradient-purple text-white border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-calendar-month me-2"></i>Year-over-Year Comparison
                            </h5>
                        </div>
                        <div class="card-body chart-3d-container position-relative year-bar-container" style="height: 420px; min-height: 340px; width: 100%; max-width: 100vw; display: flex; align-items: stretch; justify-content: stretch;">
                            <canvas id="yearComparisonChart"></canvas>
                            <div id="yearBarLabels" class="bar-labels"></div>
                            <div id="yearBarLegend" class="bar-legend"></div>
                        </div>
                    </div>
                    <style>
                    /* Responsive, modern, stunning mobile design for 3D bar chart */
                    .year-bar-mobile-card {
                        background: rgba(255,255,255,0.85);
                        border-radius: 18px;
                        box-shadow: 0 8px 32px rgba(80,40,120,0.13), 0 1.5px 8px rgba(120,80,180,0.07);
                        overflow: hidden;
                        margin-bottom: 1.5rem;
                    }
                    .year-bar-container {
                        position: relative;
                        width: 100%;
                        min-height: 320px;
                        height: 420px;
                        max-width: 100vw;
                        display: flex;
                        align-items: stretch;
                        justify-content: stretch;
                        background: linear-gradient(135deg, #f3f3fa 60%, #f8e1ff 100%);
                        border-radius: 0 0 18px 18px;
                        box-shadow: 0 2px 12px rgba(120,80,180,0.07);
                    }
                    .bar-labels {
                        position: absolute;
                        top: 0; left: 0; width: 100%; height: 100%;
                        pointer-events: none;
                        z-index: 2;
                    }
                    .bar-label {
                        position: absolute;
                        transform: translate(-50%, -50%);
                        padding: 0.18em 0.7em;
                        border-radius: 8px;
                        background: rgba(255,255,255,0.93);
                        color: #222;
                        font-size: 1.05rem;
                        font-weight: 700;
                        box-shadow: 0 1.5px 6px rgba(120,80,180,0.07);
                        white-space: nowrap;
                        transition: background 0.2s;
                        border: 1.5px solid #eee;
                        min-width: 2.2em;
                        text-align: center;
                        user-select: none;
                    }
                    .bar-label[style*='background: rgb(59, 130, 246)'],
                    .bar-label[style*='background: #3b82f6'] {
                        background: linear-gradient(90deg, #3b82f6 80%, #e0e7ff 100%) !important;
                        color: #fff;
                        border: none;
                    }
                    .bar-label[style*='background: rgb(245, 158, 66)'],
                    .bar-label[style*='background: #f59e42'] {
                        background: linear-gradient(90deg, #f59e42 80%, #fff7e0 100%) !important;
                        color: #fff;
                        border: none;
                    }
                    .bar-label.month-label {
                        background: rgba(255,255,255,0.97);
                        color: #222;
                        font-weight: 800;
                        font-size: 1.01rem;
                        border: 1.5px solid #eee;
                        margin-top: 0.5em;
                        margin-bottom: 0.5em;
                        box-shadow: none;
                    }
                    .bar-legend {
                        position: absolute;
                        top: 12px;
                        right: 18px;
                        z-index: 3;
                        display: flex;
                        flex-direction: column;
                        gap: 0.5em;
                        background: rgba(255,255,255,0.93);
                        border-radius: 8px;
                        box-shadow: 0 1.5px 6px rgba(120,80,180,0.07);
                        padding: 0.5em 1em;
                        font-size: 1.01rem;
                        font-weight: 700;
                        border: 1.5px solid #eee;
                        min-width: 90px;
                        align-items: flex-start;
                    }
                    .bar-legend-item {
                        display: flex;
                        align-items: center;
                        gap: 0.5em;
                    }
                    .bar-legend-dot {
                        width: 18px; height: 18px; border-radius: 50%; display: inline-block;
                        border: 2px solid #fff;
                        box-shadow: 0 1px 3px rgba(120,80,180,0.07);
                    }
                    @media (max-width: 900px) {
                        .year-bar-container { height: 320px; min-height: 220px; }
                        .bar-label { font-size: 0.95rem; padding: 0.13em 0.5em; }
                        .bar-legend { font-size: 0.95rem; padding: 0.4em 0.7em; }
                    }
                    @media (max-width: 600px) {
                        .year-bar-mobile-card { border-radius: 10px; }
                        .year-bar-container { height: 220px; min-height: 140px; border-radius: 0 0 10px 10px; }
                        .bar-label { font-size: 0.82rem; padding: 0.09em 0.35em; border-radius: 5px; min-width: 1.5em; }
                        .bar-label.month-label { font-size: 0.8rem; }
                        .bar-legend { font-size: 0.82rem; padding: 0.25em 0.5em; border-radius: 5px; min-width: 60px; }
                        .bar-legend-dot { width: 12px; height: 12px; }
                    }
                    </style>
                </div>

                <!-- Top Performing Users -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-gradient-dark text-white border-0">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">
                                        <i class="bi bi-trophy me-2"></i>Top Performing Users
                                    </h5>
                                </div>
                                <div class="col-md-6">
                                    <div class="table-controls">
                                        <div class="search-box">
                                            <i class="bi bi-search"></i>
                                            <input type="text" class="form-control" id="userSearch" placeholder="Search users...">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover modern-table" id="topUsersTable">
                                    <thead>
                                        <tr>
                                            <th class="sortable" data-sort="user">
                                                <div class="th-content">
                                                    User
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="submissions">
                                                <div class="th-content">
                                                    Submissions
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="value">
                                                <div class="th-content">
                                                    Avg Value
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="confidence">
                                                <div class="th-content">
                                                    Confidence
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($top_users)): ?>
                                            <?php foreach ($top_users as $user): ?>
                                            <tr>
                                                <td class="user"><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                                <td class="submissions" data-submissions="<?php echo $user['total_submissions']; ?>">
                                                    <span class="badge bg-primary"><?php echo $user['total_submissions']; ?></span>
                                                </td>
                                                <td class="value" data-value="<?php echo $user['avg_property_value']; ?>">
                                                    RWF <?php echo number_format($user['avg_property_value'], 0); ?>
                                                </td>
                                                <td class="confidence" data-confidence="<?php echo $user['avg_confidence']; ?>">
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar bg-success" style="width: <?php echo $user['avg_confidence']; ?>%">
                                                            <?php echo number_format($user['avg_confidence'], 1); ?>%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="4" class="text-center text-muted">No top performing users found.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Predictions -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-gradient-secondary text-white border-0">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">
                                        <i class="bi bi-clock-history me-2"></i>Recent Predictions
                                    </h5>
                                </div>
                                <div class="col-md-6">
                                    <div class="table-controls">
                                        <div class="search-box">
                                            <i class="bi bi-search"></i>
                                            <input type="text" class="form-control" id="predictionSearch" placeholder="Search predictions...">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover modern-table" id="recentPredictionsTable">
                                    <thead>
                                        <tr>
                                            <th class="sortable" data-sort="user">
                                                <div class="th-content">
                                                    User
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="location">
                                                <div class="th-content">
                                                    Location
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="price">
                                                <div class="th-content">
                                                    Price
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="confidence">
                                                <div class="th-content">
                                                    Confidence
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (array_slice($recent_predictions, 0, 8) as $prediction): ?>
                                        <tr>
                                            <td class="user"><?php echo htmlspecialchars($prediction['username']); ?></td>
                                            <td class="location"><?php echo htmlspecialchars($prediction['location']); ?></td>
                                            <td class="price" data-price="<?php echo $prediction['estimated_price']; ?>">
                                                RWF <?php echo number_format($prediction['estimated_price'], 0); ?>
                                            </td>
                                            <td class="confidence" data-confidence="<?php echo $prediction['confidence_score']; ?>">
                                                <span class="badge <?php echo $prediction['confidence_score'] >= 80 ? 'bg-success' : ($prediction['confidence_score'] >= 60 ? 'bg-warning' : 'bg-danger'); ?>">
                                                    <?php echo number_format($prediction['confidence_score'], 1); ?>%
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Modern Card Styles */
.stat-card {
    transition: all 0.3s ease;
    border-radius: 15px;
    overflow: hidden;
}

.stat-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.1) !important;
}

.chart-card {
    border-radius: 15px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.chart-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.1) !important;
}

.stat-icon {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Custom Gradient Backgrounds */
.bg-gradient-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.bg-gradient-success {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.bg-gradient-info {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.bg-gradient-warning {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}

.bg-gradient-purple {
    background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
}

.bg-gradient-dark {
    background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
    color: #333 !important;
}

.bg-gradient-secondary {
    background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
    color: #333 !important;
}

.text-purple {
    color: #8e44ad !important;
}

.bg-purple {
    background-color: #8e44ad !important;
}

/* Progress Bar Enhancements */
.progress {
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    transition: width 1s ease-in-out;
}

/* Table Controls */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 300px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255,255,255,0.8);
    z-index: 2;
}

.search-box .form-control {
    padding-left: 2.5rem;
    border-radius: 20px;
    border: 1px solid rgba(255,255,255,0.3);
    background: rgba(255,255,255,0.1);
    color: white;
}

.search-box .form-control::placeholder {
    color: rgba(255,255,255,0.7);
}

.search-box .form-control:focus {
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.5);
    box-shadow: 0 0 0 0.2rem rgba(255,255,255,0.25);
    color: white;
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: rgba(0,0,0,0.05);
    border-bottom: 2px solid rgba(0,0,0,0.1);
    font-weight: 600;
    color: #333;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: #007bff;
}

.modern-table tbody tr {
    border-bottom: 1px solid rgba(0,0,0,0.05);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background-color: rgba(0,0,0,0.05);
    transform: scale(1.02);
    transition: all 0.2s ease;
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

/* Table Enhancements */
.table-hover tbody tr:hover {
    background-color: rgba(0,0,0,0.05);
    transform: scale(1.02);
    transition: all 0.2s ease;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    
    .sidebar {
        display: none;
    }
}

@media (max-width: 768px) {
    .stat-card {
        margin-bottom: 1rem;
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
    }
}

/* Animation for loading */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card {
    animation: fadeInUp 0.6s ease-out;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-3d"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
// Chart.js default configuration
Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
Chart.defaults.color = '#64748b';

// Register DataLabels plugin
Chart.register(ChartDataLabels);

// Activity Trends Chart (3D Multi-line comparison)
const activityCtx = document.getElementById('activityTrendsChart').getContext('2d');
new Chart(activityCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_column($activity_trends, 'month')); ?>,
        datasets: [
            {
                label: 'Property Submissions',
                data: <?php echo json_encode(array_column($activity_trends, 'submissions')); ?>,
                borderColor: 'rgb(99, 102, 241)',
                backgroundColor: 'rgba(99, 102, 241, 0.3)',
                tension: 0.4,
                fill: true,
                borderWidth: 3
            },
            {
                label: 'Active Users',
                data: <?php echo json_encode(array_column($activity_trends, 'active_users')); ?>,
                borderColor: 'rgb(16, 185, 129)',
                backgroundColor: 'rgba(16, 185, 129, 0.3)',
                tension: 0.4,
                fill: true,
                borderWidth: 3
            }
        ]
    },
    options: {
        responsive: true,
        interaction: {
            intersect: false,
        },
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            },
            datalabels: {
                display: function(context) {
                    return context.datasetIndex === 0; // Show labels for first dataset only
                },
                color: '#333',
                anchor: 'end',
                align: 'top',
                offset: 8,
                font: {
                    weight: 'bold',
                    size: 11
                },
                formatter: function(value) {
                    return value;
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        },
        // 3D Configuration
        layout: {
            padding: {
                top: 20,
                bottom: 20
            }
        },
        elements: {
            point: {
                radius: 6,
                hoverRadius: 8,
                borderWidth: 2
            }
        }
    }
});

// Development Status Distribution (3D Doughnut Chart)
const developmentCtx = document.getElementById('developmentChart').getContext('2d');
new Chart(developmentCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($development_distribution, 'development_status')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_column($development_distribution, 'count')); ?>,
            backgroundColor: [
                'rgba(34, 197, 94, 0.9)',
                'rgba(251, 191, 36, 0.9)',
                'rgba(239, 68, 68, 0.9)'
            ],
            borderColor: '#ffffff',
            borderWidth: 2,
            hoverOffset: 15,
            weight: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 20,
                    usePointStyle: true,
                    font: {
                        size: 12
                    }
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.raw;
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((value / total) * 100).toFixed(1);
                        return `${label}: ${value} (${percentage}%)`;
                    }
                }
            },
            datalabels: {
                color: '#fff',
                font: {
                    weight: 'bold',
                    size: 12
                },
                formatter: function(value, context) {
                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                    const percentage = ((value / total) * 100).toFixed(1);
                    return `${value}\n(${percentage}%)`;
                }
            }
        },
        // 3D Configuration
        layout: {
            padding: {
                top: 10,
                bottom: 10
            }
        },
        cutout: '60%'
    }
});

// Location Performance Chart (3D Bar Chart with dual axis)
const locationCtx = document.getElementById('locationPerformanceChart').getContext('2d');
new Chart(locationCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($location_performance, 'location')); ?>,
        datasets: [
            {
                label: 'Average Price (RWF)',
                data: <?php echo json_encode(array_column($location_performance, 'avg_price')); ?>,
                backgroundColor: 'rgba(59, 130, 246, 0.9)',
                borderColor: 'rgba(59, 130, 246, 1)',
                borderWidth: 2,
                yAxisID: 'y',
                borderRadius: 8,
                borderSkipped: false
            },
            {
                label: 'Property Count',
                data: <?php echo json_encode(array_column($location_performance, 'property_count')); ?>,
                backgroundColor: 'rgba(16, 185, 129, 0.9)',
                borderColor: 'rgba(16, 185, 129, 1)',
                borderWidth: 2,
                yAxisID: 'y1',
                borderRadius: 8,
                borderSkipped: false
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top'
            },
            tooltip: {
                mode: 'index',
                intersect: false
            },
            datalabels: {
                color: '#333',
                anchor: 'end',
                align: 'top',
                offset: 4,
                font: {
                    weight: 'bold',
                    size: 10
                },
                formatter: function(value, context) {
                    if (context.datasetIndex === 0) {
                        return 'RWF ' + Math.round(value / 1000000) + 'M';
                    } else {
                        return value;
                    }
                }
            }
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                title: {
                    display: true,
                    text: 'Average Price (RWF)'
                },
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                title: {
                    display: true,
                    text: 'Property Count'
                },
                grid: {
                    drawOnChartArea: false,
                },
            },
            x: {
                grid: {
                    display: false
                }
            }
        },
        // 3D Configuration
        layout: {
            padding: {
                top: 20,
                bottom: 20
            }
        },
        elements: {
            bar: {
                borderWidth: 2
            }
        }
    }
});

// Price Distribution Chart (3D Horizontal Bar)
const priceCtx = document.getElementById('priceDistributionChart').getContext('2d');
new Chart(priceCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($price_distribution, 'price_range')); ?>,
        datasets: [{
            label: 'Properties',
            data: <?php echo json_encode(array_column($price_distribution, 'count')); ?>,
            backgroundColor: [
                'rgba(34, 197, 94, 0.9)',
                'rgba(59, 130, 246, 0.9)',
                'rgba(251, 191, 36, 0.9)',
                'rgba(147, 51, 234, 0.9)',
                'rgba(239, 68, 68, 0.9)'
            ],
            borderColor: [
                'rgba(34, 197, 94, 1)',
                'rgba(59, 130, 246, 1)',
                'rgba(251, 191, 36, 1)',
                'rgba(147, 51, 234, 1)',
                'rgba(239, 68, 68, 1)'
            ],
            borderWidth: 2,
            borderRadius: 10,
            borderSkipped: false
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return `${context.parsed.x} properties in ${context.label}`;
                    }
                }
            },
            datalabels: {
                color: '#333',
                anchor: 'end',
                align: 'center',
                offset: 8,
                font: {
                    weight: 'bold',
                    size: 11
                },
                formatter: function(value, context) {
                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                    const percentage = ((value / total) * 100).toFixed(1);
                    return `${value} (${percentage}%)`;
                }
            }
        },
        scales: {
            x: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                },
                title: {
                    display: true,
                    text: 'Number of Properties'
                }
            },
            y: {
                grid: {
                    display: false
                }
            }
        },
        // 3D Configuration
        layout: {
            padding: {
                left: 20,
                right: 20
            }
        },
        elements: {
            bar: {
                borderWidth: 2
            }
        }
    }
});

// --- 3D Bar Chart: Modern, Responsive, Single Renderer ---
(function renderYear3DBar() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const currentYear = new Date().getFullYear();
const previousYear = currentYear - 1;
const currentYearData = new Array(12).fill(0);
const previousYearData = new Array(12).fill(0);
<?php foreach ($monthly_comparison as $data): ?>
        const month = <?php echo $data['month']; ?> - 1;
    const year = <?php echo $data['year']; ?>;
    const count = <?php echo $data['count']; ?>;
    if (year === currentYear) {
        currentYearData[month] = count;
    } else if (year === previousYear) {
        previousYearData[month] = count;
    }
<?php endforeach; ?>
    const container = document.getElementById('yearComparisonChart').parentElement;
    const chartCanvas = document.getElementById('yearComparisonChart');
    const labelContainer = document.getElementById('yearBarLabels');
    const legendContainer = document.getElementById('yearBarLegend');
    chartCanvas.style.display = 'none';
    // Remove any old renderers
    Array.from(container.querySelectorAll('canvas')).forEach(c => {
        if (c !== chartCanvas) c.remove();
    });
    // Scene, camera, renderer
    const scene = new THREE.Scene();
    let width = container.clientWidth;
    let height = container.clientHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setClearColor(0xffffff, 0);
    renderer.setSize(width, height);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    container.appendChild(renderer.domElement);
    let camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 1000);
    camera.position.set(0, 10, 28);
    camera.lookAt(0, 0, 0);
    // Lighting
    scene.add(new THREE.AmbientLight(0xffffff, 0.95));
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(10, 20, 20);
    dirLight.castShadow = true;
    scene.add(dirLight);
    // Glassy floor
    const floorGeo = new THREE.CircleGeometry(12, 64);
    const floorMat = new THREE.MeshPhysicalMaterial({ color: 0xf3f3fa, metalness: 0.2, roughness: 0.1, transmission: 0.7, opacity: 0.7, transparent: true, clearcoat: 1, clearcoatRoughness: 0.1 });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -4.5;
    scene.add(floor);
    // Subtle grid
    const grid = new THREE.GridHelper(24, 24, 0xeaeaea, 0xf3f3fa);
    grid.position.y = -4.5;
    scene.add(grid);
    // Bar chart group
    const barGroup = new THREE.Group();
    scene.add(barGroup);
    // Bar settings
    let barWidth = 1.2;
    let barDepth = 2.1;
    let gap = 1.5;
    let yMax = Math.max(...currentYearData, ...previousYearData) * 1.18 + 1;
    const colors = ['#3b82f6', '#f59e42'];
    // Draw bars for each month
    function drawBars() {
        // Remove old bars
        while (barGroup.children.length) barGroup.remove(barGroup.children[0]);
        for (let i = 0; i < 12; i++) {
            // Current year bar
            const h1 = currentYearData[i] / yMax * 9.5;
            const geo1 = new THREE.BoxGeometry(barWidth, h1, barDepth);
            const mat1 = new THREE.MeshPhysicalMaterial({ color: colors[0], metalness: 0.4, roughness: 0.13, clearcoat: 0.9, transparent: true, opacity: 0.98 });
            const bar1 = new THREE.Mesh(geo1, mat1);
            bar1.position.x = i * (barWidth + gap) - ((barWidth + gap) * 11) / 2;
            bar1.position.y = h1 / 2 - 4.5;
            bar1.position.z = -barDepth / 2 - 0.3;
            bar1.castShadow = true;
            bar1.receiveShadow = true;
            barGroup.add(bar1);
            // Previous year bar
            const h2 = previousYearData[i] / yMax * 9.5;
            const geo2 = new THREE.BoxGeometry(barWidth, h2, barDepth);
            const mat2 = new THREE.MeshPhysicalMaterial({ color: colors[1], metalness: 0.4, roughness: 0.13, clearcoat: 0.9, transparent: true, opacity: 0.88 });
            const bar2 = new THREE.Mesh(geo2, mat2);
            bar2.position.x = i * (barWidth + gap) - ((barWidth + gap) * 11) / 2;
            bar2.position.y = h2 / 2 - 4.5;
            bar2.position.z = barDepth / 2 + 0.3;
            bar2.castShadow = true;
            bar2.receiveShadow = true;
            barGroup.add(bar2);
        }
    }
    drawBars();
    // Mouse controls
    let isMouseDown = false;
    let lastMouseX = 0;
    let lastMouseY = 0;
    let rotationY = 0;
    let rotationX = -0.18;
    renderer.domElement.addEventListener('mousedown', (e) => {
        isMouseDown = true;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
    });
    window.addEventListener('mouseup', () => { isMouseDown = false; });
    window.addEventListener('mouseleave', () => { isMouseDown = false; });
    renderer.domElement.addEventListener('mousemove', (e) => {
        if (!isMouseDown) return;
        const dx = e.clientX - lastMouseX;
        const dy = e.clientY - lastMouseY;
        rotationY += dx * 0.01;
        rotationX += dy * 0.01;
        rotationX = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, rotationX));
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
    });
    renderer.domElement.addEventListener('wheel', (e) => {
        e.preventDefault();
        camera.position.z += e.deltaY * 0.01;
        camera.position.z = Math.max(10, Math.min(38, camera.position.z));
    });
    // Responsive resize
    function handleResize() {
        width = container.clientWidth;
        height = container.clientHeight;
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        drawBars();
    }
    window.addEventListener('resize', handleResize);
    // HTML overlays for axis and values
    function updateBarLabels() {
        labelContainer.innerHTML = '';
        for (let i = 0; i < 12; i++) {
            // Current year label
            const h1 = currentYearData[i] / yMax * 9.5;
            const pos1 = new THREE.Vector3(i * (barWidth + gap) - ((barWidth + gap) * 11) / 2, h1 - 4.5 + 0.7, -barDepth / 2 - 0.3);
            pos1.applyMatrix4(barGroup.matrixWorld);
            pos1.project(camera);
            const cx1 = (pos1.x * 0.5 + 0.5) * container.clientWidth;
            const cy1 = (-pos1.y * 0.5 + 0.5) * container.clientHeight;
            const label1 = document.createElement('div');
            label1.className = 'bar-label';
            label1.style.left = `${cx1}px`;
            label1.style.top = `${cy1}px`;
            label1.style.background = colors[0];
            label1.style.fontSize = '16px';
            label1.style.fontWeight = '800';
            label1.innerHTML = `<b>${currentYearData[i]}</b>`;
            labelContainer.appendChild(label1);
            // Previous year label
            const h2 = previousYearData[i] / yMax * 9.5;
            const pos2 = new THREE.Vector3(i * (barWidth + gap) - ((barWidth + gap) * 11) / 2, h2 - 4.5 + 0.7, barDepth / 2 + 0.3);
            pos2.applyMatrix4(barGroup.matrixWorld);
            pos2.project(camera);
            const cx2 = (pos2.x * 0.5 + 0.5) * container.clientWidth;
            const cy2 = (-pos2.y * 0.5 + 0.5) * container.clientHeight;
            const label2 = document.createElement('div');
            label2.className = 'bar-label';
            label2.style.left = `${cx2}px`;
            label2.style.top = `${cy2}px`;
            label2.style.background = colors[1];
            label2.style.fontSize = '16px';
            label2.style.fontWeight = '800';
            label2.innerHTML = `<b>${previousYearData[i]}</b>`;
            labelContainer.appendChild(label2);
            // Month label (bottom)
            const posMonth = new THREE.Vector3(i * (barWidth + gap) - ((barWidth + gap) * 11) / 2, -5.5, 0);
            posMonth.applyMatrix4(barGroup.matrixWorld);
            posMonth.project(camera);
            const cxm = (posMonth.x * 0.5 + 0.5) * container.clientWidth;
            const cym = (-posMonth.y * 0.5 + 0.5) * container.clientHeight;
            const monthLabel = document.createElement('div');
            monthLabel.className = 'bar-label month-label';
            monthLabel.style.left = `${cxm}px`;
            monthLabel.style.top = `${cym}px`;
            monthLabel.style.background = 'rgba(255,255,255,0.97)';
            monthLabel.style.color = '#222';
            monthLabel.style.fontWeight = '800';
            monthLabel.style.fontSize = '15px';
            monthLabel.innerHTML = `<b>${months[i]}</b>`;
            labelContainer.appendChild(monthLabel);
        }
    }
    // HTML legend
    legendContainer.innerHTML = `<div class='bar-legend-item'><span class='bar-legend-dot' style='background:${colors[0]}'></span> <b>${currentYear}</b></div><div class='bar-legend-item'><span class='bar-legend-dot' style='background:${colors[1]}'></span> <b>${previousYear}</b></div>`;
    // Animation loop
    function animate() {
        barGroup.rotation.y = rotationY;
        barGroup.rotation.x = rotationX;
        renderer.render(scene, camera);
        updateBarLabels();
        requestAnimationFrame(animate);
    }
    animate();
})();

// Export Data Function (Enhanced)
function exportData() {
    const exportModal = `
        <div class="modal fade" id="exportModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Export Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-3">Choose your export format:</p>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card border-primary">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-primary">
                                            <i class="bi bi-file-earmark-text me-2"></i>CSV Export
                                        </h6>
                                        <p class="card-text small">Complete system data in a single CSV file with all analytics</p>
                                        <button type="button" class="btn btn-primary btn-sm" onclick="performCSVExport()">
                                            <i class="bi bi-download me-1"></i>Download CSV
                                        </button>
                        </div>
                        </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-success">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-success">
                                            <i class="bi bi-file-earmark-zip me-2"></i>Comprehensive Export
                                        </h6>
                                        <p class="card-text small">Multiple CSV files with detailed system analysis</p>
                                        <button type="button" class="btn btn-success btn-sm" onclick="performComprehensiveExport()">
                                            <i class="bi bi-download me-1"></i>Download ZIP
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-info">
                                            <i class="bi bi-graph-up me-2"></i>Chart Data
                                        </h6>
                                        <p class="card-text small">Raw chart data for creating custom visualizations</p>
                                        <button type="button" class="btn btn-info btn-sm" onclick="performChartExport()">
                                            <i class="bi bi-download me-1"></i>Download Charts
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h6>Export Options Include:</h6>
                            <ul class="small">
                                <li><strong>CSV Export:</strong> Complete system data in one file with summary, user stats, location analytics, and detailed properties</li>
                                <li><strong>Comprehensive Export:</strong> Multiple CSV files with detailed system analysis and summary report</li>
                                <li><strong>Chart Data:</strong> Raw data for creating charts in Excel or other tools</li>
                                <li>All exports exclude empty/null values for cleaner data</li>
                                <li>Includes performance metrics and system analytics</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', exportModal);
    const modal = new bootstrap.Modal(document.getElementById('exportModal'));
    modal.show();
    
    // Clean up modal after hiding
    document.getElementById('exportModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

function performCSVExport() {
    // Show loading message
    showNotification('Preparing CSV export...', 'info');
    
    // Redirect to CSV export
    window.location.href = 'export.php?type=csv';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function performComprehensiveExport() {
    // Show loading message
    showNotification('Preparing comprehensive export...', 'info');
    
    // Redirect to comprehensive export
    window.location.href = 'export.php?type=comprehensive';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function performChartExport() {
    // Show loading message
    showNotification('Preparing chart data export...', 'info');
    
    // Redirect to chart export
    window.location.href = 'export_charts.php?chart=all';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('exportModal')).hide();
}

function exportChartData() {
    const chartModal = `
        <div class="modal fade" id="chartExportModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Export Chart Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-3">Choose which chart data to export:</p>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card border-success">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-success">
                                            <i class="bi bi-file-earmark-zip me-2"></i>All Charts
                                        </h6>
                                        <p class="card-text small">Export data for all dashboard charts in multiple CSV files</p>
                                        <button type="button" class="btn btn-success btn-sm" onclick="exportAllCharts()">
                                            <i class="bi bi-download me-1"></i>Download All
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card border-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title text-info">
                                            <i class="bi bi-file-earmark-text me-2"></i>Individual Charts
                                        </h6>
                                        <p class="card-text small">Export specific chart data in separate CSV files</p>
                                        <button type="button" class="btn btn-info btn-sm" onclick="showIndividualCharts()">
                                            <i class="bi bi-list me-1"></i>Select Charts
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="individualChartsList" class="mt-4" style="display: none;">
                            <h6>Select Individual Charts:</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartActivity" value="activity_trends">
                                        <label class="form-check-label" for="chartActivity">Activity Trends</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartDevelopment" value="development_status">
                                        <label class="form-check-label" for="chartDevelopment">Development Status</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartLocation" value="location_performance">
                                        <label class="form-check-label" for="chartLocation">Location Performance</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartPrice" value="price_distribution">
                                        <label class="form-check-label" for="chartPrice">Price Distribution</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartUsers" value="user_activity">
                                        <label class="form-check-label" for="chartUsers">User Activity</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="chartConfidence" value="confidence_distribution">
                                        <label class="form-check-label" for="chartConfidence">Confidence Distribution</label>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="button" class="btn btn-primary btn-sm" onclick="exportSelectedCharts()">
                                    <i class="bi bi-download me-1"></i>Export Selected
                                </button>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h6>Chart Data Export Includes:</h6>
                            <ul class="small">
                                <li>Raw data for creating charts in Excel, Google Sheets, or other tools</li>
                                <li>Properly formatted CSV files with headers</li>
                                <li>Instructions for creating charts from the data</li>
                                <li>All metrics and calculations used in dashboard charts</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', chartModal);
    const modal = new bootstrap.Modal(document.getElementById('chartExportModal'));
    modal.show();
    
    // Clean up modal after hiding
    document.getElementById('chartExportModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

function exportAllCharts() {
    // Show loading message
    showNotification('Preparing chart data export...', 'info');
    
    // Redirect to comprehensive chart export
    window.location.href = 'export_charts.php?chart=all';
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('chartExportModal')).hide();
}

function showIndividualCharts() {
    document.getElementById('individualChartsList').style.display = 'block';
}

function exportSelectedCharts() {
    const selectedCharts = [];
    const checkboxes = document.querySelectorAll('#individualChartsList input[type="checkbox"]:checked');
    
    checkboxes.forEach(checkbox => {
        selectedCharts.push(checkbox.value);
    });
    
    if (selectedCharts.length === 0) {
        showNotification('Please select at least one chart to export.', 'warning');
        return;
    }
    
    // Show loading message
    showNotification('Preparing selected chart data...', 'info');
    
    // For multiple charts, we'll export them one by one
    if (selectedCharts.length === 1) {
        window.location.href = 'export_charts.php?chart=' + selectedCharts[0];
    } else {
        // For multiple charts, we'll create a ZIP with all selected charts
        // This would require a more complex implementation
        showNotification('Multiple chart export coming soon!', 'info');
    }
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('chartExportModal')).hide();
}

function refreshDashboard() {
    // Show loading indicator
    showNotification('Refreshing dashboard...', 'info');
    
    // Simulate refresh (in real implementation, this would reload the page or fetch new data)
    setTimeout(() => {
        location.reload();
    }, 1000);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Real-time updates simulation (in production, use WebSocket or Server-Sent Events)
setInterval(() => {
    // This would typically fetch updated data from the server
    // For demo purposes, we'll just update timestamps
    const timeElements = document.querySelectorAll('.last-updated');
    timeElements.forEach(el => {
        el.textContent = 'Last updated: ' + new Date().toLocaleTimeString();
    });
}, 60000); // Update every minute

// Initialize tooltips for better UX
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips if available
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });
    
    // Add loading animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
});

// Search and filter functionality for dashboard tables
document.addEventListener('DOMContentLoaded', function() {
    // Top Users Table
    const userSearchInput = document.getElementById('userSearch');
    const topUsersTable = document.getElementById('topUsersTable');
    
    if (userSearchInput && topUsersTable) {
        function filterTopUsersTable() {
            const searchTerm = userSearchInput.value.toLowerCase();
            const rows = topUsersTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const user = row.querySelector('.user')?.textContent.toLowerCase() || '';
                const submissions = row.querySelector('.submissions')?.textContent.toLowerCase() || '';
                const value = row.querySelector('.value')?.textContent.toLowerCase() || '';
                const confidence = row.querySelector('.confidence')?.textContent.toLowerCase() || '';
                
                const matchesSearch = user.includes(searchTerm) || 
                                    submissions.includes(searchTerm) || 
                                    value.includes(searchTerm) || 
                                    confidence.includes(searchTerm);
                
                row.style.display = matchesSearch ? '' : 'none';
            });
        }
        
        userSearchInput.addEventListener('input', filterTopUsersTable);
        
        // Sortable headers for top users
        const topUserSortableHeaders = topUsersTable.querySelectorAll('.sortable');
        topUserSortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(topUsersTable, sortType, this);
            });
        });
    }
    
    // Recent Predictions Table
    const predictionSearchInput = document.getElementById('predictionSearch');
    const recentPredictionsTable = document.getElementById('recentPredictionsTable');
    
    if (predictionSearchInput && recentPredictionsTable) {
        function filterPredictionsTable() {
            const searchTerm = predictionSearchInput.value.toLowerCase();
            const rows = recentPredictionsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const user = row.querySelector('.user')?.textContent.toLowerCase() || '';
                const location = row.querySelector('.location')?.textContent.toLowerCase() || '';
                const price = row.querySelector('.price')?.textContent.toLowerCase() || '';
                const confidence = row.querySelector('.confidence')?.textContent.toLowerCase() || '';
                
                const matchesSearch = user.includes(searchTerm) || 
                                    location.includes(searchTerm) || 
                                    price.includes(searchTerm) || 
                                    confidence.includes(searchTerm);
                
                row.style.display = matchesSearch ? '' : 'none';
            });
        }
        
        predictionSearchInput.addEventListener('input', filterPredictionsTable);
        
        // Sortable headers for predictions
        const predictionSortableHeaders = recentPredictionsTable.querySelectorAll('.sortable');
        predictionSortableHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const sortType = this.dataset.sort;
                sortTable(recentPredictionsTable, sortType, this);
            });
        });
    }
    
    function sortTable(table, sortType, headerElement) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const isAscending = !headerElement.classList.contains('sort-asc');
        
        // Remove sort classes from all headers in this table
        const allHeaders = table.querySelectorAll('.sortable');
        allHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        
        // Add appropriate sort class
        headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        
        rows.sort((a, b) => {
            let aVal, bVal;
            
            switch(sortType) {
                case 'user':
                    aVal = a.querySelector('.user')?.textContent || '';
                    bVal = b.querySelector('.user')?.textContent || '';
                    break;
                case 'location':
                    aVal = a.querySelector('.location')?.textContent || '';
                    bVal = b.querySelector('.location')?.textContent || '';
                    break;
                case 'submissions':
                    aVal = parseInt(a.querySelector('.submissions')?.dataset.submissions || '0');
                    bVal = parseInt(b.querySelector('.submissions')?.dataset.submissions || '0');
                    break;
                case 'value':
                    aVal = parseFloat(a.querySelector('.value')?.dataset.value || '0');
                    bVal = parseFloat(b.querySelector('.value')?.dataset.value || '0');
                    break;
                case 'price':
                    aVal = parseFloat(a.querySelector('.price')?.dataset.price || '0');
                    bVal = parseFloat(b.querySelector('.price')?.dataset.price || '0');
                    break;
                case 'confidence':
                    aVal = parseFloat(a.querySelector('.confidence')?.dataset.confidence || '0');
                    bVal = parseFloat(b.querySelector('.confidence')?.dataset.confidence || '0');
                    break;
                default:
                    return 0;
            }
            
            if (typeof aVal === 'string') {
                return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
            } else {
                return isAscending ? aVal - bVal : bVal - aVal;
            }
        });
        
        // Reappend sorted rows
        rows.forEach(row => tbody.appendChild(row));
    }
});

// Performance monitoring
const observer = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
            console.log('Dashboard load time:', entry.loadEventEnd - entry.loadEventStart, 'ms');
        }
    }
});
observer.observe({entryTypes: ['navigation']});
</script>
<style>
.bar-labels {
    position: absolute;
    left: 0; top: 0; width: 100%; height: 100%;
    pointer-events: none;
    z-index: 10;
}
.bar-label {
    position: absolute;
    transform: translate(-50%, -50%);
    background: #3b82f6;
    border-radius: 7px;
    padding: 7px 16px 6px 16px;
    font-size: 16px;
    color: #fff;
    font-family: 'Poppins', Arial, sans-serif;
    box-shadow: 0 2px 8px 0 rgba(31, 38, 135, 0.08);
    white-space: nowrap;
    min-width: 36px;
    text-align: center;
    font-weight: 800;
    border: 1.5px solid #e3e8f0;
    pointer-events: none;
    user-select: none;
    opacity: 0.98;
    letter-spacing: 0.5px;
}
.bar-label.month-label {
    background: rgba(255,255,255,0.97) !important;
    color: #222;
    font-size: 15px;
    font-weight: 800;
    border: 1.5px solid #eee;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    box-shadow: none;
}
.bar-legend {
    position: absolute;
    top: 12px;
    right: 24px;
    z-index: 20;
    display: flex;
    gap: 18px;
    font-size: 16px;
    font-family: 'Poppins', Arial, sans-serif;
    align-items: center;
}
.bar-legend-item {
    display: flex;
    align-items: center;
    gap: 7px;
}
.bar-legend-dot {
    display: inline-block;
    width: 18px; height: 18px;
    border-radius: 50%;
    border: 2.5px solid #fff;
    box-shadow: 0 1px 3px #bbb2;
}
</style>

<?php include '../includes/footer.php'; ?> 