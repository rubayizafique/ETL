<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: ../login.php');
    exit;
}

// Handle user status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $user_id = $_POST['user_id'];
    
    if ($_POST['action'] === 'delete') {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND id != ?");
        if ($stmt) {
            $stmt->bind_param("ii", $user_id, $_SESSION['user_id']);
            $stmt->execute();
        }
    }
    
    header('Location: users.php');
    exit;
}

// Get all users with their property counts
$query = "
    SELECT u.*, 
           COUNT(p.id) as total_properties
    FROM users u
    LEFT JOIN properties p ON u.id = p.user_id
    GROUP BY u.id, u.username, u.password, u.email, u.role, u.created_at
    ORDER BY u.created_at DESC
";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/header_logged_in.php';
include '../includes/admin_sidebar.php';
?>

<div class="d-flex">
    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Enhanced Header Section -->
            <div class="header-section mb-5">
                <div class="row align-items-center">
                    <div class="col-lg-8">
                        <div class="page-title-wrapper">
                            <h1 class="page-title">User Management</h1>
                            <p class="page-subtitle">Manage system users, permissions, and access control</p>
                            <div class="stats-row mt-3">
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo count($users); ?></span>
                                    <span class="stat-label">Total Users</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo count(array_filter($users, fn($u) => $u['role'] === 'admin')); ?></span>
                                    <span class="stat-label">Administrators</span>
                                </div>
                            </div>
                        </div>
                </div>
                    <div class="col-lg-4 text-lg-end">
                        <div class="action-buttons">
                            <button type="button" class="btn btn-primary btn-modern" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                <i class="bi bi-person-plus me-2"></i>
                                <span>Add New User</span>
                            </button>
                            <button class="btn btn-outline-secondary btn-modern ms-2" onclick="refreshTable()">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                            <a href="../logout.php" class="btn btn-outline-danger btn-modern ms-2 d-lg-none">
                                <i class="bi bi-box-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Enhanced Users Table -->
            <div class="table-container">
                <div class="table-header">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h5 class="table-title mb-0">User Directory</h5>
                        </div>
                        <div class="col-md-6">
                            <div class="table-controls">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control" id="userSearch" placeholder="Search users...">
                                </div>
                                <div class="filter-dropdown ms-2">
                                    <select class="form-select" id="statusFilter">
                                        <option value="">All Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                    <div class="table-responsive">
                        <table class="table table-hover" id="usersTable">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Email</th>
                                <th>Role</th>
                                    <th>Status</th>
                                <th>Last Login</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (
    $users as $user): ?>
                            <tr class="user-row" data-user-id="<?php echo $user['id']; ?>">
                                <td>
                                    <div class="user-info">
                                        <div class="user-avatar">
                                            <?php if ($user['role'] === 'admin'): ?>
                                                <div class="avatar-circle admin-avatar">
                                                    <i class="bi bi-shield-fill-check"></i>
                                                </div>
                                            <?php else: ?>
                                                <div class="avatar-circle user-avatar">
                                                    <i class="bi bi-person-fill"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="user-details">
                                            <span class="user-name badge bg-secondary"><?php echo htmlspecialchars($user['username']); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="contact-info">
                                        <a href="mailto:<?php echo htmlspecialchars($user['email']); ?>" class="email text-decoration-none">
                                            <i class="bi bi-envelope-fill me-1"></i>
                                            <?php echo htmlspecialchars($user['email']); ?>
                                        </a>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($user['role'] === 'admin'): ?>
                                        <span class="badge bg-primary">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">User</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge status-active">Active</span>
                                </td>
                                <td>
                                    <div class="joined-date">
                                        <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="action-buttons-group">
                                        <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" 
                                                        class="btn btn-action btn-delete"
                                                        title="Delete User">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                </div>
                
                <!-- Table Footer -->
                <div class="table-footer">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <span class="table-info">Showing <?php echo count($users); ?> users</span>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <nav>
                                <ul class="pagination pagination-sm mb-0">
                                    <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addUserForm" method="POST" action="add_user.php">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('addUserForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('add_user.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            alert('User created successfully');
            // Close modal
            bootstrap.Modal.getInstance(document.getElementById('addUserModal')).hide();
            // Refresh the page to show new user
            window.location.reload();
        } else {
            // Show error message
            alert(data.error || 'Error creating user');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error creating user');
    });
});
</script>

<style>
/* Modern Design System */
:root {
    --primary-color: #6366f1;
    --primary-light: #a5b4fc;
    --primary-dark: #4f46e5;
    --success-color: #10b981;
    --warning-color: #f59e0b;
    --danger-color: #ef4444;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    --border-radius: 12px;
    --border-radius-lg: 16px;
    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}

/* Enhanced Header Section */
.header-section {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
    border-radius: var(--border-radius-lg);
    padding: 2rem;
    color: white;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}

.header-section::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    transform: translate(50%, -50%);
}

.page-title {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    color: white;
}

.page-subtitle {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 0;
}

.stats-row {
    display: flex;
    gap: 2rem;
    flex-wrap: wrap;
}

.stat-item {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.stat-number {
    font-size: 2rem;
    font-weight: 700;
    line-height: 1;
}

.stat-label {
    font-size: 0.875rem;
    opacity: 0.8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Modern Button Styles */
.btn-modern {
    border-radius: var(--border-radius);
    padding: 0.75rem 1.5rem;
    font-weight: 600;
    transition: all 0.2s ease;
    border: 2px solid transparent;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-modern:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.btn-primary.btn-modern {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    border-color: var(--primary-color);
}

.btn-outline-secondary.btn-modern {
    color: var(--gray-600);
    border-color: var(--gray-300);
    background: white;
}

.btn-outline-secondary.btn-modern:hover {
    background: var(--gray-50);
    border-color: var(--gray-400);
}

/* Enhanced Table Container */
.table-container {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.table-header {
    background: var(--gray-50);
    padding: 1.5rem;
    border-bottom: 1px solid var(--gray-200);
}

.table-title {
    color: var(--gray-800);
    font-weight: 600;
}

.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 300px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-400);
    z-index: 2;
}

.search-box .form-control {
    padding-left: 2.5rem;
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    background: white;
}

.filter-dropdown .form-select {
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    min-width: 120px;
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: var(--gray-50);
    border-bottom: 2px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}

/* User Info Styles */
.user-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.user-avatar {
    position: relative;
}

.avatar-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
}

.admin-avatar {
    background: linear-gradient(135deg, #3498db, #2980b9);
}

.user-avatar {
    background: linear-gradient(135deg, #95a5a6, #7f8c8d);
}

.status-indicator {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid white;
}

.status-indicator.online {
    background-color: #2ecc71;
}

.status-indicator.offline {
    background-color: #95a5a6;
}

.user-details {
    display: flex;
    flex-direction: column;
}

.badge {
    font-weight: 500;
    padding: 0.5em 0.75em;
    font-size: 0.9rem;
}

.contact-info {
    color: #2c3e50;
}

.contact-info a {
    color: inherit;
}

.contact-info a:hover {
    color: #3498db;
}

/* Property Stats */
.property-stats {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.property-count {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--gray-800);
    line-height: 1;
}

.property-label {
    font-size: 0.75rem;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Price Info */
.price-info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.price-amount {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--success-color);
    line-height: 1;
}

.price-label {
    font-size: 0.75rem;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.no-data {
    color: var(--gray-400);
    font-style: italic;
    font-size: 0.9rem;
}

/* Performance/Confidence Score */
.confidence-score {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    width: 100%;
}

.confidence-bar {
    flex: 1;
    height: 8px;
    background: var(--gray-200);
    border-radius: 4px;
    overflow: hidden;
    position: relative;
}

.confidence-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--danger-color) 0%, var(--warning-color) 50%, var(--success-color) 100%);
    border-radius: 4px;
    transition: width 0.3s ease;
}

.confidence-text {
    font-weight: 600;
    color: var(--gray-700);
    font-size: 0.9rem;
    min-width: 40px;
    text-align: right;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-active {
    background: rgba(16, 185, 129, 0.1);
    color: var(--success-color);
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.status-inactive {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger-color);
    border: 1px solid rgba(239, 68, 68, 0.2);
}

/* Date Info */
.date-info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.date-main {
    font-weight: 500;
    color: var(--gray-700);
    line-height: 1;
}

.date-sub {
    font-size: 0.75rem;
    color: var(--gray-500);
    margin-top: 0.25rem;
}

/* Action Buttons */
.action-buttons-group {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-action {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    border: 1px solid var(--gray-300);
    background: white;
    color: var(--gray-600);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    font-size: 0.9rem;
}

.btn-action:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.btn-edit:hover {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.btn-toggle:hover {
    background: var(--warning-color);
    color: white;
    border-color: var(--warning-color);
}

.btn-delete:hover {
    background: var(--danger-color);
    color: white;
    border-color: var(--danger-color);
}

.btn-more:hover {
    background: var(--gray-700);
    color: white;
    border-color: var(--gray-700);
}

/* Table Footer */
.table-footer {
    background: var(--gray-50);
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--gray-200);
}

.table-info {
    color: var(--gray-600);
    font-size: 0.9rem;
}

.pagination {
    --bs-pagination-border-radius: 8px;
    --bs-pagination-color: var(--gray-600);
    --bs-pagination-bg: white;
    --bs-pagination-border-color: var(--gray-300);
    --bs-pagination-hover-color: var(--primary-color);
    --bs-pagination-hover-bg: var(--gray-50);
    --bs-pagination-active-color: white;
    --bs-pagination-active-bg: var(--primary-color);
    --bs-pagination-active-border-color: var(--primary-color);
}

/* Enhanced Modal Styles */
.modern-modal {
    border-radius: var(--border-radius-lg);
    border: none;
    box-shadow: var(--shadow-xl);
}

.modern-modal .modal-header {
    background: var(--gray-50);
    border-bottom: 1px solid var(--gray-200);
    padding: 1.5rem;
    border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
}

.modal-title-wrapper .modal-title {
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--gray-800);
    margin-bottom: 0.25rem;
}

.modal-subtitle {
    color: var(--gray-600);
    font-size: 0.9rem;
    margin-bottom: 0;
}

.modern-modal .modal-body {
    padding: 2rem 1.5rem;
}

.modern-modal .modal-footer {
    background: var(--gray-50);
    border-top: 1px solid var(--gray-200);
    padding: 1rem 1.5rem;
    border-radius: 0 0 var(--border-radius-lg) var(--border-radius-lg);
}

/* Form Styles */
.form-group-modern {
    margin-bottom: 1.5rem;
}

.form-group-modern .form-label {
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
}

.form-group-modern .form-control {
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-300);
    padding: 0.75rem 1rem;
    transition: all 0.2s ease;
    font-size: 0.95rem;
}

.form-group-modern .form-control:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    outline: none;
}

.permission-toggle {
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: var(--border-radius);
    padding: 1rem;
    margin-top: 0.5rem;
}

.permission-toggle .form-check-input {
    margin-right: 0.75rem;
}

.permission-toggle .form-check-label {
    font-weight: 500;
    color: var(--gray-700);
    cursor: pointer;
    display: flex;
    align-items: center;
}

/* Dropdown Menu Enhancements */
.dropdown-menu {
    border-radius: var(--border-radius);
    border: 1px solid var(--gray-200);
    box-shadow: var(--shadow-lg);
    padding: 0.5rem 0;
}

.dropdown-item {
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
}

.dropdown-item:hover {
    background: var(--gray-50);
    color: var(--gray-800);
}

.dropdown-item.text-danger:hover {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger-color);
}

/* Responsive Design */
@media (max-width: 1200px) {
    .stats-row {
        gap: 1rem;
    }
    
    .stat-number {
        font-size: 1.5rem;
    }
}

@media (max-width: 992px) {
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    
    .sidebar {
        display: none;
    }
    
    .page-title {
        font-size: 2rem;
    }
    
    .table-controls {
        flex-direction: column;
        gap: 0.75rem;
        align-items: stretch;
    }
    
    .search-box {
        max-width: none;
    }
}

@media (max-width: 768px) {
    .header-section {
        padding: 1.5rem;
        margin-bottom: 1.5rem;
    }
    
    .stats-row {
        flex-direction: column;
        gap: 1rem;
    }
    
    .table-container {
        margin: 0 -15px;
        border-radius: 0;
    }
    
    .table-header {
        padding: 1rem;
    }
    
    .table-controls {
        margin-top: 1rem;
    }
    
    .modern-table tbody td {
        padding: 1rem 0.75rem;
    }
    
    .user-info {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .avatar-circle {
        width: 40px;
        height: 40px;
        font-size: 1rem;
    }
    
    .action-buttons-group {
        flex-wrap: wrap;
        gap: 0.25rem;
    }
    
    .btn-action {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
    }
}

@media (max-width: 576px) {
    .page-title {
        font-size: 1.75rem;
    }
    
    .table-responsive {
        font-size: 0.85rem;
    }
    
    .modern-table tbody td {
        padding: 0.75rem 0.5rem;
    }
    
    .confidence-score {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .confidence-bar {
        width: 100%;
    }
    
    .modal-dialog {
        margin: 0.5rem;
    }
    
    .modern-modal .modal-body {
        padding: 1.5rem 1rem;
    }
}

/* Loading and Animation States */
.table-loading {
    position: relative;
    overflow: hidden;
}

.table-loading::after {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: shimmer 1.5s infinite;
}

@keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

/* Print Styles */
@media print {
    .action-buttons-group,
    .table-header,
    .table-footer,
    .header-section .action-buttons {
        display: none !important;
    }
    
    .table-container {
        box-shadow: none;
        border: 1px solid var(--gray-300);
    }
    
    .modern-table tbody tr:hover {
        background: transparent !important;
        transform: none !important;
        box-shadow: none !important;
    }
}

/* Dark Mode Support (Optional) */
@media (prefers-color-scheme: dark) {
    :root {
        --gray-50: #1f2937;
        --gray-100: #374151;
        --gray-200: #4b5563;
        --gray-300: #6b7280;
        --gray-800: #f9fafb;
        --gray-900: #ffffff;
    }
}

/* Custom Scrollbar */
.table-responsive::-webkit-scrollbar {
    height: 8px;
}

.table-responsive::-webkit-scrollbar-track {
    background: var(--gray-100);
    border-radius: 4px;
}

.table-responsive::-webkit-scrollbar-thumb {
    background: var(--gray-400);
    border-radius: 4px;
}

.table-responsive::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}

.table-container {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.table-responsive {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.table {
    width: 100%;
    margin-bottom: 0;
    border-collapse: separate;
    border-spacing: 0;
}

.table th {
    background: #f8f9fa;
    font-weight: 600;
    padding: 1rem;
    white-space: nowrap;
}

.table td {
    padding: 1rem;
    vertical-align: middle;
    white-space: nowrap;
}

@media (max-width: 768px) {
    .table th,
    .table td {
        padding: 0.75rem;
    }
    
    .table-responsive {
        overflow-x: auto;
    }
}
</style>

<script>
// Enhanced JavaScript functionality
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('userSearch');
    const statusFilter = document.getElementById('statusFilter');
    const table = document.getElementById('usersTable');
    
    function filterTable() {
        const searchTerm = searchInput.value.toLowerCase();
        const statusFilter = document.getElementById('statusFilter').value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const name = row.querySelector('.user-name').textContent.toLowerCase();
            const email = row.querySelector('.email').textContent.toLowerCase();
            const status = row.querySelector('.status-badge').textContent.toLowerCase();
            
            const matchesSearch = name.includes(searchTerm) || email.includes(searchTerm);
            const matchesStatus = !statusFilter || status.includes(statusFilter);
            
            row.style.display = matchesSearch && matchesStatus ? '' : 'none';
        });
    }
    
    if (searchInput) searchInput.addEventListener('input', filterTable);
    if (statusFilter) statusFilter.addEventListener('change', filterTable);
    
    // Sortable table headers
    const sortableHeaders = document.querySelectorAll('.sortable');
    sortableHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const sortType = this.dataset.sort;
            sortTable(sortType, this);
        });
    });
    
    function sortTable(sortType, headerElement) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const isAscending = !headerElement.classList.contains('sort-asc');
        
        // Remove sort classes from all headers
        sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        
        // Add appropriate sort class
        headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        
        rows.sort((a, b) => {
            let aVal, bVal;
            
            switch(sortType) {
                case 'name':
                    aVal = a.querySelector('.user-name').textContent;
                    bVal = b.querySelector('.user-name').textContent;
                    break;
                case 'email':
                    aVal = a.querySelector('.email').textContent;
                    bVal = b.querySelector('.email').textContent;
                    break;
                case 'properties':
                    aVal = parseInt(a.querySelector('.property-count').textContent.replace(/,/g, ''));
                    bVal = parseInt(b.querySelector('.property-count').textContent.replace(/,/g, ''));
                    break;
                case 'status':
                    aVal = a.querySelector('.status-badge').textContent;
                    bVal = b.querySelector('.status-badge').textContent;
                    break;
                default:
                    return 0;
            }
            
            if (typeof aVal === 'string') {
                return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
            } else {
                return isAscending ? aVal - bVal : bVal - aVal;
            }
        });
        
        // Reappend sorted rows
        rows.forEach(row => tbody.appendChild(row));
    }
    
    // Refresh table function
    window.refreshTable = function() {
        location.reload();
    };
    
    // Enhanced form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields.');
            }
        });
    });
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });
});
</script>

<?php include '../includes/footer.php'; ?> 