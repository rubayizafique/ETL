<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: ../login.php');
    exit;
}

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_general':
                // Update general settings
                $site_name = $_POST['site_name'];
                $site_description = $_POST['site_description'];
                $contact_email = $_POST['contact_email'];
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'site_name'");
                $stmt->bind_param("s", $site_name);
                $stmt->execute();
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'site_description'");
                $stmt->bind_param("s", $site_description);
                $stmt->execute();
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'contact_email'");
                $stmt->bind_param("s", $contact_email);
                $stmt->execute();
                
                $success_message = "General settings updated successfully!";
                break;
                
            case 'update_prediction':
                // Update prediction settings
                $confidence_threshold = $_POST['confidence_threshold'];
                $price_adjustment = $_POST['price_adjustment'];
                $market_trend_weight = $_POST['market_trend_weight'];
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'confidence_threshold'");
                $stmt->bind_param("i", $confidence_threshold);
                $stmt->execute();
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'price_adjustment'");
                $stmt->bind_param("f", $price_adjustment);
                $stmt->execute();
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'market_trend_weight'");
                $stmt->bind_param("f", $market_trend_weight);
                $stmt->execute();
                
                $success_message = "Prediction settings updated successfully!";
                break;
                
            case 'update_notification':
                // Update notification settings
                $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
                $notification_frequency = $_POST['notification_frequency'];
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'email_notifications'");
                $stmt->bind_param("i", $email_notifications);
                $stmt->execute();
                
                $stmt = $conn->prepare("UPDATE settings SET value = ? WHERE setting_key = 'notification_frequency'");
                $stmt->bind_param("s", $notification_frequency);
                $stmt->execute();
                
                $success_message = "Notification settings updated successfully!";
                break;

            case 'change_password':
                // Handle password change
                $current_password = $_POST['current_password'];
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];
                
                // Verify current password
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                
                if (password_verify($current_password, $user['password'])) {
                    if ($new_password === $confirm_password) {
                        // Update password
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                        $stmt->bind_param("si", $hashed_password, $_SESSION['user_id']);
                        
                        if ($stmt->execute()) {
                            $success_message = "Password updated successfully!";
                        } else {
                            $error_message = "Error updating password. Please try again.";
                        }
                    } else {
                        $error_message = "New passwords do not match.";
                    }
                } else {
                    $error_message = "Current password is incorrect.";
                }
                break;
        }
    }
}

// Create settings table if it doesn't exist
$conn->query("
    CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(50) NOT NULL UNIQUE,
        value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
");

// Insert default settings if they don't exist
$default_settings = [
    'site_name' => 'Land Price Estimation',
    'site_description' => 'Advanced land price estimation system',
    'contact_email' => 'admin@example.com',
    'confidence_threshold' => '70',
    'price_adjustment' => '1.0',
    'market_trend_weight' => '0.3',
    'email_notifications' => '1',
    'notification_frequency' => 'daily'
];

foreach ($default_settings as $key => $value) {
    $conn->query("INSERT IGNORE INTO settings (setting_key, value) VALUES ('$key', '$value')");
}

// Get current settings
$settings = [];
$result = $conn->query("SELECT * FROM settings");
if (!$result) {
    die("Error fetching settings: " . $conn->error);
}
while ($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['value'];
}

include '../includes/header_logged_in.php';
include '../includes/admin_sidebar.php';
?>

<div class="d-flex">
    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Settings Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">System Settings</h1>
                    <p class="text-muted mb-0">Manage system configurations and preferences</p>
                </div>
                <a href="../logout.php" class="btn btn-outline-danger d-lg-none">
                    <i class="bi bi-box-arrow-right"></i>
                </a>
            </div>

            <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- General Settings -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-gear me-2"></i>General Settings
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="update_general">
                                
                                <div class="mb-3">
                                    <label class="form-label">Site Name</label>
                                    <input type="text" 
                                           class="form-control" 
                                           name="site_name" 
                                           value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>" 
                                           required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Site Description</label>
                                    <textarea class="form-control" 
                                              name="site_description" 
                                              rows="3"><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Contact Email</label>
                                    <input type="email" 
                                           class="form-control" 
                                           name="contact_email" 
                                           value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>" 
                                           required>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Save Changes
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Password Change -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-key me-2"></i>Change Password
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="change_password">
                                
                                <div class="mb-3">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" 
                                           class="form-control" 
                                           name="current_password" 
                                           required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" 
                                           class="form-control" 
                                           name="new_password" 
                                           required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" 
                                           class="form-control" 
                                           name="confirm_password" 
                                           required>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-key me-2"></i>Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Prediction Settings -->
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-graph-up me-2"></i>Prediction Settings
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="update_prediction">
                                
                                <div class="mb-3">
                                    <label class="form-label">Confidence Threshold (%)</label>
                                    <input type="number" 
                                           class="form-control" 
                                           name="confidence_threshold" 
                                           value="<?php echo htmlspecialchars($settings['confidence_threshold'] ?? '70'); ?>" 
                                           min="0" 
                                           max="100" 
                                           required>
                                    <small class="text-muted">Minimum confidence score required for predictions</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Price Adjustment Factor</label>
                                    <input type="number" 
                                           class="form-control" 
                                           name="price_adjustment" 
                                           value="<?php echo htmlspecialchars($settings['price_adjustment'] ?? '1.0'); ?>" 
                                           step="0.1" 
                                           required>
                                    <small class="text-muted">Multiplier for price adjustments based on market conditions</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Market Trend Weight</label>
                                    <input type="number" 
                                           class="form-control" 
                                           name="market_trend_weight" 
                                           value="<?php echo htmlspecialchars($settings['market_trend_weight'] ?? '0.3'); ?>" 
                                           step="0.1" 
                                           min="0" 
                                           max="1" 
                                           required>
                                    <small class="text-muted">Weight given to market trends in price calculations</small>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Save Changes
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Card Styles */
.card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}

/* Form Styles */
.form-label {
    font-weight: 500;
}

.form-control:focus, .form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    
    .sidebar {
        display: none;
    }
}

@media (max-width: 768px) {
    .card {
        margin-bottom: 1rem;
    }
}

/* Mobile Optimizations */
@media (max-width: 576px) {
    .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
}
</style>

<script>
function backupDatabase() {
    // Implement database backup functionality
    alert('Database backup initiated. This may take a few minutes.');
}

function clearCache() {
    // Implement cache clearing functionality
    alert('Cache cleared successfully.');
}
</script>

<?php include '../includes/footer.php'; ?> 