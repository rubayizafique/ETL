<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Get export type from request
$export_type = $_GET['type'] ?? 'csv';
$include_charts = isset($_GET['charts']) && $_GET['charts'] === 'true';

// Function to get all properties with complete data
function getAllPropertiesData($conn) {
$stmt = $conn->prepare("
    SELECT 
        p.*,
        pr.predicted_price,
        pr.confidence_score,
        pr.prediction_date,
            u.username as submitted_by,
            u.email as user_email,
            u.created_at as user_created_at,
            up.notifications,
            up.email_alerts,
            CASE 
                WHEN p.has_water = 1 AND p.has_electricity = 1 AND p.has_road_access = 1 THEN 'Fully Developed'
                WHEN p.has_water = 1 OR p.has_electricity = 1 OR p.has_road_access = 1 THEN 'Partially Developed'
                ELSE 'Undeveloped'
            END as development_status,
            CASE 
                WHEN p.estimated_price < 1000000 THEN 'Under 1M'
                WHEN p.estimated_price < 5000000 THEN '1M - 5M'
                WHEN p.estimated_price < 10000000 THEN '5M - 10M'
                WHEN p.estimated_price < 20000000 THEN '10M - 20M'
                ELSE 'Over 20M'
            END as price_category
    FROM properties p
    LEFT JOIN predictions pr ON p.id = pr.property_id
    LEFT JOIN users u ON p.user_id = u.id
        LEFT JOIN user_preferences up ON u.id = up.user_id
    ORDER BY p.submission_date DESC
");
$stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get user statistics
function getUserStatistics($conn) {
    $stmt = $conn->prepare("
        SELECT 
            u.id,
            u.username,
            u.email,
            u.role,
            u.created_at,
            COUNT(p.id) as total_properties,
            SUM(p.estimated_price) as total_portfolio_value,
            AVG(p.estimated_price) as avg_property_value,
            AVG(pr.confidence_score) as avg_confidence,
            MAX(p.estimated_price) as highest_property_value,
            MIN(p.estimated_price) as lowest_property_value,
            MAX(p.submission_date) as last_activity,
            up.notifications,
            up.email_alerts
        FROM users u
        LEFT JOIN properties p ON u.id = p.user_id
        LEFT JOIN predictions pr ON p.id = pr.property_id
        LEFT JOIN user_preferences up ON u.id = up.user_id
        GROUP BY u.id, u.username, u.email, u.role, u.created_at, up.notifications, up.email_alerts
        ORDER BY total_portfolio_value DESC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get location analytics
function getLocationAnalytics($conn) {
    $stmt = $conn->prepare("
        SELECT 
            location,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            MIN(estimated_price) as min_price,
            MAX(estimated_price) as max_price,
            SUM(estimated_price) as total_value,
            AVG(pr.confidence_score) as avg_confidence,
            COUNT(CASE WHEN has_water = 1 THEN 1 END) as properties_with_water,
            COUNT(CASE WHEN has_electricity = 1 THEN 1 END) as properties_with_electricity,
            COUNT(CASE WHEN has_road_access = 1 THEN 1 END) as properties_with_road_access,
            COUNT(CASE WHEN nearby_schools = 1 THEN 1 END) as properties_near_schools,
            COUNT(CASE WHEN nearby_hospital = 1 THEN 1 END) as properties_near_hospital,
            COUNT(CASE WHEN nearby_market = 1 THEN 1 END) as properties_near_market,
            COUNT(CASE WHEN nearby_university = 1 THEN 1 END) as properties_near_university
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        GROUP BY location
        ORDER BY total_value DESC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get system statistics
function getSystemStatistics($conn) {
    $stats = [];
    
    // Total counts
    $stmt = $conn->prepare("SELECT COUNT(*) as total_users FROM users");
    $stmt->execute();
    $stats['total_users'] = $stmt->get_result()->fetch_assoc()['total_users'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as total_properties FROM properties");
    $stmt->execute();
    $stats['total_properties'] = $stmt->get_result()->fetch_assoc()['total_properties'];
    
    $stmt = $conn->prepare("SELECT SUM(estimated_price) as total_value FROM properties");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stats['total_value'] = $result['total_value'] ?? 0;
    
    $stmt = $conn->prepare("SELECT AVG(confidence_score) as avg_confidence FROM predictions");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stats['avg_confidence'] = $result['avg_confidence'] ?? 0;
    
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT user_id) as active_users FROM properties WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute();
    $stats['active_users'] = $stmt->get_result()->fetch_assoc()['active_users'];
    
    return $stats;
}

// Function to clean data - remove empty, null, 0, and N/A values
function cleanData($value) {
    if ($value === null || $value === '' || $value === '0' || $value === 'N/A' || $value === 0) {
        return '';
    }
    return $value;
}

// Generate consolidated CSV export
if ($export_type === 'csv') {
    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="system_data_' . date('Y-m-d') . '.csv"');

    // Create output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM for proper Excel encoding
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // Get all data
    $properties = getAllPropertiesData($conn);
    $users = getUserStatistics($conn);
    $locations = getLocationAnalytics($conn);
    $systemStats = getSystemStatistics($conn);

    // Write System Summary Section
    fputcsv($output, ['SYSTEM SUMMARY']);
    fputcsv($output, ['']);
    fputcsv($output, ['Metric', 'Value']);
    fputcsv($output, ['Total Users', cleanData($systemStats['total_users'])]);
    fputcsv($output, ['Active Users (30 days)', cleanData($systemStats['active_users'])]);
    fputcsv($output, ['Total Properties', cleanData($systemStats['total_properties'])]);
    fputcsv($output, ['Total System Value', cleanData($systemStats['total_value'])]);
    fputcsv($output, ['Average Confidence Score', cleanData($systemStats['avg_confidence'])]);
    fputcsv($output, ['']);

    // Write User Statistics Section
    fputcsv($output, ['USER STATISTICS']);
    fputcsv($output, ['']);
    fputcsv($output, ['User ID', 'Username', 'Email', 'Role', 'Account Created', 'Total Properties', 'Total Portfolio Value', 'Average Property Value', 'Average Confidence', 'Highest Property Value', 'Lowest Property Value', 'Last Activity', 'Notifications Enabled', 'Email Alerts Enabled']);
    foreach ($users as $user) {
        fputcsv($output, [
            cleanData($user['id']),
            cleanData($user['username']),
            cleanData($user['email']),
            cleanData($user['role']),
            cleanData($user['created_at']),
            cleanData($user['total_properties']),
            cleanData($user['total_portfolio_value']),
            cleanData($user['avg_property_value']),
            cleanData($user['avg_confidence']),
            cleanData($user['highest_property_value']),
            cleanData($user['lowest_property_value']),
            cleanData($user['last_activity']),
            cleanData($user['notifications'] ? 'Yes' : ''),
            cleanData($user['email_alerts'] ? 'Yes' : '')
        ]);
    }
    fputcsv($output, ['']);

    // Write Location Analytics Section
    fputcsv($output, ['LOCATION ANALYTICS']);
    fputcsv($output, ['']);
    fputcsv($output, ['Location', 'Property Count', 'Average Price', 'Minimum Price', 'Maximum Price', 'Total Value', 'Average Confidence', 'Properties with Water', 'Properties with Electricity', 'Properties with Road Access', 'Properties Near Schools', 'Properties Near Hospital', 'Properties Near Market', 'Properties Near University']);
    foreach ($locations as $location) {
        fputcsv($output, [
            cleanData($location['location']),
            cleanData($location['property_count']),
            cleanData($location['avg_price']),
            cleanData($location['min_price']),
            cleanData($location['max_price']),
            cleanData($location['total_value']),
            cleanData($location['avg_confidence']),
            cleanData($location['properties_with_water']),
            cleanData($location['properties_with_electricity']),
            cleanData($location['properties_with_road_access']),
            cleanData($location['properties_near_schools']),
            cleanData($location['properties_near_hospital']),
            cleanData($location['properties_near_market']),
            cleanData($location['properties_near_university'])
        ]);
    }
    fputcsv($output, ['']);

    // Write Detailed Properties Section
    fputcsv($output, ['DETAILED PROPERTIES']);
    fputcsv($output, ['']);
    fputcsv($output, [
        'ID', 'Location', 'Size (sqm)', 'Has Water', 'Has Electricity', 'Has Road Access',
        'Additional Amenities', 'Estimated Price', 'Submission Date', 'Land Type', 'Zoning',
        'Land Use', 'Nearby Schools', 'Nearby Hospital', 'Nearby Market', 'Nearby University',
        'Zoning Land Type', 'Nearby Amenities', 'Distance to City Center', 'Predicted Price',
        'Confidence Score', 'Prediction Date', 'Submitted By', 'User Email', 'User Created At',
        'Development Status', 'Price Category', 'User Notifications', 'User Email Alerts'
    ]);

    foreach ($properties as $property) {
        fputcsv($output, [
            cleanData($property['id']),
            cleanData($property['location']),
            cleanData($property['size_sqm']),
            cleanData($property['has_water'] ? 'Yes' : ''),
            cleanData($property['has_electricity'] ? 'Yes' : ''),
            cleanData($property['has_road_access'] ? 'Yes' : ''),
            cleanData($property['additional_amenities']),
            cleanData($property['estimated_price']),
            cleanData($property['submission_date']),
            cleanData($property['land_type']),
            cleanData($property['zoning']),
            cleanData($property['land_use']),
            cleanData($property['nearby_schools'] ? 'Yes' : ''),
            cleanData($property['nearby_hospital'] ? 'Yes' : ''),
            cleanData($property['nearby_market'] ? 'Yes' : ''),
            cleanData($property['nearby_university'] ? 'Yes' : ''),
            cleanData($property['zoning_landtype']),
            cleanData($property['nearby_amenities']),
            cleanData($property['distance_to_city_center']),
            cleanData($property['predicted_price']),
            cleanData($property['confidence_score']),
            cleanData($property['prediction_date']),
            cleanData($property['submitted_by']),
            cleanData($property['user_email']),
            cleanData($property['user_created_at']),
            cleanData($property['development_status']),
            cleanData($property['price_category']),
            cleanData($property['notifications'] ? 'Yes' : ''),
            cleanData($property['email_alerts'] ? 'Yes' : '')
    ]);
}

// Close the output stream
fclose($output);
exit; 
}

// Generate comprehensive export (ZIP with multiple files)
elseif ($export_type === 'comprehensive') {
    // Set headers for ZIP download
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="land_price_estimation_comprehensive_export_' . date('Y-m-d_H-i-s') . '.zip"');
    
    // Create ZIP file
    $zip = new ZipArchive();
    $zipName = 'temp_export_' . time() . '.zip';
    $zip->open($zipName, ZipArchive::CREATE);
    
    // 1. Main Properties Data
    $properties = getAllPropertiesData($conn);
    $csvContent = "ID,Property Type,Location,Size (sqm),Has Water,Has Electricity,Has Road Access,Additional Amenities,Estimated Price,Submission Date,Land Type,Zoning,Land Use,Nearby Schools,Nearby Hospital,Nearby Market,Nearby University,Zoning Land Type,Nearby Amenities,Distance to City Center,Predicted Price,Confidence Score,Prediction Date,Submitted By,User Email,User Created At,Development Status,Price Category,User Notifications,User Email Alerts\n";
    
    foreach ($properties as $property) {
        $csvContent .= implode(',', [
            $property['id'],
            '"' . str_replace('"', '""', $property['land_type'] ?? 'N/A') . '"',
            '"' . str_replace('"', '""', $property['location']) . '"',
            $property['size_sqm'],
            $property['has_water'] ? 'Yes' : 'No',
            $property['has_electricity'] ? 'Yes' : 'No',
            $property['has_road_access'] ? 'Yes' : 'No',
            '"' . str_replace('"', '""', $property['additional_amenities'] ?? '') . '"',
            $property['estimated_price'],
            $property['submission_date'],
            '"' . str_replace('"', '""', $property['land_type'] ?? 'N/A') . '"',
            '"' . str_replace('"', '""', $property['zoning'] ?? 'N/A') . '"',
            '"' . str_replace('"', '""', $property['land_use'] ?? 'N/A') . '"',
            $property['nearby_schools'] ? 'Yes' : 'No',
            $property['nearby_hospital'] ? 'Yes' : 'No',
            $property['nearby_market'] ? 'Yes' : 'No',
            $property['nearby_university'] ? 'Yes' : 'No',
            '"' . str_replace('"', '""', $property['zoning_landtype'] ?? 'N/A') . '"',
            '"' . str_replace('"', '""', $property['nearby_amenities'] ?? '') . '"',
            $property['distance_to_city_center'] ?? 'N/A',
            $property['predicted_price'] ?? 'N/A',
            $property['confidence_score'] ?? 'N/A',
            $property['prediction_date'] ?? 'N/A',
            '"' . str_replace('"', '""', $property['submitted_by'] ?? 'N/A') . '"',
            '"' . str_replace('"', '""', $property['user_email'] ?? 'N/A') . '"',
            $property['user_created_at'] ?? 'N/A',
            '"' . str_replace('"', '""', $property['development_status']) . '"',
            '"' . str_replace('"', '""', $property['price_category']) . '"',
            $property['notifications'] ? 'Yes' : 'No',
            $property['email_alerts'] ? 'Yes' : 'No'
        ]) . "\n";
    }
    
    $zip->addFromString('01_Properties_Data.csv', $csvContent);
    
    // 2. User Statistics
    $users = getUserStatistics($conn);
    $csvContent = "User ID,Username,Email,Role,Account Created,Total Properties,Total Portfolio Value,Average Property Value,Average Confidence,Highest Property Value,Lowest Property Value,Last Activity,Notifications Enabled,Email Alerts Enabled\n";
    
    foreach ($users as $user) {
        $csvContent .= implode(',', [
            $user['id'],
            '"' . str_replace('"', '""', $user['username']) . '"',
            '"' . str_replace('"', '""', $user['email']) . '"',
            $user['role'],
            $user['created_at'],
            $user['total_properties'],
            $user['total_portfolio_value'] ?? 0,
            $user['avg_property_value'] ?? 0,
            $user['avg_confidence'] ?? 0,
            $user['highest_property_value'] ?? 0,
            $user['lowest_property_value'] ?? 0,
            $user['last_activity'] ?? 'N/A',
            $user['notifications'] ? 'Yes' : 'No',
            $user['email_alerts'] ? 'Yes' : 'No'
        ]) . "\n";
    }
    
    $zip->addFromString('02_User_Statistics.csv', $csvContent);
    
    // 3. Location Analytics
    $locations = getLocationAnalytics($conn);
    $csvContent = "Location,Property Count,Average Price,Minimum Price,Maximum Price,Total Value,Average Confidence,Properties with Water,Properties with Electricity,Properties with Road Access,Properties Near Schools,Properties Near Hospital,Properties Near Market,Properties Near University\n";
    
    foreach ($locations as $location) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $location['location']) . '"',
            $location['property_count'],
            $location['avg_price'],
            $location['min_price'],
            $location['max_price'],
            $location['total_value'],
            $location['avg_confidence'] ?? 0,
            $location['properties_with_water'],
            $location['properties_with_electricity'],
            $location['properties_with_road_access'],
            $location['properties_near_schools'],
            $location['properties_near_hospital'],
            $location['properties_near_market'],
            $location['properties_near_university']
        ]) . "\n";
    }
    
    $zip->addFromString('03_Location_Analytics.csv', $csvContent);
    
    // Export Summary Report
    $summary = "# Land Price Estimation System - Comprehensive Export Report\n\n";
    $summary .= "Export Date: " . date('Y-m-d H:i:s') . "\n";
    $summary .= "Generated By: " . $_SESSION['username'] . "\n\n";
    
    $summary .= "## Data Summary\n";
    $summary .= "- Total Properties: " . count($properties) . "\n";
    $summary .= "- Total Users: " . count($users) . "\n";
    $summary .= "- Total Locations: " . count($locations) . "\n";
    $summary .= "- Export Period: All time\n\n";
    
    $summary .= "## Files Included\n";
    $summary .= "1. 01_Properties_Data.csv - Complete property information with predictions\n";
    $summary .= "2. 02_User_Statistics.csv - User activity and portfolio statistics\n";
    $summary .= "3. 03_Location_Analytics.csv - Location-based performance metrics\n\n";
    
    $summary .= "## Key Insights\n";
    if (count($properties) > 0) {
        $totalValue = array_sum(array_column($properties, 'estimated_price'));
        $avgPrice = $totalValue / count($properties);
        $summary .= "- Total Portfolio Value: RWF " . number_format($totalValue, 0) . "\n";
        $summary .= "- Average Property Price: RWF " . number_format($avgPrice, 0) . "\n";
    }
    
    $zip->addFromString('00_Export_Summary.txt', $summary);
    
    $zip->close();
    
    // Output the ZIP file
    readfile($zipName);
    unlink($zipName); // Clean up
    exit;
}

// Default redirect
else {
    header('Location: dashboard.php');
    exit;
}
?> 