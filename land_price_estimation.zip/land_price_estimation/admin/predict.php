<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

include '../includes/header_logged_in.php';
include '../includes/admin_sidebar.php';
?>

<div class="d-flex">
    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Prediction Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Admin Land Price Prediction</h1>
                    <p class="text-muted mb-0">Enter land details to get a price estimate</p>
                </div>
                <a href="../logout.php" class="btn btn-outline-danger d-lg-none">
                    <i class="bi bi-box-arrow-right"></i>
                </a>
            </div>

            <div class="row">
                <div class="col-lg-8">
                    <!-- Prediction Form -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <form action="admin_predict_submit.php" method="POST" id="predictionForm">
                                <div class="row g-3">
                                    <!-- Location -->
                                    <div class="mb-3">
                                        <label for="location" class="form-label">Location</label>
                                        <input type="text" class="form-control" id="location" name="location" required 
                                               placeholder="Enter the location of the land">
                                    </div>

                                    <!-- Size -->
                                    <div class="col-md-6">
                                        <label for="size_sqm" class="form-label">Size (Square Meters)</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" id="size_sqm" name="size_sqm" 
                                                   min="1" step="0.01" required>
                                            <span class="input-group-text">sqm</span>
                                        </div>
                                    </div>

                                    <!-- Amenities -->
                                    <div class="col-12">
                                        <label class="form-label">Amenities</label>
                                        <div class="row g-3">
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="has_water" 
                                                           name="has_water" value="1">
                                                    <label class="form-check-label" for="has_water">
                                                        <i class="bi bi-droplet me-1"></i>Water Supply
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="has_electricity" 
                                                           name="has_electricity" value="1">
                                                    <label class="form-check-label" for="has_electricity">
                                                        <i class="bi bi-lightning me-1"></i>Electricity
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="has_road_access" 
                                                           name="has_road_access" value="1">
                                                    <label class="form-check-label" for="has_road_access">
                                                        <i class="bi bi-signpost me-1"></i>Road Access
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Additional Notes -->
                                    <div class="col-12">
                                        <label for="notes" class="form-label">Additional Notes</label>
                                        <textarea class="form-control" id="notes" name="notes" rows="3" 
                                                  placeholder="Enter any additional details about the land..."></textarea>
                                    </div>

                                    <!-- Submit Button -->
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-calculator me-2"></i>Get Price Estimate
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Information Card -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <i class="bi bi-info-circle me-2"></i>About Predictions
                            </h5>
                            <p class="text-muted">
                                Our system uses advanced algorithms to estimate land prices based on various factors including:
                            </p>
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Location and accessibility
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Land size and shape
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Available amenities
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Market trends and conditions
                                </li>
                            </ul>
                            <div class="alert alert-info mt-3">
                                <i class="bi bi-lightbulb me-2"></i>
                                <strong>Tip:</strong> The more accurate information you provide, the better the price estimate will be.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Card Styles */
.card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}

/* Form Styles */
.form-control:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.form-check-input:checked {
    background-color: #0d6efd;
    border-color: #0d6efd;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    
    .sidebar {
        display: none;
    }
}

@media (max-width: 768px) {
    .card {
        margin-bottom: 1rem;
    }
}
</style>

<?php include '../includes/footer.php'; ?> 