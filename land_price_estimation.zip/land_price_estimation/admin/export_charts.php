<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Get chart type from request
$chart_type = $_GET['chart'] ?? 'all';

// Function to get activity trends data
function getActivityTrendsData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            DATE_FORMAT(submission_date, '%Y-%m') as month,
            COUNT(*) as total_submissions,
            COUNT(DISTINCT user_id) as active_users,
            AVG(estimated_price) as avg_price,
            SUM(estimated_price) as total_value,
            AVG(pr.confidence_score) as avg_confidence,
            COUNT(CASE WHEN pr.confidence_score >= 80 THEN 1 END) as high_confidence_predictions
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
        GROUP BY DATE_FORMAT(submission_date, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get development status data
function getDevelopmentStatusData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            CASE 
                WHEN has_water = 1 AND has_electricity = 1 AND has_road_access = 1 THEN 'Fully Developed'
                WHEN has_water = 1 OR has_electricity = 1 OR has_road_access = 1 THEN 'Partially Developed'
                ELSE 'Undeveloped'
            END as development_status,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            MIN(estimated_price) as min_price,
            MAX(estimated_price) as max_price,
            SUM(estimated_price) as total_value,
            AVG(pr.confidence_score) as avg_confidence
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        GROUP BY development_status
        ORDER BY avg_price DESC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get location performance data
function getLocationPerformanceData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            location,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            MIN(estimated_price) as min_price,
            MAX(estimated_price) as max_price,
            SUM(estimated_price) as total_value,
            AVG(pr.confidence_score) as avg_confidence,
            COUNT(CASE WHEN has_water = 1 THEN 1 END) as properties_with_water,
            COUNT(CASE WHEN has_electricity = 1 THEN 1 END) as properties_with_electricity,
            COUNT(CASE WHEN has_road_access = 1 THEN 1 END) as properties_with_road_access
        FROM properties p
        LEFT JOIN predictions pr ON p.id = pr.property_id
        GROUP BY location
        HAVING property_count >= 2
        ORDER BY total_value DESC
        LIMIT 15
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get price distribution data
function getPriceDistributionData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            CASE 
                WHEN estimated_price < 1000000 THEN 'Under 1M'
                WHEN estimated_price < 5000000 THEN '1M - 5M'
                WHEN estimated_price < 10000000 THEN '5M - 10M'
                WHEN estimated_price < 20000000 THEN '10M - 20M'
                ELSE 'Over 20M'
            END as price_range,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            MIN(estimated_price) as min_price,
            MAX(estimated_price) as max_price,
            SUM(estimated_price) as total_value
        FROM properties
        GROUP BY price_range
        ORDER BY min_price ASC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get user activity data
function getUserActivityData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            u.username,
            COUNT(p.id) as total_properties,
            SUM(p.estimated_price) as total_portfolio_value,
            AVG(p.estimated_price) as avg_property_value,
            AVG(pr.confidence_score) as avg_confidence,
            MAX(p.estimated_price) as highest_property_value,
            MIN(p.estimated_price) as lowest_property_value,
            MAX(p.submission_date) as last_activity
        FROM users u
        LEFT JOIN properties p ON u.id = p.user_id
        LEFT JOIN predictions pr ON p.id = pr.property_id
        WHERE u.role = 'user'
        GROUP BY u.id, u.username
        HAVING total_properties >= 1
        ORDER BY total_portfolio_value DESC
        LIMIT 20
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get confidence distribution data
function getConfidenceDistributionData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            CASE 
                WHEN confidence_score >= 90 THEN '90-100% (Excellent)'
                WHEN confidence_score >= 80 THEN '80-89% (Good)'
                WHEN confidence_score >= 70 THEN '70-79% (Fair)'
                WHEN confidence_score >= 60 THEN '60-69% (Poor)'
                ELSE 'Below 60% (Very Poor)'
            END as confidence_range,
            COUNT(*) as prediction_count,
            AVG(confidence_score) as avg_confidence,
            AVG(ABS(p.estimated_price - pr.predicted_price)) as avg_price_difference,
            AVG((ABS(p.estimated_price - pr.predicted_price) / p.estimated_price) * 100) as avg_accuracy_percentage
        FROM predictions pr
        JOIN properties p ON pr.property_id = p.id
        GROUP BY confidence_range
        ORDER BY avg_confidence DESC
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get monthly comparison data
function getMonthlyComparisonData($conn) {
    $stmt = $conn->prepare("
        SELECT 
            MONTH(submission_date) as month,
            YEAR(submission_date) as year,
            COUNT(*) as property_count,
            AVG(estimated_price) as avg_price,
            SUM(estimated_price) as total_value,
            COUNT(DISTINCT user_id) as active_users
        FROM properties
        WHERE submission_date >= DATE_SUB(NOW(), INTERVAL 24 MONTH)
        GROUP BY YEAR(submission_date), MONTH(submission_date)
        ORDER BY year, month
    ");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Generate comprehensive chart data export
if ($chart_type === 'all') {
    // Set headers for ZIP download
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="chart_data_export_' . date('Y-m-d_H-i-s') . '.zip"');
    
    // Create ZIP file
    $zip = new ZipArchive();
    $zipName = 'temp_chart_export_' . time() . '.zip';
    $zip->open($zipName, ZipArchive::CREATE);
    
    // 1. Activity Trends Chart Data
    $activityTrends = getActivityTrendsData($conn);
    $csvContent = "Month,Total Submissions,Active Users,Average Price,Total Value,Average Confidence,High Confidence Predictions\n";
    
    foreach ($activityTrends as $trend) {
        $csvContent .= implode(',', [
            $trend['month'],
            $trend['total_submissions'],
            $trend['active_users'],
            $trend['avg_price'],
            $trend['total_value'],
            $trend['avg_confidence'] ?? 0,
            $trend['high_confidence_predictions']
        ]) . "\n";
    }
    
    $zip->addFromString('01_Activity_Trends_Chart.csv', $csvContent);
    
    // 2. Development Status Chart Data
    $developmentStatus = getDevelopmentStatusData($conn);
    $csvContent = "Development Status,Property Count,Average Price,Minimum Price,Maximum Price,Total Value,Average Confidence\n";
    
    foreach ($developmentStatus as $dev) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $dev['development_status']) . '"',
            $dev['property_count'],
            $dev['avg_price'],
            $dev['min_price'],
            $dev['max_price'],
            $dev['total_value'],
            $dev['avg_confidence'] ?? 0
        ]) . "\n";
    }
    
    $zip->addFromString('02_Development_Status_Chart.csv', $csvContent);
    
    // 3. Location Performance Chart Data
    $locationPerformance = getLocationPerformanceData($conn);
    $csvContent = "Location,Property Count,Average Price,Minimum Price,Maximum Price,Total Value,Average Confidence,Properties with Water,Properties with Electricity,Properties with Road Access\n";
    
    foreach ($locationPerformance as $location) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $location['location']) . '"',
            $location['property_count'],
            $location['avg_price'],
            $location['min_price'],
            $location['max_price'],
            $location['total_value'],
            $location['avg_confidence'] ?? 0,
            $location['properties_with_water'],
            $location['properties_with_electricity'],
            $location['properties_with_road_access']
        ]) . "\n";
    }
    
    $zip->addFromString('03_Location_Performance_Chart.csv', $csvContent);
    
    // 4. Price Distribution Chart Data
    $priceDistribution = getPriceDistributionData($conn);
    $csvContent = "Price Range,Property Count,Average Price,Minimum Price,Maximum Price,Total Value\n";
    
    foreach ($priceDistribution as $price) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $price['price_range']) . '"',
            $price['property_count'],
            $price['avg_price'],
            $price['min_price'],
            $price['max_price'],
            $price['total_value']
        ]) . "\n";
    }
    
    $zip->addFromString('04_Price_Distribution_Chart.csv', $csvContent);
    
    // 5. User Activity Chart Data
    $userActivity = getUserActivityData($conn);
    $csvContent = "Username,Total Properties,Total Portfolio Value,Average Property Value,Average Confidence,Highest Property Value,Lowest Property Value,Last Activity\n";
    
    foreach ($userActivity as $user) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $user['username']) . '"',
            $user['total_properties'],
            $user['total_portfolio_value'] ?? 0,
            $user['avg_property_value'] ?? 0,
            $user['avg_confidence'] ?? 0,
            $user['highest_property_value'] ?? 0,
            $user['lowest_property_value'] ?? 0,
            $user['last_activity'] ?? 'N/A'
        ]) . "\n";
    }
    
    $zip->addFromString('05_User_Activity_Chart.csv', $csvContent);
    
    // 6. Confidence Distribution Chart Data
    $confidenceDistribution = getConfidenceDistributionData($conn);
    $csvContent = "Confidence Range,Prediction Count,Average Confidence,Average Price Difference,Average Accuracy Percentage\n";
    
    foreach ($confidenceDistribution as $conf) {
        $csvContent .= implode(',', [
            '"' . str_replace('"', '""', $conf['confidence_range']) . '"',
            $conf['prediction_count'],
            $conf['avg_confidence'],
            $conf['avg_price_difference'],
            $conf['avg_accuracy_percentage']
        ]) . "\n";
    }
    
    $zip->addFromString('06_Confidence_Distribution_Chart.csv', $csvContent);
    
    // 7. Monthly Comparison Chart Data
    $monthlyComparison = getMonthlyComparisonData($conn);
    $csvContent = "Month,Year,Property Count,Average Price,Total Value,Active Users\n";
    
    foreach ($monthlyComparison as $month) {
        $csvContent .= implode(',', [
            $month['month'],
            $month['year'],
            $month['property_count'],
            $month['avg_price'],
            $month['total_value'],
            $month['active_users']
        ]) . "\n";
    }
    
    $zip->addFromString('07_Monthly_Comparison_Chart.csv', $csvContent);
    
    // 8. Chart Instructions
    $instructions = "# Chart Data Export Instructions\n\n";
    $instructions .= "This ZIP file contains CSV data for all dashboard charts.\n\n";
    $instructions .= "## Files Included:\n";
    $instructions .= "1. 01_Activity_Trends_Chart.csv - For line/area charts showing user activity over time\n";
    $instructions .= "2. 02_Development_Status_Chart.csv - For pie/doughnut charts showing property development status\n";
    $instructions .= "3. 03_Location_Performance_Chart.csv - For bar charts showing location performance\n";
    $instructions .= "4. 04_Price_Distribution_Chart.csv - For histogram/bar charts showing price ranges\n";
    $instructions .= "5. 05_User_Activity_Chart.csv - For bar charts showing top users\n";
    $instructions .= "6. 06_Confidence_Distribution_Chart.csv - For pie charts showing prediction confidence\n";
    $instructions .= "7. 07_Monthly_Comparison_Chart.csv - For comparison charts across months/years\n\n";
    
    $instructions .= "## How to Use in Excel:\n";
    $instructions .= "1. Open any CSV file in Excel\n";
    $instructions .= "2. Select the data you want to chart\n";
    $instructions .= "3. Go to Insert > Charts and choose your preferred chart type\n";
    $instructions .= "4. Customize colors, labels, and formatting as needed\n\n";
    
    $instructions .= "## Chart Recommendations:\n";
    $instructions .= "- Activity Trends: Line or Area Chart\n";
    $instructions .= "- Development Status: Pie or Doughnut Chart\n";
    $instructions .= "- Location Performance: Bar or Column Chart\n";
    $instructions .= "- Price Distribution: Histogram or Bar Chart\n";
    $instructions .= "- User Activity: Bar Chart\n";
    $instructions .= "- Confidence Distribution: Pie Chart\n";
    $instructions .= "- Monthly Comparison: Line or Bar Chart\n\n";
    
    $instructions .= "Export Date: " . date('Y-m-d H:i:s') . "\n";
    $instructions .= "Generated By: " . $_SESSION['username'] . "\n";
    
    $zip->addFromString('00_Chart_Instructions.txt', $instructions);
    
    $zip->close();
    
    // Output the ZIP file
    readfile($zipName);
    unlink($zipName); // Clean up
    exit;
}

// Generate specific chart data export
else {
    $chartData = [];
    $filename = '';
    $headers = '';
    
    switch ($chart_type) {
        case 'activity_trends':
            $chartData = getActivityTrendsData($conn);
            $filename = 'activity_trends_chart_data.csv';
            $headers = "Month,Total Submissions,Active Users,Average Price,Total Value,Average Confidence,High Confidence Predictions\n";
            break;
            
        case 'development_status':
            $chartData = getDevelopmentStatusData($conn);
            $filename = 'development_status_chart_data.csv';
            $headers = "Development Status,Property Count,Average Price,Minimum Price,Maximum Price,Total Value,Average Confidence\n";
            break;
            
        case 'location_performance':
            $chartData = getLocationPerformanceData($conn);
            $filename = 'location_performance_chart_data.csv';
            $headers = "Location,Property Count,Average Price,Minimum Price,Maximum Price,Total Value,Average Confidence,Properties with Water,Properties with Electricity,Properties with Road Access\n";
            break;
            
        case 'price_distribution':
            $chartData = getPriceDistributionData($conn);
            $filename = 'price_distribution_chart_data.csv';
            $headers = "Price Range,Property Count,Average Price,Minimum Price,Maximum Price,Total Value\n";
            break;
            
        case 'user_activity':
            $chartData = getUserActivityData($conn);
            $filename = 'user_activity_chart_data.csv';
            $headers = "Username,Total Properties,Total Portfolio Value,Average Property Value,Average Confidence,Highest Property Value,Lowest Property Value,Last Activity\n";
            break;
            
        case 'confidence_distribution':
            $chartData = getConfidenceDistributionData($conn);
            $filename = 'confidence_distribution_chart_data.csv';
            $headers = "Confidence Range,Prediction Count,Average Confidence,Average Price Difference,Average Accuracy Percentage\n";
            break;
            
        case 'monthly_comparison':
            $chartData = getMonthlyComparisonData($conn);
            $filename = 'monthly_comparison_chart_data.csv';
            $headers = "Month,Year,Property Count,Average Price,Total Value,Active Users\n";
            break;
            
        default:
            header('Location: dashboard.php');
            exit;
    }
    
    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // Create output stream
    $output = fopen('php://output', 'w');
    
    // Add UTF-8 BOM for proper Excel encoding
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Write headers
    fwrite($output, $headers);
    
    // Write data rows
    foreach ($chartData as $row) {
        $csvRow = [];
        foreach ($row as $value) {
            if (is_string($value) && strpos($value, ',') !== false) {
                $csvRow[] = '"' . str_replace('"', '""', $value) . '"';
            } else {
                $csvRow[] = $value;
            }
        }
        fputcsv($output, $csvRow);
    }
    
    // Close the output stream
    fclose($output);
    exit;
}
?> 