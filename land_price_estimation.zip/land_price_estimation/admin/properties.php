<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: ../login.php');
    exit;
}

// Handle property deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $property_id = $_POST['property_id'];
    $stmt = $conn->prepare("DELETE FROM properties WHERE id = ?");
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    
    header('Location: properties.php');
    exit;
}

// Get all properties with user and prediction details
$stmt = $conn->prepare("
    SELECT p.*, u.username, pr.predicted_price, pr.confidence_score, pr.prediction_date
    FROM properties p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN (
        SELECT t1.*
        FROM predictions t1
        INNER JOIN (
            SELECT property_id, MAX(prediction_date) AS max_date
            FROM predictions
            GROUP BY property_id
        ) t2 ON t1.property_id = t2.property_id AND t1.prediction_date = t2.max_date
    ) pr ON p.id = pr.property_id
    ORDER BY p.submission_date DESC
");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->execute();
$properties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get property statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_properties,
        AVG(estimated_price) as avg_price,
        SUM(estimated_price) as total_value,
        COUNT(DISTINCT user_id) as total_users,
        COUNT(DISTINCT location) as total_locations
    FROM properties
");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get location distribution
$stmt = $conn->prepare("
    SELECT location, COUNT(*) as count
    FROM properties
    GROUP BY location
    ORDER BY count DESC
    LIMIT 5
");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->execute();
$locations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include '../includes/header_logged_in.php';
include '../includes/admin_sidebar.php';
?>

<div class="d-flex">
    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Properties Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Land Management</h1>
                    <p class="text-muted mb-0">View and manage all land predictions</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-primary" onclick="exportData()">
                        <i class="bi bi-download me-2"></i>Export Data
                    </button>
                    <a href="../logout.php" class="btn btn-outline-danger d-lg-none">
                        <i class="bi bi-box-arrow-right"></i>
                    </a>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-primary bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-map text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Total Lands</h6>
                                    <h4 class="mb-0"><?php echo number_format($stats['total_properties']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-success bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-currency-dollar text-success"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Total Value</h6>
                                    <h4 class="mb-0">RWF <?php echo number_format($stats['total_value'], 0); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-info bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-graph-up text-info"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Average Price</h6>
                                    <h4 class="mb-0">RWF <?php echo number_format($stats['avg_price'], 0); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="stat-icon bg-warning bg-opacity-10 rounded p-3 me-3">
                                    <i class="bi bi-geo-alt text-warning"></i>
                                </div>
                                <div>
                                    <h6 class="text-muted mb-1">Locations</h6>
                                    <h4 class="mb-0"><?php echo number_format($stats['total_locations']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <!-- Location Distribution -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-pie-chart me-2"></i>Location Distribution
                            </h5>
                        </div>
                        <div class="card-body chart-3d-container position-relative" style="height: 400px; min-height: 320px;">
                            <canvas id="locationChart"></canvas>
                            <div id="pieLabels" class="pie-labels"></div>
                        </div>
                    </div>
                </div>

                <!-- Properties Table -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">
                                        <i class="bi bi-table me-2"></i>Land Properties
                                    </h5>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="table-controls">
                                            <div class="search-box">
                                                <i class="bi bi-search text-warning fw-bold fs-5"></i>
                                                <input type="text" class="form-control search-input-enhanced" id="propertySearch" placeholder="🔍 Search properties by location, size, price, user...">
                                                <button type="button" class="btn btn-sm btn-outline-warning clear-search-btn" id="clearSearchBtn" style="display: none;">
                                                    <i class="bi bi-x fw-bold"></i>
                                                </button>
                                            </div>
                                            <div class="search-results-info" id="searchResultsInfo">
                                                <i class="bi bi-info-circle me-1 text-warning"></i>
                                                <span id="searchResultsText">Showing all properties</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover modern-table" id="propertiesTable">
                                    <thead>
                                        <tr>
                                            <th class="sortable" data-sort="upi">
                                                <div class="th-content">
                                                    UPI
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="location">
                                                <div class="th-content">
                                                    Location
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="size">
                                                <div class="th-content">
                                                    Size
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="price">
                                                <div class="th-content">
                                                    Price
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="user">
                                                <div class="th-content">
                                                    User
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <th class="sortable" data-sort="date">
                                                <div class="th-content">
                                                    Date
                                                    <i class="bi bi-arrow-down-up sort-icon"></i>
                                                </div>
                                            </th>
                                            <!-- Removed Actions column -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (
                                            $properties as $property): ?>
                                        <tr>
                                            <td class="upi"><?php echo htmlspecialchars($property['upi']); ?></td>
                                            <td class="location"><?php echo htmlspecialchars($property['location']); ?></td>
                                            <td class="size" data-size="<?php echo $property['size_sqm']; ?>"><?php echo number_format($property['size_sqm']); ?> sqm</td>
                                            <td class="price" data-price="<?php echo $property['estimated_price']; ?>">RWF <?php echo number_format($property['estimated_price'], 0); ?></td>
                                            <td class="user"><?php echo htmlspecialchars($property['username']); ?></td>
                                            <td class="date" data-date="<?php echo strtotime($property['submission_date']); ?>"><?php echo date('M d, Y', strtotime($property['submission_date'])); ?></td>
                                            <!-- Removed Actions cell -->
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Table Footer -->
                            <div class="table-footer">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="table-info">Showing <?php echo count($properties); ?> properties</span>
                                    <button class="btn btn-outline-secondary btn-sm" onclick="refreshTable()">
                                        <i class="bi bi-arrow-clockwise me-1"></i>Refresh
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Card Styles */
.card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}

.stat-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Table Controls - Enhanced Visibility */
.table-controls {
    display: flex;
    gap: 1rem;
    align-items: center;
    flex-wrap: wrap;
    max-width: 100%;
}

.search-box {
    position: relative;
    flex: 1;
    max-width: 350px;
    min-width: 250px;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.8);
    z-index: 2;
    font-size: 1.1rem;
}

.search-input-enhanced {
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    border-radius: 25px;
    border: 3px solid #ffc107;
    background: #ffffff;
    color: #000;
    font-weight: 700;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    font-size: 16px;
    text-shadow: none;
}

.search-input-enhanced::placeholder {
    color: #333;
    font-weight: 600;
    opacity: 1;
    font-size: 15px;
}

.search-input-enhanced:focus {
    background: rgba(255, 255, 255, 0.95);
    border-color: #ffc107;
    box-shadow: 0 4px 20px rgba(255, 193, 7, 0.3);
    outline: none;
    color: #000;
}

.search-input-enhanced:focus::placeholder {
    color: #999;
    font-weight: 500;
}

/* Enhanced search box hover effect */
.search-box:hover .search-input-enhanced {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.4);
    transform: translateY(-1px);
}

/* Search box focus animation */
.search-input-enhanced:focus {
    animation: searchPulse 0.3s ease;
}

@keyframes searchPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.02); }
    100% { transform: scale(1); }
}

/* Clear search button */
.clear-search-btn {
    position: absolute;
    right: 0.5rem;
    top: 50%;
    transform: translateY(-50%);
    border-radius: 50%;
    width: 30px;
    height: 30px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.8;
    transition: all 0.3s ease;
    z-index: 3;
}

.clear-search-btn:hover {
    opacity: 1;
    transform: translateY(-50%) scale(1.1);
    background-color: rgba(255, 255, 255, 0.2);
}

/* Adjust search input padding when clear button is visible */
.search-box.has-clear .search-input-enhanced {
    padding-right: 3rem;
}

/* Search results info styling */
.search-results-info {
    background: #ffc107;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    color: #000;
    font-size: 0.875rem;
    font-weight: 600;
    margin-top: 0.5rem;
    display: none;
    border: 2px solid #000;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.5);
    position: relative;
    z-index: 10;
    max-width: 100%;
    word-wrap: break-word;
    white-space: normal;
    overflow: hidden;
    text-overflow: ellipsis;
    flex-shrink: 0;
}

.search-results-info.show {
    display: block;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from { 
        opacity: 0; 
        transform: translateY(-10px) scale(0.95); 
    }
    to { 
        opacity: 1; 
        transform: translateY(0) scale(1); 
    }
}

/* Mobile responsiveness for search */
@media (max-width: 768px) {
    .search-box {
        max-width: 100%;
        min-width: auto;
    }
    
    .search-input-enhanced {
        font-size: 16px; /* Prevents zoom on iOS */
    }
    
    .table-controls {
        flex-direction: column;
        gap: 0.5rem;
        width: 100%;
    }
    
    .search-results-info {
        text-align: center;
        margin-top: 0.25rem;
        white-space: normal;
        word-wrap: break-word;
        font-size: 0.8rem;
        padding: 0.4rem 0.8rem;
        width: 100%;
        max-width: 100%;
    }
    
    .clear-search-btn {
        width: 28px;
        height: 28px;
        right: 0.25rem;
    }
}

/* Modern Table Styles */
.modern-table {
    margin-bottom: 0;
    background: white;
}

.modern-table thead th {
    background: var(--gray-50);
    border-bottom: 2px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
    vertical-align: middle;
    position: relative;
}

.th-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.sort-icon {
    opacity: 0.5;
    transition: all 0.2s ease;
}

.sortable:hover .sort-icon {
    opacity: 1;
    color: var(--primary-color);
}

.modern-table tbody tr {
    border-bottom: 1px solid var(--gray-100);
    transition: all 0.2s ease;
}

.modern-table tbody tr:hover {
    background: var(--gray-50);
    transform: scale(1.01);
    box-shadow: var(--shadow-md);
}

.modern-table tbody td {
    padding: 1.25rem 1rem;
    vertical-align: middle;
    border-bottom: 1px solid var(--gray-100);
}

/* Table Footer */
.table-footer {
    background: var(--gray-50);
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--gray-200);
}

.table-info {
    color: var(--gray-600);
    font-size: 0.875rem;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    
    .sidebar {
        display: none;
    }
    
    .table-controls {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .search-box {
        max-width: 100%;
    }
}

@media (max-width: 768px) {
    .card {
        margin-bottom: 1rem;
    }
    
    .modern-table thead th {
        padding: 0.75rem 0.5rem;
        font-size: 0.7rem;
    }
    
    .modern-table tbody td {
        padding: 0.75rem 0.5rem;
        font-size: 0.875rem;
    }
}

/* Mobile Optimizations */
@media (max-width: 576px) {
    .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .table-controls {
        flex-direction: column;
        width: 100%;
    }
    
    .search-box,
    .filter-dropdown {
        width: 100%;
    }
}
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
const chartData = {
        labels: <?php echo json_encode(array_column($locations, 'location')); ?>,
    values: <?php echo json_encode(array_column($locations, 'count')); ?>,
    colors: [
        '#FF6384',
        '#36A2EB', 
        '#FFCD56',
        '#4BC0C0',
        '#9966FF'
    ]
};

const scene = new THREE.Scene();
const container = document.getElementById('locationChart').parentElement;
const chartCanvas = document.getElementById('locationChart');
const labelContainer = document.getElementById('pieLabels');
chartCanvas.style.display = 'none';

const width = container.clientWidth;
const height = container.clientHeight;
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setClearColor(0xffffff, 0);
container.appendChild(renderer.domElement);

const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 1000);
camera.position.set(0, 7, 10);
camera.lookAt(0, 0, 0);

// Modern glass effect background
const glassGeometry = new THREE.PlaneGeometry(12, 12);
const glassMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0.1,
    roughness: 0.1,
    transmission: 0.7,
    opacity: 0.7,
    transparent: true,
    clearcoat: 1,
    clearcoatRoughness: 0.1
});
const glass = new THREE.Mesh(glassGeometry, glassMaterial);
glass.position.y = -2.5;
glass.position.z = -2;
scene.add(glass);

// Lighting
scene.add(new THREE.AmbientLight(0xffffff, 0.7));
const dirLight = new THREE.DirectionalLight(0xffffff, 0.7);
dirLight.position.set(10, 10, 10);
dirLight.castShadow = true;
scene.add(dirLight);

// Pie chart group
const pieGroup = new THREE.Group();
scene.add(pieGroup);

const total = chartData.values.reduce((a, b) => a + b, 0);
let currentAngle = 0;
const segments = [];
const radius = 3.2;
const height3d = 1.1;
const labelPositions = [];
const segmentAngles = [];

chartData.values.forEach((value, index) => {
    const percentage = value / total;
    const angle = percentage * Math.PI * 2;
    // Pie segment
    const geometry = new THREE.CylinderGeometry(radius, radius, height3d, 80, 1, false, currentAngle, angle);
    const material = new THREE.MeshPhysicalMaterial({
        color: chartData.colors[index],
        metalness: 0.3,
        roughness: 0.2,
        clearcoat: 0.7,
        clearcoatRoughness: 0.1,
        transmission: 0.1,
        opacity: 0.98,
        transparent: true
    });
    const segment = new THREE.Mesh(geometry, material);
    segment.castShadow = true;
    segment.receiveShadow = true;
    pieGroup.add(segment);
    segments.push(segment);
    // Store start and end angle for this segment
    segmentAngles.push({ start: currentAngle, end: currentAngle + angle, index });
    currentAngle += angle;
});

// Now, after all segments are created, calculate label positions so that each label is centered above its segment
function updateLabelPositions() {
    labelPositions.length = 0;
    segmentAngles.forEach(({ start, end, index }) => {
        // Adjust for Three.js CylinderGeometry's start angle at -Math.PI/2 (12 o'clock)
        const midAngle = (start + end) / 2 - Math.PI / 2;
        labelPositions.push({
            x: Math.cos(midAngle) * (radius * 0.85),
            y: Math.sin(midAngle) * (radius * 0.85),
            index,
            percentage: ((chartData.values[index] / total) * 100).toFixed(1),
            value: chartData.values[index]
        });
    });
}
updateLabelPositions();

// Center the pie chart
pieGroup.position.y = 0;
pieGroup.position.x = 0;
pieGroup.position.z = 0;

// Mouse controls (user can rotate only, no auto-rotation)
let isMouseDown = false;
let lastMouseX = 0;
let lastMouseY = 0;
let rotationY = 0;
let rotationX = 0.3;

renderer.domElement.addEventListener('mousedown', (e) => {
    isMouseDown = true;
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
});
window.addEventListener('mouseup', () => { isMouseDown = false; });
window.addEventListener('mouseleave', () => { isMouseDown = false; });
renderer.domElement.addEventListener('mousemove', (e) => {
    if (!isMouseDown) return;
    const dx = e.clientX - lastMouseX;
    const dy = e.clientY - lastMouseY;
    rotationY += dx * 0.01;
    rotationX += dy * 0.01;
    rotationX = Math.max(-Math.PI / 2.5, Math.min(Math.PI / 2.5, rotationX));
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
});
renderer.domElement.addEventListener('wheel', (e) => {
    e.preventDefault();
    camera.position.z += e.deltaY * 0.01;
    camera.position.z = Math.max(6, Math.min(18, camera.position.z));
});

// Responsive resize
window.addEventListener('resize', () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    updateLabelPositions();
});

function updateLabels() {
    // Remove old labels
    labelContainer.innerHTML = '';
    // Project 3D positions to 2D overlay
    labelPositions.forEach(({ x, y, index, percentage, value }) => {
        const pos = new THREE.Vector3(x, height3d / 2 + 0.1, y);
        pos.applyMatrix4(pieGroup.matrixWorld);
        pos.project(camera);
        const cx = (pos.x * 0.5 + 0.5) * container.clientWidth;
        const cy = (-pos.y * 0.5 + 0.5) * container.clientHeight;
        const label = document.createElement('div');
        label.className = 'pie-label';
        label.style.left = `${cx}px`;
        label.style.top = `${cy}px`;
        label.innerHTML = `<span class="pie-label-dot" style="background:${chartData.colors[index]}"></span> <b>${chartData.labels[index]}</b><br><span class="pie-label-value">${value} (${percentage}%)</span>`;
        labelContainer.appendChild(label);
    });
}

function animate() {
    pieGroup.rotation.y = rotationY;
    pieGroup.rotation.x = rotationX;
    renderer.render(scene, camera);
    updateLabels();
    requestAnimationFrame(animate);
}

animate();
</script>
<style>
#locationChart {
    position: relative;
    width: 100%;
    height: 100%;
}
.chart-3d-container {
    position: relative;
    width: 100%;
    height: 400px;
    min-height: 320px;
    overflow: hidden;
    background: linear-gradient(135deg, #f8fafc 60%, #e3e8f0 100%);
    border-radius: 12px;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.12);
}
.chart-3d-container canvas {
    border-radius: 12px;
    box-shadow: 0 2px 16px 0 rgba(31, 38, 135, 0.10);
}
.pie-labels {
    position: absolute;
    left: 0; top: 0; width: 100%; height: 100%;
    pointer-events: none;
    z-index: 10;
}
.pie-label {
    position: absolute;
    transform: translate(-50%, -50%);
    background: rgba(255,255,255,0.92);
    border-radius: 8px;
    padding: 6px 14px 4px 10px;
    font-size: 13px;
    color: #222;
    font-family: 'Poppins', Arial, sans-serif;
    box-shadow: 0 2px 8px 0 rgba(31, 38, 135, 0.08);
    white-space: nowrap;
    min-width: 70px;
    text-align: center;
    font-weight: 500;
    border: 1px solid #e3e8f0;
    pointer-events: none;
    user-select: none;
}
.pie-label-dot {
    display: inline-block;
    width: 10px; height: 10px;
    border-radius: 50%;
    margin-right: 6px;
    vertical-align: middle;
    border: 1.5px solid #fff;
    box-shadow: 0 1px 3px #bbb2;
}
.pie-label-value {
    color: #666;
    font-size: 12px;
    font-weight: 400;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-chart-3d"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script>
// Register DataLabels plugin
Chart.register(ChartDataLabels);

// Search and filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('propertySearch');
    const table = document.getElementById('propertiesTable');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const searchResultsInfo = document.getElementById('searchResultsInfo');
    const searchResultsText = document.getElementById('searchResultsText');
    
    function filterTable() {
        const searchTerm = searchInput.value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');
        let visibleCount = 0;
        
        rows.forEach(row => {
            const upi = row.querySelector('.upi').textContent.toLowerCase();
            const location = row.querySelector('.location').textContent.toLowerCase();
            const user = row.querySelector('.user').textContent.toLowerCase();
            const size = row.querySelector('.size').textContent.toLowerCase();
            const price = row.querySelector('.price').textContent.toLowerCase();
            
            const matchesSearch = upi.includes(searchTerm) ||
                                location.includes(searchTerm) || 
                                user.includes(searchTerm) || 
                                size.includes(searchTerm) || 
                                price.includes(searchTerm);
            
            const isVisible = matchesSearch;
            row.style.display = isVisible ? '' : 'none';
            if (isVisible) visibleCount++;
        });
        
        // Update table info
        const tableInfo = document.querySelector('.table-info');
        if (tableInfo) {
            tableInfo.textContent = `Showing ${visibleCount} properties`;
        }
        
        // Update search results info
        const totalRows = rows.length;
        if (searchTerm) {
            searchResultsText.textContent = `Found ${visibleCount} of ${totalRows} properties`;
            searchResultsInfo.classList.add('show');
        } else {
            searchResultsInfo.classList.remove('show');
        }
        
        // Show/hide clear button
        if (searchTerm) {
            clearSearchBtn.style.display = 'flex';
            searchInput.parentElement.classList.add('has-clear');
        } else {
            clearSearchBtn.style.display = 'none';
            searchInput.parentElement.classList.remove('has-clear');
        }
    }
    
    // Clear search functionality
    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', function() {
            searchInput.value = '';
            filterTable();
            searchInput.focus();
        });
    }
    
    if (searchInput) searchInput.addEventListener('input', filterTable);
    
    // Sortable table headers
    const sortableHeaders = document.querySelectorAll('.sortable');
    sortableHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const sortType = this.dataset.sort;
            sortTable(sortType, this);
        });
    });
    
    function sortTable(sortType, headerElement) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const isAscending = !headerElement.classList.contains('sort-asc');
        
        // Remove sort classes from all headers
        sortableHeaders.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        
        // Add appropriate sort class
        headerElement.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        
        rows.sort((a, b) => {
            let aVal, bVal;
            
            switch(sortType) {
                case 'upi':
                    aVal = a.querySelector('.upi').textContent;
                    bVal = b.querySelector('.upi').textContent;
                    break;
                case 'location':
                    aVal = a.querySelector('.location').textContent;
                    bVal = b.querySelector('.location').textContent;
                    break;
                case 'size':
                    aVal = parseFloat(a.querySelector('.size').dataset.size);
                    bVal = parseFloat(b.querySelector('.size').dataset.size);
                    break;
                case 'price':
                    aVal = parseFloat(a.querySelector('.price').dataset.price);
                    bVal = parseFloat(b.querySelector('.price').dataset.price);
                    break;
                case 'user':
                    aVal = a.querySelector('.user').textContent;
                    bVal = b.querySelector('.user').textContent;
                    break;
                case 'date':
                    aVal = parseInt(a.querySelector('.date').dataset.date);
                    bVal = parseInt(b.querySelector('.date').dataset.date);
                    break;
                default:
                    return 0;
            }
            
            if (typeof aVal === 'string') {
                return isAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
            } else {
                return isAscending ? aVal - bVal : bVal - aVal;
            }
        });
        
        // Reappend sorted rows
        rows.forEach(row => tbody.appendChild(row));
    }
    
    // Refresh table function
    window.refreshTable = function() {
        location.reload();
    };
});

function deleteProperty(id) {
    if (confirm('Are you sure you want to delete this land?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="property_id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function exportData() {
    window.location.href = 'export.php';
}
</script>

<?php include '../includes/footer.php'; ?> 