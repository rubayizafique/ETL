<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect logged-in users to their dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: user/dashboard.php');
    exit;
}

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row align-items-center">
        <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="fade-in">
                <h1 class="display-4 fw-bold mb-4 text-gradient">
                    Land Price Estimation
                </h1>
                <p class="lead mb-4 text-muted">
                    Get accurate property price predictions using our advanced ML-powered system. 
                    Make informed decisions about your real estate investments.
                </p>
                <div class="d-flex gap-3">
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <a href="register.php" class="btn btn-primary btn-lg">
                            <i class="bi bi-person-plus"></i> Get Started
                        </a>
                        <a href="login.php" class="btn btn-outline-primary btn-lg">
                            <i class="bi bi-box-arrow-in-right"></i> Login
                        </a>
                    <?php else: ?>
                        <a href="predict.php" class="btn btn-primary btn-lg">
                            <i class="bi bi-calculator"></i> Predict Price
                        </a>
                        <a href="submit.php" class="btn btn-outline-primary btn-lg">
                            <i class="bi bi-plus-circle"></i> Submit Property
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card fade-in">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">
                        <i class="bi bi-graph-up"></i> Why Choose Us?
                    </h3>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="feature-card p-3 rounded">
                                <i class="bi bi-cpu text-primary display-6 mb-3"></i>
                                <h5>ML-Powered</h5>
                                <p class="text-muted mb-0">Advanced algorithms for accurate predictions</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="feature-card p-3 rounded">
                                <i class="bi bi-speedometer2 text-primary display-6 mb-3"></i>
                                <h5>Real-Time Data</h5>
                                <p class="text-muted mb-0">Up-to-date market information</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="feature-card p-3 rounded">
                                <i class="bi bi-shield-check text-primary display-6 mb-3"></i>
                                <h5>Secure & Reliable</h5>
                                <p class="text-muted mb-0">Your data is always protected</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="feature-card p-3 rounded">
                                <i class="bi bi-graph-up-arrow text-primary display-6 mb-3"></i>
                                <h5>Market Insights</h5>
                                <p class="text-muted mb-0">Detailed property analytics</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Land Gallery Section -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card fade-in">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">
                        <i class="bi bi-images"></i> Featured Properties
                    </h3>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="land-card">
                                <img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800" 
                                     alt="Residential Land" 
                                     class="img-fluid rounded">
                                <div class="land-card-overlay">
                                    <h5>Residential Land</h5>
                                    <p>Perfect for housing development</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="land-card">
                                <img src="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800" 
                                     alt="Agricultural Land" 
                                     class="img-fluid rounded">
                                <div class="land-card-overlay">
                                    <h5>Agricultural Land</h5>
                                    <p>Ideal for farming and cultivation</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="land-card">
                                <img src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=800" 
                                     alt="Commercial Land" 
                                     class="img-fluid rounded">
                                <div class="land-card-overlay">
                                    <h5>Commercial Land</h5>
                                    <p>Great for business development</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- How It Works Section -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card fade-in">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">
                        <i class="bi bi-info-circle"></i> How It Works
                    </h3>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="text-center">
                                <div class="step-number mb-3">1</div>
                                <h5>Enter Details</h5>
                                <p class="text-muted">Provide property location, size, and features</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-center">
                                <div class="step-number mb-3">2</div>
                                <h5>ML Analysis</h5>
                                <p class="text-muted">Our system analyzes market data and trends</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-center">
                                <div class="step-number mb-3">3</div>
                                <h5>Get Results</h5>
                                <p class="text-muted">Receive accurate price predictions</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.text-gradient {
    background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.feature-card {
    background: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.step-number {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin: 0 auto;
}

.btn-outline-primary {
    border: 2px solid #3498db;
    color: #3498db;
    font-weight: 500;
}

.btn-outline-primary:hover {
    background: #3498db;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
}

.land-card {
    position: relative;
    overflow: hidden;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
}

.land-card:hover {
    transform: translateY(-5px);
}

.land-card img {
    width: 100%;
    height: 250px;
    object-fit: cover;
}

.land-card-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
    color: white;
    padding: 20px;
}

.land-card-overlay h5 {
    margin: 0;
    font-size: 1.2rem;
}

.land-card-overlay p {
    margin: 5px 0 0;
    font-size: 0.9rem;
    opacity: 0.9;
}
</style>

<?php include 'includes/footer.php'; ?> 