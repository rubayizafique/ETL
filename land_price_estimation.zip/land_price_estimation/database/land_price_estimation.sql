-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2025 at 03:20 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `land_price_estimation`
--

-- --------------------------------------------------------

--
-- Table structure for table `predictions`
--

CREATE TABLE `predictions` (
  `id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `predicted_price` decimal(15,2) NOT NULL,
  `confidence_score` decimal(5,2) DEFAULT NULL,
  `prediction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `predictions`
--

INSERT INTO `predictions` (`id`, `property_id`, `predicted_price`, `confidence_score`, `prediction_date`) VALUES
(42, 44, '5460000.00', '85.00', '2025-07-12 15:47:19'),
(43, 45, '4860000.00', '85.00', '2025-07-12 16:08:49'),
(44, 46, '5106000.00', '85.00', '2025-07-12 16:18:50'),
(45, 47, '6534000.00', '85.00', '2025-07-12 16:26:55'),
(46, 48, '6734000.00', '85.00', '2025-07-12 16:27:31'),
(47, 49, '6899000.00', '85.00', '2025-07-12 16:28:10'),
(48, 50, '6534000.00', '85.00', '2025-07-14 21:52:16'),
(49, 51, '6734000.00', '85.00', '2025-07-14 21:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `prediction_requests`
--

CREATE TABLE `prediction_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `response_date` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `upi` varchar(64) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `size_sqm` decimal(10,2) NOT NULL,
  `has_water` tinyint(1) DEFAULT 0,
  `has_electricity` tinyint(1) DEFAULT 0,
  `has_road_access` tinyint(1) DEFAULT 0,
  `additional_amenities` text DEFAULT NULL,
  `estimated_price` decimal(15,2) DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `land_type` varchar(50) DEFAULT NULL,
  `zoning` varchar(50) DEFAULT NULL,
  `land_use` varchar(100) DEFAULT NULL,
  `nearby_schools` tinyint(1) DEFAULT 0,
  `nearby_hospital` tinyint(1) DEFAULT 0,
  `nearby_market` tinyint(1) DEFAULT 0,
  `nearby_university` tinyint(1) DEFAULT 0,
  `zoning_landtype` varchar(100) DEFAULT NULL,
  `nearby_amenities` text DEFAULT NULL,
  `distance_to_city_center` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `upi`, `user_id`, `location`, `size_sqm`, `has_water`, `has_electricity`, `has_road_access`, `additional_amenities`, `estimated_price`, `submission_date`, `land_type`, `zoning`, `land_use`, `nearby_schools`, `nearby_hospital`, `nearby_market`, `nearby_university`, `zoning_landtype`, `nearby_amenities`, `distance_to_city_center`) VALUES
(44, 'TEMP_UPI_44', 2, 'Ngoma', '478.00', 0, 0, 0, '0', '5460000.00', '2025-07-12 15:47:18', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', '', '7.00'),
(45, 'TEMP_UPI_45', 2, 'Huye', '351.00', 0, 0, 0, '0', '4860000.00', '2025-07-12 16:08:49', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', '', '5.00'),
(46, 'TEMP_UPI_46', 2, 'Huye', '351.00', 0, 0, 0, '0', '5106000.00', '2025-07-12 16:18:50', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'School, Market', '5.00'),
(47, 'TEMP_UPI_47', 2, 'Huye', '351.00', 0, 0, 0, '0', '6534000.00', '2025-07-12 16:26:55', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'School, Market', '5.00'),
(48, 'TEMP_UPI_48', 2, 'Huye', '351.00', 0, 0, 0, '0', '6734000.00', '2025-07-12 16:27:31', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'School, Market', '5.00'),
(49, 'TEMP_UPI_49', 2, 'Ngoma', '478.00', 0, 0, 0, '0', '6899000.00', '2025-07-12 16:28:10', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'Hospital, University', '7.00'),
(50, '56fy6', 2, 'Huye', '351.00', 0, 0, 0, '0', '6534000.00', '2025-07-14 21:52:16', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'School, Market', '5.00'),
(51, 'gjh78g', 2, 'Huye', '351.00', 0, 0, 0, '0', '6734000.00', '2025-07-14 21:52:55', 'Residential', 'Commercial', NULL, 0, 0, 0, 0, 'Commercial - Residential', 'School, Market', '5.00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'site_name', 'Land Price Estimation', '2025-06-09 11:28:37', '2025-06-09 11:28:37'),
(2, 'site_description', 'Advanced land price estimation system', '2025-06-09 11:28:37', '2025-06-09 11:28:37'),
(3, 'contact_email', 'Ally@gmail.com', '2025-06-09 11:28:38', '2025-06-09 11:30:21'),
(4, 'confidence_threshold', '70', '2025-06-09 11:28:38', '2025-06-09 11:28:38'),
(5, 'price_adjustment', '1.0', '2025-06-09 11:28:38', '2025-06-09 11:28:38'),
(6, 'market_trend_weight', '0.3', '2025-06-09 11:28:38', '2025-06-09 11:28:38'),
(7, 'email_notifications', '1', '2025-06-09 11:28:38', '2025-06-09 11:28:38'),
(8, 'notification_frequency', 'daily', '2025-06-09 11:28:38', '2025-06-09 11:28:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`) VALUES
(2, 'seba', '$2y$10$II.Q8xuOgU.2G2634kVWqew0WYy53Q5g4VRH4.KsGr4s5/f/W.AiG', 'sebastienmuhire@gmail.com', 'user', '2025-05-16 12:36:23'),
(3, 'admin', '$2y$10$Ho16Su3eYwPGfn350DMltuxrlvaMZ8rn4VZhzumXoAGGqBsVZDLzG', 'admin@example.com', 'admin', '2025-05-16 12:38:33'),
(4, 'Ally', '$2y$10$BhE8r8GvwXCuaAMT6s2wLu0PlCZmDTr9TVNovcROB69ivXvA5xJsa', 'ally@gmail.com', 'user', '2025-06-09 12:12:49');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notifications` tinyint(1) DEFAULT 1,
  `email_alerts` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_preferences`
--

INSERT INTO `user_preferences` (`id`, `user_id`, `notifications`, `email_alerts`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 1, '2025-06-08 20:21:39', '2025-06-08 20:21:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `predictions`
--
ALTER TABLE `predictions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_predictions_property` (`property_id`);

--
-- Indexes for table `prediction_requests`
--
ALTER TABLE `prediction_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `upi` (`upi`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `predictions`
--
ALTER TABLE `predictions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `prediction_requests`
--
ALTER TABLE `prediction_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=273;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `predictions`
--
ALTER TABLE `predictions`
  ADD CONSTRAINT `fk_predictions_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `prediction_requests`
--
ALTER TABLE `prediction_requests`
  ADD CONSTRAINT `prediction_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `fk_properties_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
