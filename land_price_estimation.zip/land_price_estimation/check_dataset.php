<?php
require_once 'config/database.php';

echo "Checking original_dataset table contents:\n\n";

// Check for Huye properties
$stmt = $conn->prepare("SELECT * FROM original_dataset WHERE location = 'Huye' AND size_sqm = 351 LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();

echo "Huye properties with 351 sqm:\n";
while ($row = $result->fetch_assoc()) {
    echo "Plot: " . $row['plot_number'] . "\n";
    echo "Location: " . $row['location'] . "\n";
    echo "Size: " . $row['size_sqm'] . "\n";
    echo "Price: " . number_format($row['price']) . "\n";
    echo "Zoning: " . $row['zoning'] . "\n";
    echo "Land Type: " . $row['land_type'] . "\n";
    echo "Amenities: " . $row['nearby_amenities'] . "\n";
    echo "Distance: " . $row['distance_to_city_center'] . "\n";
    echo "---\n";
}

// Check for Commercial - Residential combinations
$stmt = $conn->prepare("SELECT DISTINCT zoning, land_type FROM original_dataset WHERE location = 'Huye'");
$stmt->execute();
$result = $stmt->get_result();

echo "\nZoning-Land Type combinations in Huye:\n";
while ($row = $result->fetch_assoc()) {
    echo $row['zoning'] . " - " . $row['land_type'] . "\n";
}

// Check for School, Market combinations
$stmt = $conn->prepare("SELECT DISTINCT nearby_amenities FROM original_dataset WHERE location = 'Huye'");
$stmt->execute();
$result = $stmt->get_result();

echo "\nAmenities combinations in Huye:\n";
while ($row = $result->fetch_assoc()) {
    echo $row['nearby_amenities'] . "\n";
}

$conn->close();
?> 