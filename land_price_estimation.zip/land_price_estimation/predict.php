<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get distinct locations from the CSV dataset (only these 4 locations are valid)
$locations = [
    ['location' => 'Huye'],
    ['location' => 'Ngoma'],
    ['location' => 'Tumba'],
    ['location' => 'Rukira']
];

include 'includes/header_logged_in.php';
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar bg-dark text-white d-none d-lg-block" style="width: 250px; min-height: 100vh; position: fixed; left: 0; top: 0; z-index: 1000;">
        <div class="p-3">
            <div class="d-flex align-items-center mb-4">
                <img src="assets/images/logo.jfif" alt="Logo" class="me-2" style="width: 40px; height: 40px;">
                <h5 class="text-white mb-0">User Dashboard</h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link text-white" href="user/dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white active" href="predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="user/profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="user/history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="user/settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-white" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Mobile Sidebar Toggle Button -->
    <button class="btn btn-dark d-lg-none position-fixed" style="top: 1rem; left: 1rem; z-index: 1100;" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMobile" aria-controls="sidebarMobile">
        <i class="bi bi-list fs-2"></i>
    </button>
    <!-- Mobile Sidebar (Offcanvas) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarMobile">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="user/dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="predict.php">
                        <i class="bi bi-calculator me-2"></i> New Prediction
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user/profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user/history.php">
                        <i class="bi bi-clock-history me-2"></i> History
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user/settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" style="margin-left: 250px; width: calc(100% - 250px);">
        <div class="container-fluid py-4">
            <!-- Prediction Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">New Land Price Prediction</h1>
                    <p class="text-muted mb-0">Enter land details to get a price estimate</p>
                </div>
                <a href="logout.php" class="btn btn-outline-danger d-lg-none">
                    <i class="bi bi-box-arrow-right"></i>
                </a>
            </div>

            <div class="row">
                <div class="col-lg-8">
                    <!-- Prediction Form -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <form action="submit.php" method="POST" id="predictionForm">
                                <input type="hidden" name="predicted_price" id="predicted_price" value="">
                                <div class="row g-3">
                                    <!-- Location -->
                                    <div class="mb-3">
                                        <label for="location" class="form-label">Location</label>
                                        <select class="form-select" id="location" name="location" required>
                                            <option value="">Select location</option>
                                            <?php foreach ($locations as $loc): ?>
                                                <option value="<?php echo htmlspecialchars($loc['location']); ?>">
                                                    <?php echo htmlspecialchars($loc['location']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <!-- Size -->
                                    <div class="col-md-6">
                                        <label for="size_sqm" class="form-label">Size (Square Meters)</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" id="size_sqm" name="size_sqm" 
                                                   min="1" step="0.01" required>
                                            <span class="input-group-text">sqm</span>
                                        </div>
                                    </div>
                                    <!-- UPI -->
                                    <div class="col-md-6">
                                        <label for="upi" class="form-label">UPI <span class="text-muted" style="font-size:0.95em;">(Unique Parcel Identifier)</span></label>
                                        <input type="text" class="form-control" id="upi" name="upi" maxlength="64" required placeholder="Enter UPI">
                                       
                                    </div>

                                    <!-- Nearby Amenities Dropdown -->
                                    <div class="col-12">
                                        <label class="form-label">Nearby Amenities</label>
                                        <select class="form-select" id="nearby_amenities" name="nearby_amenities" required>
                                            <option value="">Select amenities</option>
                                            <option value="School, Market">School, Market</option>
                                            <option value="Hospital, University">Hospital, University</option>
                                            <option value="Market, University">Market, University</option>
                                            <option value="School, Hospital">School, Hospital</option>
                                        </select>
                                    </div>

                                    <!-- Distance to City Center (km) -->
                                    <div class="col-12">
                                        <label for="distance_to_city_center" class="form-label">Distance to City Center (km)</label>
                                        <input type="number" class="form-control" id="distance_to_city_center" name="distance_to_city_center" min="0" step="0.01" required>
                                    </div>

                                    <!-- Zoning Dropdown -->
                                    <div class="col-12">
                                        <label for="zoning" class="form-label">Zoning</label>
                                        <select class="form-select" id="zoning" name="zoning" required>
                                            <option value="">Select zoning</option>
                                            <option value="Agricultural">Agricultural</option>
                                            <option value="Commercial">Commercial</option>
                                            <option value="Residential">Residential</option>
                                        </select>
                                    </div>

                                    <!-- Land Type Dropdown -->
                                    <div class="col-12">
                                        <label for="land_type" class="form-label">Land Type</label>
                                        <select class="form-select" id="land_type" name="land_type" required>
                                            <option value="">Select land type</option>
                                            <option value="Agricultural">Agricultural</option>
                                            <option value="Commercial">Commercial</option>
                                            <option value="Residential">Residential</option>
                                        </select>
                                    </div>

                                    <!-- Additional Notes -->
                                    <div class="col-12">
                                        <label for="notes" class="form-label">Additional Notes</label>
                                        <textarea class="form-control" id="notes" name="notes" rows="3" 
                                                  placeholder="Enter any additional details about the land..."></textarea>
                                    </div>

                                    <!-- Submit Button -->
                                    <div class="col-12">
                                        <button type="button" class="btn btn-primary" id="getEstimateBtn">
                                            <i class="bi bi-calculator me-2"></i>Get Price Estimate
                                        </button>
                                        <button type="submit" class="btn btn-success d-none" id="savePredictionBtn" style="margin-left:10px;">
                                            <i class="bi bi-save me-2"></i>Save Prediction
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="predictionResult" style="margin-top:20px;"></div>
                </div>

                <div class="col-lg-4">
                    <!-- Information Card -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-info-circle me-2"></i>How It Works
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex align-items-start mb-3">
                                <div class="step-icon bg-primary bg-opacity-10 rounded p-2 me-3">
                                    <i class="bi bi-1-circle text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Enter Land Details</h6>
                                    <p class="text-muted mb-0">Fill in the basic information about your land</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-start mb-3">
                                <div class="step-icon bg-primary bg-opacity-10 rounded p-2 me-3">
                                    <i class="bi bi-2-circle text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Analysis</h6>
                                    <p class="text-muted mb-0">Our system analyzes market data and similar properties</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-start">
                                <div class="step-icon bg-primary bg-opacity-10 rounded p-2 me-3">
                                    <i class="bi bi-3-circle text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Get Estimate</h6>
                                    <p class="text-muted mb-0">Receive a detailed price estimate with confidence score</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tips Card -->
                    <div class="card border-0 shadow-sm mt-4">
                        <div class="card-header bg-transparent border-0">
                            <h5 class="card-title mb-0">
                                <i class="bi bi-lightbulb me-2"></i>Tips
                            </h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Provide accurate measurements
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Include all available amenities
                                </li>
                                <li class="mb-2">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Add relevant notes for better accuracy
                                </li>
                                <li>
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Check similar properties in the area
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Form Styles */
.form-control:focus, .form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.step-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .sidebar {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

@media (max-width: 768px) {
    .card {
        margin-bottom: 1rem;
    }
}

/* Mobile Optimizations */
@media (max-width: 576px) {
    .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .form-check {
        margin-bottom: 1rem;
    }
}
</style>

<script>
const form = document.getElementById('predictionForm');
const getEstimateBtn = document.getElementById('getEstimateBtn');
const savePredictionBtn = document.getElementById('savePredictionBtn');
const predictionResult = document.getElementById('predictionResult');
const predictedPriceInput = document.getElementById('predicted_price');

getEstimateBtn.addEventListener('click', function(e) {
    e.preventDefault();
    const data = {
        location: form.location.value,
        size_sqm: form.size_sqm.value,
        upi: form.upi.value,
        nearby_amenities: form.nearby_amenities.value,
        distance_to_city_center: form.distance_to_city_center.value,
        zoning: form.zoning.value,
        land_type: form.land_type.value
    };
    predictionResult.innerHTML = 'Loading...';
    fetch('api/predict_price.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(res => {
        if(res.success) {
            predictionResult.innerHTML = `<div class="alert alert-success">Estimated Price: <b>${res.predicted_price}</b></div>`;
            predictedPriceInput.value = res.predicted_price;
            savePredictionBtn.classList.remove('d-none');
        } else {
            predictionResult.innerHTML = `<div class="alert alert-danger">Error: ${res.error}</div>`;
            savePredictionBtn.classList.add('d-none');
        }
    })
    .catch(err => {
        predictionResult.innerHTML = `<div class="alert alert-danger">Request failed.</div>`;
        savePredictionBtn.classList.add('d-none');
    });
});
form.addEventListener('submit', function(e) {
    if (!predictedPriceInput.value) {
        e.preventDefault();
        predictionResult.innerHTML = '<div class="alert alert-warning">Please get a price estimate first.</div>';
        return;
    }
    // No AJAX submit here, so browser will send all fields including notes and predicted_price
});

// Optionally, display backend errors if redirected back to this page
window.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('error')) {
        predictionResult.innerHTML = `<div class='alert alert-danger'>${decodeURIComponent(urlParams.get('error'))}</div>`;
    }
});
</script>

<?php include 'includes/footer.php'; ?> 